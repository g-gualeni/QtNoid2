 #ifndef QTNOID_APP_PARAMETERSPAGE_H
#define QTNOID_APP_PARAMETERSPAGE_H


#include "global.h"
#include "parameter.h"
#include <QObject>
#include <QList>
#include <QProperty>
#include <QMetaMethod>

class TestQtNoidAppParametersPage;

namespace QtNoid {
namespace App {

class QTNOID_APP_EXPORT ParametersPage : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QString name READ name WRITE setName BINDABLE bindableName NOTIFY nameChanged FINAL)
    Q_PROPERTY(QString label READ label WRITE setLabel BINDABLE bindableLabel NOTIFY labelChanged FINAL)
    Q_PROPERTY(QString description READ description WRITE setDescription BINDABLE bindableDescription NOTIFY descriptionChanged FINAL)
    Q_PROPERTY(QString tooltip READ tooltip WRITE setTooltip BINDABLE bindableTooltip NOTIFY tooltipChanged FINAL)
    Q_PROPERTY(bool readOnly READ readOnly WRITE setReadOnly BINDABLE bindableReadOnly NOTIFY readOnlyChanged FINAL)
    Q_PROPERTY(bool visible READ visible WRITE setVisible BINDABLE bindableVisible NOTIFY visibleChanged FINAL)
    Q_PROPERTY(bool isValueModified READ isValueModified BINDABLE bindableIsValueModified NOTIFY isValueModifiedChanged FINAL)
    Q_PROPERTY(bool isSchemaModified READ isSchemaModified BINDABLE bindableIsSchemaModified NOTIFY isSchemaModifiedChanged FINAL)
    Q_PROPERTY(int count READ count BINDABLE bindableCount NOTIFY countChanged FINAL)

public:

    // ===== ITERATOR CLASSES =====
    class iterator {
    public:
        using iterator_category = std::bidirectional_iterator_tag;
        using value_type = Parameter*;
        using difference_type = std::ptrdiff_t;
        using pointer = Parameter**;
        using reference = Parameter*&;

        iterator() = default;
        explicit iterator(QMap<int, Parameter*>::iterator it) : m_it(it) {}

        Parameter* operator*() const { return m_it.value(); }
        Parameter* operator->() const { return m_it.value(); }

        iterator& operator++() { ++m_it; return *this; }
        iterator operator++(int) { iterator tmp = *this; ++m_it; return tmp; }
        iterator& operator--() { --m_it; return *this; }
        iterator operator--(int) { iterator tmp = *this; --m_it; return tmp; }

        bool operator==(const iterator& other) const { return m_it == other.m_it; }
        bool operator!=(const iterator& other) const { return m_it != other.m_it; }

        int index() const { return m_it.key(); }

    private:
        QMap<int, Parameter*>::iterator m_it;
        friend class const_iterator;
        friend class ParametersPage;
    };

    class const_iterator {
    public:
        using iterator_category = std::bidirectional_iterator_tag;
        using value_type = const Parameter*;
        using difference_type = std::ptrdiff_t;
        using pointer = const Parameter**;
        using reference = const Parameter*&;

        const_iterator() = default;
        explicit const_iterator(QMap<int, Parameter*>::const_iterator it) : m_it(it) {}
        const_iterator(const iterator& it) : m_it(it.m_it) {}  // Conversione da non-const

        const Parameter* operator*() const { return m_it.value(); }
        const Parameter* operator->() const { return m_it.value(); }

        const_iterator& operator++() { ++m_it; return *this; }
        const_iterator operator++(int) { const_iterator tmp = *this; ++m_it; return tmp; }
        const_iterator& operator--() { --m_it; return *this; }
        const_iterator operator--(int) { const_iterator tmp = *this; --m_it; return tmp; }

        bool operator==(const const_iterator& other) const { return m_it == other.m_it; }
        bool operator!=(const const_iterator& other) const { return m_it != other.m_it; }

        int index() const { return m_it.key(); }

    private:
        QMap<int, Parameter*>::const_iterator m_it;
    };

    // Reverse iterators
    using reverse_iterator = std::reverse_iterator<iterator>;
    using const_reverse_iterator = std::reverse_iterator<const_iterator>;

    // ===== END ITERATOR CLASSES =====

    explicit ParametersPage(QObject *parent = nullptr);
    explicit ParametersPage(const QString& name, QObject *parent = nullptr);
    explicit ParametersPage(const QJsonObject &schemaList, const QJsonObject& valueList, QObject *parent = nullptr);
     ~ParametersPage() override;

    int uniqueId() const { return m_uniqueId; }

    // JSON Serialization / Deserialization
    QJsonObject toJsonValues() const;
    QJsonObject toJsonSchema() const;
    bool valuesFromJson(const QJsonObject& json);
    bool schemaFromJson(const QJsonObject& json);

    // Name
    QString name() const;
    void setName(const QString& newName);
    QBindable<QString> bindableName();

    // Label
    QString label() const;
    void setLabel(const QString& newLabel);
    QBindable<QString> bindableLabel();

    // Description
    QString description() const;
    void setDescription(const QString& value);
    QBindable<QString> bindableDescription();

    // Tooltip
    QString tooltip() const;
    void setTooltip(const QString& value);
    QBindable<QString> bindableTooltip();

    // ReadOnly
    bool readOnly() const;
    void setReadOnly(bool value);
    QBindable<bool> bindableReadOnly();

    // Visible
    bool visible() const;
    void setVisible(bool value);
    QBindable<bool> bindableVisible();

    // isValueModified: track modifications
    bool isValueModified() const;
    QBindable<bool> bindableIsValueModified();
    void setValueModified(bool modified);
    void resetValueModifications();

    // isSchemaModified: tracks modifications to this page's own properties
    // (name, label, description, tooltip, readOnly, visible) and to any
    // contained Parameter's isSchemaModified, unlike isValueModified which only
    // tracks value changes.
    bool isSchemaModified() const;
    QBindable<bool> bindableIsSchemaModified();
    void setSchemaModified(bool modified);
    void resetSchemaModifications();   // restores own properties AND cascades to every Parameter

    // List management
    int count() const;
    QBindable<int> bindableCount();
    bool append(Parameter *parameter);
    bool append(const QJsonObject& schema, const QJsonObject& value);
    Parameter* emplace(const QVariant& initialValue, const QString& name, const QString& description = {});
    Parameter* emplace(const QJsonObject& schema, const QJsonObject& value);
    void removeParameter(Parameter* parameter);
    void removeParameter(const QString& name);
    void clear();
    bool isEmpty() const;

    // Access methods
    Parameter* parameter(int index) const;
    Parameter* parameter(const QString& name) const;
    int indexOf(Parameter* parameter) const;
    int indexOf(const QString& name) const;
    bool contains(Parameter* parameter) const;
    bool contains(const QString& name) const;

    // List access
    QList<Parameter*> parameters() const;

    // Convenience methods
    QVariant value(const QString& name) const;
    bool setValue(const QString& name, const QVariant& value);
    void applyPreset(const QString& presetName);

    // ===== ITERATOR METHODS =====
    iterator begin() { return iterator(m_parametersByIndex.begin()); }
    iterator end() { return iterator(m_parametersByIndex.end()); }
    const_iterator begin() const { return const_iterator(m_parametersByIndex.constBegin()); }
    const_iterator end() const { return const_iterator(m_parametersByIndex.constEnd()); }
    const_iterator cbegin() const { return const_iterator(m_parametersByIndex.constBegin()); }
    const_iterator cend() const { return const_iterator(m_parametersByIndex.constEnd()); }

    reverse_iterator rbegin() { return reverse_iterator(end()); }
    reverse_iterator rend() { return reverse_iterator(begin()); }
    const_reverse_iterator rbegin() const { return const_reverse_iterator(end()); }
    const_reverse_iterator rend() const { return const_reverse_iterator(begin()); }
    const_reverse_iterator crbegin() const { return const_reverse_iterator(cend()); }
    const_reverse_iterator crend() const { return const_reverse_iterator(cbegin()); }

public:
    ParametersPage &operator<<(Parameter& param){
        append(&param);
        return *this;
    };
    ParametersPage &operator<<(Parameter* param){
        if(param) append(param);
        return *this;
    };


signals:
    void aboutToBeDestroyed(QtNoid::App::ParametersPage *page);
    void nameChanged(const QString& value);
    void nameEdited(const QString &oldName, const QString &newName);
    void labelChanged(const QString& value);
    void descriptionChanged(const QString& value);
    void tooltipChanged(const QString& value);
    void countChanged(int count);
    void parameterAdded(const QtNoid::App::Parameter* parameter);
    void parameterRemoved(QtNoid::App::Parameter* parameter);
    void parameterRenameError(const QString& oldName, const QString& newName);
    void visibleChanged(bool value);
    void readOnlyChanged(bool value);
    void isValueModifiedChanged(bool value);
    void isSchemaModifiedChanged(bool changed);
    void writeAttemptedWhileReadOnly(const QString &parameterName);


private:
    Q_OBJECT_BINDABLE_PROPERTY(ParametersPage, QString, m_name, &ParametersPage::nameChanged)
    Q_OBJECT_BINDABLE_PROPERTY(ParametersPage, QString, m_label, &ParametersPage::labelChanged)
    Q_OBJECT_BINDABLE_PROPERTY(ParametersPage, QString, m_description, &ParametersPage::descriptionChanged)
    Q_OBJECT_BINDABLE_PROPERTY(ParametersPage, QString, m_tooltip, &ParametersPage::tooltipChanged)
    Q_OBJECT_BINDABLE_PROPERTY(ParametersPage, int, m_count, &ParametersPage::countChanged)
    Q_OBJECT_BINDABLE_PROPERTY(ParametersPage, bool, m_visible, &ParametersPage::visibleChanged)
    Q_OBJECT_BINDABLE_PROPERTY(ParametersPage, bool, m_readOnly, &ParametersPage::readOnlyChanged)
    Q_OBJECT_BINDABLE_PROPERTY(ParametersPage, bool, m_isValueModified, &ParametersPage::isValueModifiedChanged)
    Q_OBJECT_BINDABLE_PROPERTY(ParametersPage, bool, m_isSchemaModified, &ParametersPage::isSchemaModifiedChanged)

    friend class ::TestQtNoidAppParametersPage; // Only for White Box testing

    void initInternalConnections();
    bool canModify(const QString &parameterName) const; // Modification control
    void removeParameterInternal(Parameter *parameter);
    void appendParameterAndUpdateIndexs(Parameter *parameter);

private slots:
    void onOwnPropertyChanged();
    void onParameterAboutToBeDestroyed(QtNoid::App::Parameter *parameter);
    void onParameterNameEdited(const QString& oldName, const QString& newName);
    void onParameterIsValueModifiedChanged(bool changed);
    void onParameterIsSchemaModifiedChanged(bool changed);

private:
    QHash<int, Parameter*> m_parametersByUniqueId;
    QMap<int, Parameter*> m_parametersByIndex;
    QHash<Parameter*, int> m_parameterToIndex; // Parameter -> sortIndex
    QHash<QString, Parameter*> m_parametersByName;
    int m_nextParameterIndex = 0;

    static QMutex s_uniqueIdMutex;
    static int s_nextUniqueId;
    int m_uniqueId;
    int getNextUniqueId();

    int m_valueModifiedCounter = 0;

    void captureBaseline();
    void updateIsSchemaModified();
    QHash<QByteArray, QVariant> m_schemaBaseline;
    int m_parameterSchemaModifiedCounter = 0;
    QProperty<bool> m_forceSchemaModified; // read inside updateIsSchemaModified() so it can override the computed state
};

} // namespace App
} // namespace QtNoid

inline QDebug operator<<(QDebug debug, const QtNoid::App::ParametersPage &list)
{
    QDebugStateSaver saver(debug);
    debug.nospace() << list.name() << list.label()
                    << ":{ uniqueID:" << list.uniqueId()
                    << ", count: " << list.count()
                    << ", visible: " << list.visible();
    QString str = list.description();
    if(!str.isEmpty()){
        debug.nospace() << ", description: " << str;
    }
    str = list.tooltip();
    if(!str.isEmpty()){
        debug.nospace() << ", tooltip: " << str;
    }

    if (!list.isEmpty()) {
        debug << ", parameters: [";
        for (int i = 0; i < list.count(); ++i) {
            if (i > 0) debug << ", ";
            QtNoid::App::Parameter* param = list.parameter(i);
            if (param) {
                QString changedFlag = param->isValueModified()? ", modified" : ", notModified";
                debug << param->name() << ":{" << param->value() << changedFlag << "}";

            }
        }
        debug << "]";
    }
    debug << "}";
    return debug;
}

inline QDebug operator<<(QDebug debug, const QtNoid::App::ParametersPage *list)
{
    if (list) {
        return ::operator<<(debug, *list);
    } else {
        return debug << "ParametersPage(nullptr)";
    }
}


#endif // QTNOID_APP_PARAMETERSPAGE_H
