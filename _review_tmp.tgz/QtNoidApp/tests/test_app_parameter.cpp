#include <QElapsedTimer>
#include <QJsonArray>
#include <QJsonObject>
#include <QSignalSpy>
#include <QTest>
#include <QtNoidApp/QtNoidApp>

class TestQtNoidAppParameter : public QObject
{
    Q_OBJECT

private slots:
    void initTestCase();
    void cleanupTestCase();
    void init();
    void cleanup();
    void testCreatingParameter();
    void testConstructorWithNameAndInitialValue();
    void testConstructorWithNameDescriptionAndInitialValue();

    void testUniqueId();

    void testParameterValueChanged();
    void testParameterValueChangedNoEmitForSameValue();
    void testParameterMin();
    void testParameterMax();
    void testTooltip();
    void testVisible();

    void testParameterSetPresets();
    void testParameterSetPreset();
    void testParameterApplyPresetByName();
    void testParameterRemovePreset();
    void testParameterClearPreset();
    void testParameterSetPresetShouldAbideToRangeRules();
    void testParameterApplyPresetReadOnlyShouldBeIneffective();

    void testParameterRange();
    void testParameterSetRangeShouldHandleFlippingMinAndMaxSoRangeWillBeConsistent();
    void testParameterRangeIsValid();
    void testParameterName();
    void testParameterLabel();
    void testParameterDescription();
    void testParameterUnit();
    void testParameterTooltip();
    void testParameterReadOnly();

    // aboutToBeDestroyed signal tests
    void testAboutToBeDestroyedSignal();

    // Slot tests
    void testSetValueAsSlot();
    void testSetValueAsSlotUsingConnect();

    // Bindable properties tests
    void testBindableValue();
    void testBindableValueUsingBidirectionalNotifier();
    void testBindableMin();
    void testBindableMax();
    void testBindablePresets();
    void testBindableName();
    void testBindableLabel();
    void testBindableDescription();
    void testBindableUnit();
    void testBindableTooltip();
    void testBindableVisible();
    void testBindableReadOnly();
    void testBindableIsSchemaModified();

    // ToJSON Schema tests
    void testParameterToJsonSchema();
    void testParameterToJsonSchemaWithNoNameAndEmptyParameters();
    void testParameterToJsonSchemaWithFullMetadataForFloatNumber();
    
    // ToJSON tests
    void testParameterToJson();
    void testParameterToJsonWithNoName();
    void testParameterToJsonWithDifferentValueTypes();
    
    // Value fromJSON deserialization tests
    void testParameterValueFromJson();
    void testParameterValueFromJsonWithEmptyName();
    void testParameterValueFromJsonWithNonExistentKey();
    void testParameterValueFromJsonTestingDifferentDataTypes();
    
    // Schema fromJSON schema loading tests
    void testParameterSchemaFromJson();
    void testParameterSchemaFromJsonWithEmptyName();
    void testParameterSchemaFromJsonWithNonExistentKey();
    void testParameterSchemaFromJsonEmptyObject();
    void testParameterSchemaFromJsonPartialSchemaShouldSetUnspecifiedParamtersToDefault();
    void testParameterSchemaFromJsonChangeANewRangeShouldForceANewValue();

    // fromJSON constructor tests
    void testParameterConstructorFromJsonSchemaAndValue();
    void testParameterConstructorFromJsonSchemaAndValueWithRangeClamp();
    void testParameterConstructorFromJsonSchemaOnly();
    void testParameterConstructorFromJsonValueOnly();
    void testParameterConstructorFromJsonEmptyObjects();

    // isValid() method tests
    void testParameterIsValid();

    // fromJson method tests
    void testParameterFromJson();
    void testParameterFromJsonShouldUpdateAnExistingParameter();
    void testParameterFromJsonWithInvalidSchemaShouldLeaveTheParameterUnchanged();
    void testParameterFromJsonWithInvalidValueShouldLeaveValueUnchanged();
    void testParameterFromJsonWithIncompleteSchemaShouldOverrideExisitingSchema();

    // isValueModified flag tests
    void testParameterIsValueModifiedShouldBeFalseAfterConstructor();
    void testParameterIsValueModifiedOnlyAfterWeChangeValue();
    void testParameterIsValueModifiedShouldBeFalseAfterLoadingADifferentJsonValues();
    void testParameterIsValueModifiedSholdBeFalseAfterSettingTheSameValue();

    // isSchemaModified flag tests
    void testParameterIsSchemaModifiedShouldBeFalseAfterConstructor();
    void testParameterIsSchemaModifiedOnlyAfterSchemaPropertyChanged();
    void testParameterIsSchemaModifiedNotAffectedByValueChange();
    void testParameterIsSchemaModifiedShouldBeFalseAfterLoadingFromJson();
    void testParameterIsSchemaModifiedTracksEveryPropertyAcrossMultipleChanges();

    // resetValueModifications() / resetSchemaModifications() tests
    void testParameterResetValueModifications();
    void testParameterResetValueModificationsDoesNotAffectSchema();
    void testParameterResetSchemaModifications();
    void testParameterResetSchemaModificationsDoesNotAffectValue();
    void testParameterResetSchemaModifications_MinMaxCanClampCurrentValueAsSideEffect();

    // setSchemaModified() tests
    void testParameterSetSchemaModifiedForcesTrueRegardlessOfActualChanges();
    void testParameterSetSchemaModifiedFalseCapturesCurrentStateAsNewBaseline();
    void testParameterSetSchemaModifiedOverrideClearedByResetSchemaModifications();
    void testParameterSetSchemaModifiedInteractionWithActualSchemaChanges();

    // setValueModified() tests
    void testParameterSetValueModifiedForcesTrueRegardlessOfActualChanges();
    void testParameterSetValueModifiedFalseCapturesCurrentStateAsNewBaseline();
    void testParameterSetValueModifiedOverrideClearedByResetValueModifications();
    void testParameterSetValueModifiedInteractionWithActualValueChanges();

    // QDebug operator<< tests
    void testParameterWithQDebugOperator();
    void testParameterWithQDebugOperatorWithPointer();

    // Private methods test
    void testCompareVariants();

private:

};

using namespace QtNoid::App;


void TestQtNoidAppParameter::initTestCase()
{}

void TestQtNoidAppParameter::cleanupTestCase()
{}

void TestQtNoidAppParameter::init()
{}

void TestQtNoidAppParameter::cleanup()
{}

void TestQtNoidAppParameter::testCreatingParameter()
{
    auto par = Parameter(this);
    QCOMPARE(par.isValueModified(), false);
    QCOMPARE(par.isSchemaModified(), false);


    par.setValue(123.456);
    par.setMin(-1000);
    par.setMax(1000);
    par.setName("ParameterName");
    par.setDescription("This is the first time");

    QCOMPARE(par.value(), 123.456);
    QCOMPARE(par.min(), -1000);
    QCOMPARE(par.max(), 1000);

    QCOMPARE(par.name(), "ParameterName");
    QCOMPARE(par.description(), "This is the first time");

    par.setUnit("°C");
    QCOMPARE(par.unit(), "°C");
}

void TestQtNoidAppParameter::testConstructorWithNameAndInitialValue()
{
    auto par = Parameter(456.789, "Param", this);

    QCOMPARE(par.name(), "Param");
    QCOMPARE(par.value(), 456.789);
    QCOMPARE(par.description(), QString());
    QCOMPARE(par.unit(), QString());
    QCOMPARE(par.readOnly(), false);
    QCOMPARE(par.min(), QVariant());
    QCOMPARE(par.max(), QVariant());
}

void TestQtNoidAppParameter::testConstructorWithNameDescriptionAndInitialValue()
{
    // I use __func__ as a description
    auto par = Parameter(789.123, "Param", __func__, this);

    QCOMPARE(par.name(), "Param");
    QCOMPARE(par.description(), __func__);
    QCOMPARE(par.value(), 789.123);
    QCOMPARE(par.unit(), QString());
    QCOMPARE(par.tooltip(), QString());
    QCOMPARE(par.readOnly(), false);
    QCOMPARE(par.min(), QVariant());
    QCOMPARE(par.max(), QVariant());
}

void TestQtNoidAppParameter::testUniqueId()
{
    Parameter par(this);
    // Paramter should have a uniqueID
    QVERIFY(par.uniqueId() != 0);

    Parameter newPar(par.toJsonSchema(), par.toJsonValue(), this);
    QVERIFY(par.uniqueId() != newPar.uniqueId());

    // Unique ID should be consecutive
    QCOMPARE(par.uniqueId()+1, newPar.uniqueId());
}

void TestQtNoidAppParameter::testParameterValueChanged()
{
    auto par = Parameter(1000);
    QSignalSpy spy(&par, &Parameter::valueChanged);
    QVERIFY(spy.isValid());

    // Change the value and verify the signal is emitted
    double expected = 500.00001;
    par.setValue(expected);
    QCOMPARE(spy.count(), 1);

    // check the value is the correct one
    QList<QVariant> arguments = spy.takeFirst();
    QCOMPARE(arguments.at(0).toDouble(), expected);

    // Check that the value modification doesn't touch isSchemaModified
    QCOMPARE(par.isSchemaModified(), false);
}

void TestQtNoidAppParameter::testParameterValueChangedNoEmitForSameValue()
{
    Parameter par(100);
    QSignalSpy spy(&par, &Parameter::valueChanged);

    // Same value, no activation
    par.setValue(100);
    QCOMPARE(spy.count(), 0);
}

void TestQtNoidAppParameter::testParameterMin()
{
    Parameter par(100);
    QSignalSpy spyValue(&par, &Parameter::valueChanged);
    QSignalSpy spyMin(&par, &Parameter::minChanged);
    QSignalSpy spyRange(&par, &Parameter::rangeChanged);

    // Change the min check value and range
    QVariant expected = 101;
    par.setMin(expected);
    QCOMPARE(spyValue.count(), 1);
    QCOMPARE(spyValue.takeFirst().at(0), expected);

    QCOMPARE(spyMin.count(), 1);
    QCOMPARE(spyMin.takeFirst().at(0), expected);

    QCOMPARE(spyRange.count(), 1);
    auto rangeChanged = spyRange.takeFirst();
    QCOMPARE(rangeChanged.at(0), expected);
    QCOMPARE(rangeChanged.at(1), QVariant());
}

void TestQtNoidAppParameter::testParameterMax()
{
    Parameter par(100);
    QSignalSpy spyValue(&par, &Parameter::valueChanged);
    QSignalSpy spyMax(&par, &Parameter::maxChanged);
    QSignalSpy spyRange(&par, &Parameter::rangeChanged);

    // Change the max check value and range
    QVariant expected = 99;
    par.setMax(expected);
    QCOMPARE(spyValue.count(), 1);
    QCOMPARE(spyValue.takeFirst().at(0), expected);

    QCOMPARE(spyMax.count(), 1);
    QCOMPARE(spyMax.takeFirst().at(0), expected);

    QCOMPARE(spyRange.count(), 1);
    auto rangeChanged = spyRange.takeFirst();
    QCOMPARE(rangeChanged.at(0), QVariant());
    QCOMPARE(rangeChanged.at(1), expected);
}

void TestQtNoidAppParameter::testTooltip()
{
    Parameter par(42.0, "TestParam", "A test parameter");
    QSignalSpy spy(&par, &Parameter::tooltipChanged);

    // Test initial state (should be empty)
    QCOMPARE(par.tooltip(), QString());

    // Set tooltip and verify signal emission
    par.setTooltip("This is a tooltip");
    QCOMPARE(spy.count(), 1);
    QCOMPARE(par.tooltip(), "This is a tooltip");

    // Check signal argument
    QList<QVariant> arguments = spy.takeFirst();
    QCOMPARE(arguments.at(0).toString(), "This is a tooltip");

    // Setting same value should not emit signal
    par.setTooltip("This is a tooltip");
    QCOMPARE(spy.count(), 0);

    // Change to different value
    par.setTooltip("New tooltip");
    QCOMPARE(spy.count(), 1);
    QCOMPARE(par.tooltip(), "New tooltip");
}

void TestQtNoidAppParameter::testVisible()
{
    Parameter par(42.0, "TestParam", "A test parameter");
    QSignalSpy spy(&par, &Parameter::visibleChanged);

    // Test initial state (should be true by default)
    QCOMPARE(par.visible(), true);

    // Set visible to false and verify signal emission
    par.setVisible(false);
    QCOMPARE(spy.count(), 1);
    QCOMPARE(par.visible(), false);

    // Check signal argument
    QList<QVariant> arguments = spy.takeFirst();
    QCOMPARE(arguments.at(0).toBool(), false);

    // Setting same value should not emit signal
    par.setVisible(false);
    QCOMPARE(spy.count(), 0);

    // Change back to true
    par.setVisible(true);
    QCOMPARE(spy.count(), 1);
    QCOMPARE(par.visible(), true);
}

void TestQtNoidAppParameter::testParameterSetPresets()
{
    Parameter par(100.0);
    QSignalSpy spy(&par, &Parameter::presetsChanged);

    // Test initial state (should be empty)
    QCOMPARE(par.presets(), QVariantMap());

    // Create test presets
    QVariantMap expected;
    expected["Low"] = 10.0;
    expected["Medium"] = 50.0;
    expected["High"] = 100.0;

    // Set presets and verify signal is emitted
    par.setPresets(expected);
    QCOMPARE(spy.count(), 1);
    QCOMPARE(par.presets(), expected);

    // Check signal contains the correct presets
    QList<QVariant> arguments = spy.takeFirst();
    QCOMPARE(arguments.at(0).toMap(), expected);

    // Same presets, no signal should be emitted
    par.setPresets(expected);
    QCOMPARE(spy.count(), 0);

}

void TestQtNoidAppParameter::testParameterSetPreset()
{
    Parameter par(100.0);
    QSignalSpy spy(&par, &Parameter::presetsChanged);

    par.setPreset("Low", 10.0);
    QCOMPARE(spy.count(), 1);
    QList<QVariant> arguments = spy.takeFirst();
    QCOMPARE(arguments.first(), QVariantMap({{"Low", 10.0}}));
    QCOMPARE(par.presets(), QVariantMap({{"Low", 10.0}}));

    QCOMPARE(par.preset("Low"), 10.0);

    // Testing void setPreset(const std::pair<QString, QVariant> &preset)
    par.setPreset({"High", 1000.0});
    QCOMPARE(par.preset("High"), 1000.0);

}


void TestQtNoidAppParameter::testParameterApplyPresetByName()
{
    Parameter par(50.0);
    QSignalSpy spyValue(&par, &Parameter::valueChanged);

    par.setPreset("Low", 10.0);
    par.applyPreset("Low");
    QCOMPARE(spyValue.count(), 1);
    auto newVal = spyValue.takeFirst();
    QCOMPARE(newVal.first(), 10.0);
    QCOMPARE(par.value(), 10.0);

    // Applying the same preset, there should be no changes
    par.applyPreset("Low");
    QCOMPARE(spyValue.count(), 0);

    // Preset signal isValueModified
    QCOMPARE(par.isValueModified(), true);
}

void TestQtNoidAppParameter::testParameterRemovePreset()
{
    Parameter par(100.0);

    // Set up initial presets
    par.setPreset("Low", 10.0);
    par.setPreset("Medium", 50.0);
    par.setPreset("High", 100.0);

    // Remove one preset
    QSignalSpy spy(&par, &Parameter::presetsChanged);
    par.removePreset("Medium");
    QCOMPARE(spy.count(), 1);
    
    QVariantMap expected;
    expected["Low"] = 10.0;
    expected["High"] = 100.0;
    QCOMPARE(par.presets(), expected);

    // Verify signal contains updated presets
    QList<QVariant> arguments = spy.takeFirst();
    QCOMPARE(arguments.first().toMap(), expected);

    // Remove non-existent preset should not emit signal
    par.removePreset("NonExistent");
    QCOMPARE(spy.count(), 0);
}

void TestQtNoidAppParameter::testParameterClearPreset()
{
    Parameter par(100.0);

    // Set up initial presets
    par.setPreset("Low", 10.0);
    par.setPreset("Medium", 50.0);
    par.setPreset("High", 100.0);

    // Clear all presets
    QSignalSpy spy(&par, &Parameter::presetsChanged);
    par.clearPresets();
    QCOMPARE(spy.count(), 1);
    QCOMPARE(par.presets(), QVariantMap());

    // Verify signal contains empty presets
    QList<QVariant> arguments = spy.takeFirst();
    QCOMPARE(arguments.first().toMap(), QVariantMap());

    // Clear already empty presets should not emit signal
    par.clearPresets();
    QCOMPARE(spy.count(), 0);
}

void TestQtNoidAppParameter::testParameterSetPresetShouldAbideToRangeRules()
{
    Parameter par(50.0);
    par.setRange(0.0, 100.0);
    
    // Apply preset exactly at min boundary
    par.setPreset("AtMin", 0.0);
    par.applyPreset("AtMin");
    QCOMPARE(par.value(), 0.0);

    // Apply preset exactly at max boundary
    par.setPreset("AtMax", 100.0);
    par.applyPreset("AtMax");
    QCOMPARE(par.value(), 100.0);

    // Apply preset below min range - should be clamped to min
    par.setPreset("TooLow", -10.0);
    par.applyPreset("TooLow");
    QCOMPARE(par.value(), 0.0); // Clamped to min

    // Apply preset above max range - should be clamped to max
    par.setPreset("TooHigh", 150.0);
    par.applyPreset("TooHigh");
    QCOMPARE(par.value(), 100.0); // Clamped to max
}

void TestQtNoidAppParameter::testParameterApplyPresetReadOnlyShouldBeIneffective()
{
    Parameter par(50.0, "ReadOnlyParam");
    par.setReadOnly(true);
    
    // Set up presets
    par.setPreset("Low", 10.0);
    
    // Set up signal spies
    QSignalSpy valueChangedSpy(&par, &Parameter::valueChanged);
    QSignalSpy writeAttemptSpy(&par, &Parameter::writeAttemptedWhileReadOnly);
    
    // Try to apply preset when read-only
    par.applyPreset("Low");
    // Value should change even if it is readOnly
    QCOMPARE(par.value(), 10.0);
    QCOMPARE(valueChangedSpy.count(), 1);
    
    // Try to apply the same value and there should be no errors
    valueChangedSpy.clear();
    par.setPreset("asItIsNow", par.value());
    auto res = par.applyPreset("asItIsNow");
    QCOMPARE(res, true);
    QCOMPARE(writeAttemptSpy.count(), 0);
    QCOMPARE(valueChangedSpy.count(), 0);
}

void TestQtNoidAppParameter::testParameterRange()
{
    auto par = Parameter(1000);

    // Apply Range to the value
    par.setRange(-10, 10);
    QCOMPARE(par.min(), -10);
    QCOMPARE(par.max(), 10);
    QCOMPARE(par.value(), 10);

    // Apply a value and check it is clipped to the max
    par.setValue(100);
    QCOMPARE(par.value(), 10);

    // Apply a value and check it is clipped to the min
    par.setValue(-100);
    QCOMPARE(par.value(), -10);

    // Set mixed numbers
    par.setRange(-100LL, 100);
    QCOMPARE(par.min(), -100);
    QCOMPARE(par.max(), 100);

    par.setRange(-100.123, 100);
    QCOMPARE(par.min(), -100.123);
    QCOMPARE(par.max(), 100);

    // Set mixed numbers flipped
    par.setRange(100LL, -100);
    QCOMPARE(par.min(), -100);
    QCOMPARE(par.max(), 100);

    par.setRange(100, -100.123);
    QCOMPARE(par.min(), -100.123);
    QCOMPARE(par.max(), 100);

    par.setRange(100.00, 100);
    QCOMPARE(par.min(), 100);
    QCOMPARE(par.max(), 100);
}

void TestQtNoidAppParameter::testParameterSetRangeShouldHandleFlippingMinAndMaxSoRangeWillBeConsistent()
{
    Parameter par(1000, "Par", this);

    par.setRange(1200, 10);
    QVERIFY(par.isValid());
    QCOMPARE(par.min(), 10);
    QCOMPARE(par.max(), 1200);

    auto range = par.range();
    QCOMPARE(range.first, 10);
    QCOMPARE(range.second, 1200);

    // Setting Range using std::pair
    std::pair<QVariant, QVariant> newRange({1300, 11});
    par.setRange(newRange);
    QVERIFY(par.isValid());
    QCOMPARE(par.min(), 11);
    QCOMPARE(par.max(), 1300);

    // Setting Range using schema
    QJsonObject schemaObj{{"min", 222}, {"max", 2}};
    QJsonObject schema{{"Par", schemaObj}};
    par.schemaFromJson(schema);
    range = par.range();
    QCOMPARE(range.first, 2);
    QCOMPARE(range.second, 222);
}

void TestQtNoidAppParameter::testParameterRangeIsValid()
{
    Parameter par(50.0, "TestParam", this);

    // Test case 1: No range set (both min and max are invalid) - should return false
    QCOMPARE(par.rangeIsValid(), false);

    // Test case 2: Only min set (max is invalid) - should return false
    par.setMin(0.0);
    QCOMPARE(par.rangeIsValid(), false);

    // Test case 3: Only max set (min is invalid) - should return false
    par.setMin(QVariant()); // Reset min to invalid
    par.setMax(100.0);
    QCOMPARE(par.rangeIsValid(), false);

    // Test case 4: Valid range with min < max - should return true
    par.setMin(0.0);
    par.setMax(100.0);
    QCOMPARE(par.rangeIsValid(), true);

    // Test case 5: Valid range with min = max - should return true
    par.setRange(0, 0);
    QCOMPARE(par.rangeIsValid(), false);
    par.setRange(50.0, 50.0);
    QCOMPARE(par.rangeIsValid(), false);

    // Test case 6: Invalid range with min > max - should return false
    // because there is no control in consinstency
    par.setMin(100.0);
    par.setMax(0.0);
    QCOMPARE(par.rangeIsValid(), false);

    // Test case 7: Test with string ranges
    Parameter parString("middle", "StringParam", this);
    QCOMPARE(parString.rangeIsValid(), false); // No range set

    parString.setRange("a", "z");
    QCOMPARE(parString.rangeIsValid(), true); // Valid string range

    // Range sequence is automatically adjusted by setRange()
    parString.setRange("z", "a");
    QCOMPARE(parString.rangeIsValid(), true);

    // Test case 8: Test with negative numbers
    Parameter parNegative(-50.0, "NegativeParam", this);
    parNegative.setRange(-100.0, -10.0);
    QCOMPARE(parNegative.rangeIsValid(), true);

    parNegative.setRange(-10.0, -100.0);
    QCOMPARE(parNegative.rangeIsValid(), true);

    // Test case 9: Test edge case across zero
    Parameter parZero(0.0, "ZeroParam", this);
    parZero.setRange(-1.0, 1.0);
    QCOMPARE(parZero.rangeIsValid(), true);

    // Range sequence is automatically adjusted by setRange()
    parZero.setRange(1.0, -1.0);
    QCOMPARE(parZero.rangeIsValid(), true);
}

void TestQtNoidAppParameter::testParameterName()
{
    Parameter par(12500, "EarthRadius");
    QSignalSpy spy1(&par, &Parameter::nameChanged);
    QSignalSpy spy2(&par, &Parameter::nameEdited);

    par.setName("EarthDiameter");
    QCOMPARE(spy1.count(), 1);
    QCOMPARE(spy2.count(), 1);

    // check the value is the correct one
    QList<QVariant> arguments = spy1.takeFirst();
    QCOMPARE(arguments.at(0).toString(), "EarthDiameter");
    arguments = spy2.takeFirst();
    QCOMPARE(arguments.at(0).toString(), "EarthRadius");
    QCOMPARE(arguments.at(1).toString(), "EarthDiameter");

    // Same value, no activation
    par.setName("EarthDiameter");
    QCOMPARE(spy1.count(), 0);
    QCOMPARE(spy2.count(), 0);
}

void TestQtNoidAppParameter::testParameterLabel()
{
    Parameter par;
    QSignalSpy spy(&par, &Parameter::labelChanged);

    // Test initial state (should be empty)
    QCOMPARE(par.label(), QString());

    par.setLabel("Temperature");
    QCOMPARE(spy.count(), 1);

    // check the value is the correct one
    QList<QVariant> arguments = spy.takeFirst();
    QCOMPARE(arguments.at(0).toString(), "Temperature");
    QCOMPARE(par.label(), "Temperature");

    // Same value, no activation
    par.setLabel("Temperature");
    QCOMPARE(spy.count(), 0);
}

void TestQtNoidAppParameter::testParameterDescription()
{
    Parameter par(12500, "EarthDiameter", "this is the Earth diameter", this);
    QSignalSpy spy(&par, &Parameter::descriptionChanged);

    par.setDescription("this is the Earth diameter in km");
    QCOMPARE(spy.count(), 1);

    // check the value is the correct one
    QList<QVariant> arguments = spy.takeFirst();
    QCOMPARE(arguments.at(0).toString(), "this is the Earth diameter in km");

    // Same value, no activation
    par.setDescription("this is the Earth diameter in km");
    QCOMPARE(spy.count(), 0);
}

void TestQtNoidAppParameter::testParameterUnit()
{
    Parameter par(25.0, "Temperature", "Current temperature", this);
    QSignalSpy spy(&par, &Parameter::unitChanged);

    par.setUnit("°C");
    QCOMPARE(spy.count(), 1);

    // check the value is the correct one
    QList<QVariant> arguments = spy.takeFirst();
    QCOMPARE(arguments.at(0).toString(), "°C");

    // Same value, no activation
    par.setUnit("°C");
    QCOMPARE(spy.count(), 0);
}

void TestQtNoidAppParameter::testParameterTooltip()
{
    Parameter par(25.0, "Temperature", "Current temperature", this);
    QSignalSpy spy(&par, &Parameter::tooltipChanged);

    // Test initial state (should be empty)
    QCOMPARE(par.tooltip(), QString());

    par.setTooltip("This shows the current temperature reading");
    QCOMPARE(spy.count(), 1);

    // check the value is the correct one
    QList<QVariant> arguments = spy.takeFirst();
    QCOMPARE(arguments.at(0).toString(), "This shows the current temperature reading");
    QCOMPARE(par.tooltip(), "This shows the current temperature reading");

    // Same value, no activation
    par.setTooltip("This shows the current temperature reading");
    QCOMPARE(spy.count(), 0);
}

void TestQtNoidAppParameter::testParameterReadOnly()
{
    Parameter par(100.0, "ReadOnlyParamName", "Test parameter", this);
    
    // Test initial state (should be writable)
    QCOMPARE(par.readOnly(), false);
    
    // Test setting readOnly property
    QSignalSpy readOnlyChangeSpy(&par, &Parameter::readOnlyChanged);
    par.setReadOnly(true);
    QCOMPARE(readOnlyChangeSpy.count(), 1);
    QCOMPARE(par.readOnly(), true);
    
    // Test that setValue emits writeAttemptedWhileReadOnly signal when readOnly
    QSignalSpy writeAttemptSpy(&par, &Parameter::writeAttemptedWhileReadOnly);
    QSignalSpy valueChangeSpy(&par, &Parameter::valueChanged);
    
    par.setValue(200.0);
    QCOMPARE(writeAttemptSpy.count(), 1);

    // Signal contains the parameter name
    QList<QVariant> arguments = writeAttemptSpy.takeFirst();
    QCOMPARE(arguments.at(0).toString(), "ReadOnlyParamName");

    QCOMPARE(valueChangeSpy.count(), 0);
    QCOMPARE(par.value(), 100.0); // Value should not change
    

    // Changing max should not change the value and signal writeAttemptedWhileReadOnly
    writeAttemptSpy.clear();
    par.setMax(10);
    QCOMPARE(writeAttemptSpy.count(), 1);
    QCOMPARE(par.value(), 100.0); // Value should not change

    // Changing min should not change the value and signal writeAttemptedWhileReadOnly
    writeAttemptSpy.clear();
    par.setMin(2000);
    QCOMPARE(writeAttemptSpy.count(), 1);
    QCOMPARE(par.value(), 100.0); // Value should not change


    // Test that setValue works normally when readOnly is false
    writeAttemptSpy.clear();
    par.setReadOnly(false);
    // qDebug() << "setReadOnly" << valueChangeSpy.count() << par.value();
    par.setRange(0, 400);
    // qDebug() << "setRange" << valueChangeSpy.count() << par.value();
    par.setValue(300.0);
    // qDebug() << "setValue" <<  valueChangeSpy.count()  << par.value();


    QCOMPARE(writeAttemptSpy.count(), 0); // No additional signal
    QCOMPARE(valueChangeSpy.count(), 1);
    QCOMPARE(par.value(), 300.0);
}

void TestQtNoidAppParameter::testAboutToBeDestroyedSignal()
{
    auto par = new Parameter(100, "TestParam");

    // Capture the address as a plain integer *before* deleting: a void* (or
    // Parameter*) alias of freed memory still trips
    // clang-analyzer-cplusplus.NewDelete on any later read, even a
    // non-dereferencing comparison. quintptr breaks that pointer-provenance
    // tracking while still verifying the same identity.
    const quintptr expectedAddress = reinterpret_cast<quintptr>(par);

    QSignalSpy spy(par, &Parameter::aboutToBeDestroyed);
    QVERIFY(spy.isValid());

    delete par;

    QCOMPARE(spy.count(), 1);
    QList<QVariant> arguments = spy.takeFirst();
    QCOMPARE(reinterpret_cast<quintptr>(arguments.at(0).value<Parameter*>()), expectedAddress);
}


void TestQtNoidAppParameter::testSetValueAsSlot()
{
    Parameter par(100.0, "TestParam", this);
    QCOMPARE(par.value(), 100.0);

    QSignalSpy valueChangedSpy(&par, &Parameter::valueChanged);

    // Directly Call the slot with a new value
    QVariant newValue = 250.0;
    par.setValue(newValue);

    // Verify the value was changed
    QCOMPARE(par.value(), 250.0);
    QCOMPARE(valueChangedSpy.count(), 1);

    // Check that the signal was emitted with the correct argument
    QList<QVariant> arguments = valueChangedSpy.takeFirst();
    QCOMPARE(arguments.at(0), newValue);

    // Test with a string value
    QVariant stringValue = "TestString";
    par.setValue(stringValue);
    QCOMPARE(par.value(), stringValue);
    QCOMPARE(valueChangedSpy.count(), 1);
    arguments = valueChangedSpy.takeFirst();
    QCOMPARE(arguments.at(0), stringValue);

    // Test with the same value should not fire valueChanged
    par.setValue(stringValue);
    QCOMPARE(par.value(), stringValue);
    QCOMPARE(valueChangedSpy.count(), 0);

    // Test slot with range constraints
    par.setValue(50.0);
    par.setRange(0.0, 100.0);
    valueChangedSpy.clear();

    // Call slot with value that should be clamped
    par.setValue(150.0);
    QCOMPARE(par.value(), 100.0); // Should be clamped to max
    QCOMPARE(valueChangedSpy.count(), 1);

    // Call slot with value below minimum
    valueChangedSpy.clear();
    par.setValue(-10.0);
    QCOMPARE(par.value(), 0.0); // Should be clamped to min
    QCOMPARE(valueChangedSpy.count(), 1);

    // Test slot behavior with read-only parameter
    par.setReadOnly(true);
    QSignalSpy writeAttemptSpy(&par, &Parameter::writeAttemptedWhileReadOnly);
    valueChangedSpy.clear();
    par.setValue(75.0);
    QCOMPARE(par.value(), 0.0); // Value should not change when read-only
    QCOMPARE(valueChangedSpy.count(), 0);
    QCOMPARE(writeAttemptSpy.count(), 1);
    QList<QVariant> writeAttemptArgs = writeAttemptSpy.takeFirst();
    // Verify the writeAttemptedWhileReadOnly signal contains the parameter name
    QCOMPARE(writeAttemptArgs.at(0).toString(), "TestParam");
}

void TestQtNoidAppParameter::testSetValueAsSlotUsingConnect()
{
    Parameter parLeader(100.0, this);
    QCOMPARE(parLeader.value(), 100.0);

    // Create a follower object and
    Parameter parFollower(10.0, this);
    QCOMPARE(parFollower.value(), 10.0);
    QSignalSpy valueChangedSpy(&parFollower, &Parameter::valueChanged);
    connect(&parLeader, &Parameter::valueChanged, &parFollower, &Parameter::setValue);

    parLeader.setValue(123.0);
    QCOMPARE(parFollower.value(), 123.0);
}

void TestQtNoidAppParameter::testBindableValue()
{
    Parameter par(100.0, this);
    
    // Get bindable value
    auto bindableValue = par.bindableValue();
    QVERIFY(bindableValue.isValid());
    
    // Test binding to another QProperty
    QProperty<QVariant> externalProperty;
    externalProperty.setBinding([&]() { return par.bindableValue().value(); });
    QCOMPARE(externalProperty.value(), 100.0);
    
    // Change parameter value and verify binding updates
    par.setValue(200.0);
    QCOMPARE(externalProperty.value(), 200.0);
    
    // Test setting value through bindable
    bindableValue.setValue(300.0);
    QCOMPARE(par.value(), 300.0);
    QCOMPARE(externalProperty.value(), 300.0);
}

void TestQtNoidAppParameter::testBindableValueUsingBidirectionalNotifier()
{
    Parameter par(1.0, this);
    QProperty<QVariant> prop(2.0);

    auto propNotifier = prop.addNotifier([&]{
        // qDebug() << "prop changed -> " << prop.value();
        par.setValue(prop.value());
    });

    auto parNotifier = par.bindableValue().addNotifier([&]{
        // qDebug() << "par changed -> " << par.value();
        prop.setValue(par.value());
    });
    //  Change the property and check the parameter
    prop.setValue(123);
    QCOMPARE(par.value(), 123);
    //  Change the parameter and check the property
    par.setValue(456);
    QCOMPARE(prop.value(), 456);
}

void TestQtNoidAppParameter::testBindableMin()
{
    Parameter par(50.0, this);
    
    // Get bindable min
    auto bindableMin = par.bindableMin();
    QVERIFY(bindableMin.isValid());
    QCOMPARE(bindableMin.value(), QVariant());
    
    // Test binding to another QProperty
    QProperty<QVariant> externalProperty;
    externalProperty.setBinding([&]() { return par.bindableMin().value(); });
    QCOMPARE(externalProperty.value(), QVariant());
    
    // Change parameter min and verify binding updates
    par.setMin(10.0);
    QCOMPARE(externalProperty.value(), 10.0);
    
    // Test setting min through bindable
    bindableMin.setValue(5.0);
    QCOMPARE(par.min(), 5.0);
    QCOMPARE(externalProperty.value(), 5.0);
}

void TestQtNoidAppParameter::testBindableMax()
{
    Parameter par(50.0, this);
    
    // Get bindable max
    auto bindableMax = par.bindableMax();
    QVERIFY(bindableMax.isValid());
    QCOMPARE(bindableMax.value(), QVariant());
    
    // Test binding to another QProperty
    QProperty<QVariant> externalProperty;
    externalProperty.setBinding([&]() { return par.bindableMax().value(); });
    QCOMPARE(externalProperty.value(), QVariant());
    
    // Change parameter max and verify binding updates
    par.setMax(100.0);
    QCOMPARE(externalProperty.value(), 100.0);
    
    // Test setting max through bindable
    bindableMax.setValue(200.0);
    QCOMPARE(par.max(), 200.0);
    QCOMPARE(externalProperty.value(), 200.0);
}

void TestQtNoidAppParameter::testBindablePresets()
{
    Parameter par(50.0, this);
    
    // Get bindable presets
    auto bindablePresets = par.bindablePresets();
    QVERIFY(bindablePresets.isValid());
    QCOMPARE(bindablePresets.value(), QVariantMap());
    
    // Test binding to another QProperty
    QProperty<QVariantMap> externalProperty;
    externalProperty.setBinding([&]() { return par.bindablePresets().value(); });
    QCOMPARE(externalProperty.value(), QVariantMap());
    
    // Change parameter presets and verify binding updates
    QVariantMap testPresets;
    testPresets["Low"] = 10.0;
    testPresets["High"] = 90.0;
    par.setPresets(testPresets);
    QCOMPARE(externalProperty.value(), testPresets);
    
    // Test setting presets through bindable
    QVariantMap newPresets;
    newPresets["Medium"] = 50.0;
    bindablePresets.setValue(newPresets);
    QCOMPARE(par.presets(), newPresets);
    QCOMPARE(externalProperty.value(), newPresets);
}

void TestQtNoidAppParameter::testBindableName()
{
    Parameter par(50.0, "TestParam", this);
    
    // Get bindable name
    auto bindableName = par.bindableName();
    QVERIFY(bindableName.isValid());
    QCOMPARE(bindableName.value(), "TestParam");
    
    // Test binding to another QProperty
    QProperty<QString> externalProperty;
    externalProperty.setBinding([&]() { return par.bindableName().value(); });
    QCOMPARE(externalProperty.value(), "TestParam");
    
    // Change parameter name and verify binding updates
    par.setName("NewName");
    QCOMPARE(externalProperty.value(), "NewName");
    
    // Test setting name through bindable
    bindableName.setValue("FinalName");
    QCOMPARE(par.name(), "FinalName");
    QCOMPARE(externalProperty.value(), "FinalName");
}

void TestQtNoidAppParameter::testBindableLabel()
{
    Parameter par;

    // Get bindable label
    auto bindableLabel = par.bindableLabel();
    QVERIFY(bindableLabel.isValid());
    QCOMPARE(bindableLabel.value(), QString());

    // Test binding to another QProperty
    QProperty<QString> externalProperty;
    externalProperty.setBinding([&]() { return par.bindableLabel().value(); });
    QCOMPARE(externalProperty.value(), QString());

    // Change parameter label and verify binding updates
    par.setLabel("Rain");
    QCOMPARE(externalProperty.value(), "Rain");

    // Test setting label through bindable
    bindableLabel.setValue("Snow");
    QCOMPARE(par.label(), "Snow");
    QCOMPARE(externalProperty.value(), "Snow");
}

void TestQtNoidAppParameter::testBindableDescription()
{
    Parameter par(50.0, "TestParam", "Initial description", this);
    
    // Get bindable description
    auto bindableDescription = par.bindableDescription();
    QVERIFY(bindableDescription.isValid());
    QCOMPARE(bindableDescription.value(), "Initial description");
    
    // Test binding to another QProperty
    QProperty<QString> externalProperty;
    externalProperty.setBinding([&]() { return par.bindableDescription().value(); });
    QCOMPARE(externalProperty.value(), "Initial description");
    
    // Change parameter description and verify binding updates
    par.setDescription("Updated description");
    QCOMPARE(externalProperty.value(), "Updated description");
    
    // Test setting description through bindable
    bindableDescription.setValue("Final description");
    QCOMPARE(par.description(), "Final description");
    QCOMPARE(externalProperty.value(), "Final description");
}

void TestQtNoidAppParameter::testBindableUnit()
{
    Parameter par(25.0, "Temperature", this);

    // Get bindable unit
    auto bindableUnit = par.bindableUnit();
    QVERIFY(bindableUnit.isValid());
    QCOMPARE(bindableUnit.value(), QString());

    // Test binding to another QProperty
    QProperty<QString> externalProperty;
    externalProperty.setBinding([&]() { return par.bindableUnit().value(); });
    QCOMPARE(externalProperty.value(), QString());

    // Change parameter unit and verify binding updates
    par.setUnit("°C");
    QCOMPARE(externalProperty.value(), "°C");

    // Test setting unit through bindable
    bindableUnit.setValue("°F");
    QCOMPARE(par.unit(), "°F");
    QCOMPARE(externalProperty.value(), "°F");
}

void TestQtNoidAppParameter::testBindableTooltip()
{
    Parameter par(25.0, "Temperature", this);

    // Get bindable tooltip
    auto bindableTooltip = par.bindableTooltip();
    QVERIFY(bindableTooltip.isValid());
    QCOMPARE(bindableTooltip.value(), QString());

    // Test binding to another QProperty
    QProperty<QString> externalProperty;
    externalProperty.setBinding([&]() { return par.bindableTooltip().value(); });
    QCOMPARE(externalProperty.value(), QString());

    // Change parameter tooltip and verify binding updates
    par.setTooltip("Temperature sensor reading");
    QCOMPARE(externalProperty.value(), "Temperature sensor reading");

    // Test setting tooltip through bindable
    bindableTooltip.setValue("Updated tooltip");
    QCOMPARE(par.tooltip(), "Updated tooltip");
    QCOMPARE(externalProperty.value(), "Updated tooltip");
}

void TestQtNoidAppParameter::testBindableVisible()
{
    Parameter par(50.0, "TestParam", this);

    // Get bindable visible
    auto bindableVisible = par.bindableVisible();
    QVERIFY(bindableVisible.isValid());
    QCOMPARE(bindableVisible.value(), true);

    // Test binding to another QProperty
    QProperty<bool> externalProperty;
    externalProperty.setBinding([&]() { return par.bindableVisible().value(); });
    QCOMPARE(externalProperty.value(), true);

    // Change parameter visible and verify binding updates
    par.setVisible(false);
    QCOMPARE(externalProperty.value(), false);

    // Test setting visible through bindable
    bindableVisible.setValue(true);
    QCOMPARE(par.visible(), true);
    QCOMPARE(externalProperty.value(), true);
}

void TestQtNoidAppParameter::testBindableReadOnly()
{
    Parameter par(50.0, "TestParam", this);
    
    // Get bindable readOnly
    auto bindableReadOnly = par.bindableReadOnly();
    QVERIFY(bindableReadOnly.isValid());
    QCOMPARE(bindableReadOnly.value(), false);
    
    // Test binding to another QProperty
    QProperty<bool> externalProperty;
    externalProperty.setBinding([&]() { return par.bindableReadOnly().value(); });
    QCOMPARE(externalProperty.value(), false);
    
    // Change parameter readOnly and verify binding updates
    par.setReadOnly(true);
    QCOMPARE(externalProperty.value(), true);
    
    // Test setting readOnly through bindable
    bindableReadOnly.setValue(false);
    QCOMPARE(par.readOnly(), false);
    QCOMPARE(externalProperty.value(), false);
}

void TestQtNoidAppParameter::testBindableIsSchemaModified()
{
    Parameter par(50.0, "TestParam", this);

    auto bindableIsSchemaModified = par.bindableIsSchemaModified();
    QVERIFY(bindableIsSchemaModified.isValid());
    QCOMPARE(bindableIsSchemaModified.value(), false);

    // Test binding to another QProperty
    QProperty<bool> externalProperty;
    externalProperty.setBinding([&]() { return par.bindableIsSchemaModified().value(); });
    QCOMPARE(externalProperty.value(), false);

    // A value change must not affect isSchemaModified's bindable
    par.setValue(99.0);
    QCOMPARE(externalProperty.value(), false);

    // Change a schema property and verify binding updates
    par.setLabel("New label");
    QCOMPARE(externalProperty.value(), true);

    par.resetSchemaModifications();
    QCOMPARE(externalProperty.value(), false);
}

void TestQtNoidAppParameter::testParameterToJsonSchema()
{
    Parameter par(50.0, "Log File Size", "Parameter description", this);

    par.setUnit("kB");
    par.setMin(0.0);
    par.setMax(100.0);
    par.setPreset("Small", 2.0);
    par.setPreset("Large", 90.0);
    par.setTooltip("Size of the log file on disk");
    par.setReadOnly(true);
    par.setVisible(false);
    
    QJsonObject schema = par.toJsonSchema();
    
    QVERIFY(schema.contains("Log File Size"));
    QJsonObject paramSchema = schema["Log File Size"].toObject();

    QCOMPARE(paramSchema["min"].toVariant(), QVariant(0.0));
    QCOMPARE(paramSchema["max"].toVariant(), QVariant(100.0));
    QCOMPARE(paramSchema["description"].toString(), "Parameter description");
    QCOMPARE(paramSchema["unit"].toString(), "kB");
    QCOMPARE(paramSchema["tooltip"].toString(), "Size of the log file on disk");
    QCOMPARE(paramSchema["readOnly"].toBool(), true);
    QCOMPARE(paramSchema["visible"].toBool(), false);

    QVERIFY(paramSchema.contains("presets"));
    QJsonArray presetArray = paramSchema["presets"].toArray();
    QHash<QString, QVariant> presetMap;

    for(auto it = presetArray.constBegin(); it != presetArray.constEnd(); ++it) {
        QJsonObject element = it->toObject();
        QString key = element.begin().key();
        QVariant value = element.begin().value().toVariant();
        presetMap.emplace(key, value);
    }
    QCOMPARE(presetMap["Small"], QVariant(2.0));
    QCOMPARE(presetMap["Large"], QVariant(90.0));
}

void TestQtNoidAppParameter::testParameterToJsonSchemaWithNoNameAndEmptyParameters()
{
    Parameter par(42.0);
    
    QJsonObject schema = par.toJsonSchema();
    
    QVERIFY(schema.contains("Name"));
    QJsonObject paramSchema = schema["Name"].toObject();
    
    QCOMPARE(paramSchema["description"].toString(), QString());
    QCOMPARE(paramSchema["unit"].toString(), QString());
    QCOMPARE(paramSchema["tooltip"].toString(), QString());
    QCOMPARE(paramSchema["readOnly"].toBool(), false);
    QVERIFY(paramSchema["min"].isNull());
    QVERIFY(paramSchema["max"].isNull());
    QCOMPARE(paramSchema.contains("presets"), false);
}

void TestQtNoidAppParameter::testParameterToJsonSchemaWithFullMetadataForFloatNumber()
{
    Parameter par;
    par.setValue(75.5);
    par.setUnit("°C");
    par.setMin(-273.15);
    par.setMax(1000.0);
    par.setPreset("A_Large", 90.0);
    par.setPreset("B_Small", 2.0);
    par.setName("ComplexParam");
    par.setLabel("CP");
    par.setDescription("A complex parameter with all metadata");
    par.setTooltip("tooltip");
    par.setReadOnly(true);
    par.setVisible(true);

    QJsonObject schema = par.toJsonSchema();
    
    QVERIFY(schema.contains("ComplexParam"));
    QJsonObject paramSchema = schema["ComplexParam"].toObject();

    // value is not part of the schema
    QCOMPARE(paramSchema["unit"].toString(), "°C");
    QCOMPARE(paramSchema["min"].toVariant(), QVariant(-273.15));
    QCOMPARE(paramSchema["max"].toVariant(), QVariant(1000.0));
    QCOMPARE(paramSchema.contains("presets"), true);
    QJsonArray presetArray = paramSchema["presets"].toArray();
    QCOMPARE(presetArray.at(0), QJsonValue(QJsonObject{{"A_Large", 90}}));
    QCOMPARE(presetArray.at(1), QJsonValue(QJsonObject{{"B_Small", 2.0}}));
    QCOMPARE(paramSchema["label"].toString(), "CP");
    QCOMPARE(paramSchema["description"].toString(), "A complex parameter with all metadata");
    QCOMPARE(paramSchema["tooltip"].toString(), "tooltip");
    QCOMPARE(paramSchema["readOnly"].toBool(), true);
    QCOMPARE(paramSchema["visible"].toBool(), true);
}

void TestQtNoidAppParameter::testParameterToJson()
{
    Parameter par(25.5, "Temperature", "Current temperature", this);
    
    QJsonObject json = par.toJsonValue();
    // qDebug() << __func__ << json;
    
    QVERIFY(json.contains("Temperature"));
    QCOMPARE(json["Temperature"].toVariant(), QVariant(25.5));
    QCOMPARE(json.size(), 1);
}

void TestQtNoidAppParameter::testParameterToJsonWithNoName()
{
    Parameter par(42.0);
    
    QJsonObject json = par.toJsonValue();
    // qDebug() << __func__ << json;

    QVERIFY(json.contains("Name"));
    QCOMPARE(json["Name"].toVariant(), QVariant(42.0));
    QCOMPARE(json.size(), 1);
}

void TestQtNoidAppParameter::testParameterToJsonWithDifferentValueTypes()
{
    // Test with integer
    Parameter parInt(100, "IntParam", this);
    QJsonObject jsonInt = parInt.toJsonValue();
    QVERIFY(jsonInt.contains("IntParam"));
    QCOMPARE(jsonInt["IntParam"].toVariant(), QVariant(100));
    
    // Test with string
    Parameter parString("Hello World", "StringParam", this);
    QJsonObject jsonString = parString.toJsonValue();
    QVERIFY(jsonString.contains("StringParam"));
    QCOMPARE(jsonString["StringParam"].toVariant(), QVariant("Hello World"));
    
    // Test with boolean
    Parameter parBool(true, "BoolParam", this);
    QJsonObject jsonBool = parBool.toJsonValue();
    QVERIFY(jsonBool.contains("BoolParam"));
    QCOMPARE(jsonBool["BoolParam"].toVariant(), QVariant(true));
    
    // Test with negative double
    Parameter parNegative(-123.456, "NegativeParam", this);
    QJsonObject jsonNegative = parNegative.toJsonValue();
    QVERIFY(jsonNegative.contains("NegativeParam"));
    QCOMPARE(jsonNegative["NegativeParam"].toVariant(), QVariant(-123.456));
}

void TestQtNoidAppParameter::testParameterValueFromJson()
{
    Parameter par(25.0, "Temperature", this);
    QSignalSpy spy(&par, &Parameter::valueChanged);
    
    QJsonObject json;
    json["Temperature"] = 30.5;
    
    QCOMPARE(par.valueFromJson(json), true);
    QCOMPARE(par.value(), 30.5);
    QCOMPARE(par.isValueModified(), false);
    QCOMPARE(spy.count(), 1);

    QList<QVariant> arguments = spy.takeFirst();
    QCOMPARE(arguments.at(0).toDouble(), 30.5);
}

void TestQtNoidAppParameter::testParameterValueFromJsonWithEmptyName()
{
    Parameter par(42.0);  // No name set
    QSignalSpy spy(&par, &Parameter::valueChanged);
    QSignalSpy nameSpy(&par, &Parameter::nameChanged);
    
    QJsonObject json;
    json["NewParameterName"] = 100.0;
    
    QCOMPARE(par.valueFromJson(json), true);
    QCOMPARE(par.value(), 100.0);
    QCOMPARE(par.name(), "NewParameterName");
    QCOMPARE(par.isValueModified(), false);
    QCOMPARE(spy.count(), 1);
    QCOMPARE(nameSpy.count(), 1);
}

void TestQtNoidAppParameter::testParameterValueFromJsonWithNonExistentKey()
{
    Parameter par(25.0, "Temperature", this);
    QSignalSpy spy(&par, &Parameter::valueChanged);
    
    QJsonObject json;
    json["Pressure"] = 1013.25;
    
    QCOMPARE(par.valueFromJson(json), false);
    QCOMPARE(par.value(), 25.0);  // Value should not change
    QCOMPARE(par.isValueModified(), false);
    QCOMPARE(spy.count(), 0);     // No signal should be emitted
}

void TestQtNoidAppParameter::testParameterValueFromJsonTestingDifferentDataTypes()
{
    // Test with integer
    Parameter parInt(50, "IntParam", this);
    QJsonObject jsonInt;
    jsonInt["IntParam"] = 100;
    QCOMPARE(parInt.valueFromJson(jsonInt), true);
    QCOMPARE(parInt.value().toInt(), 100);

    // Test with float
    Parameter parDouble(50.2, "DoubleParam", this);
    QJsonObject jsonDouble;
    jsonDouble["DoubleParam"] = 100.5;
    QCOMPARE(parDouble.valueFromJson(jsonDouble), true);
    QCOMPARE(parDouble.value().toDouble(), 100.5);

    // Test with string
    Parameter parString("initial", "StringParam", this);
    QJsonObject jsonString;
    jsonString["StringParam"] = "updated";
    QCOMPARE(parString.valueFromJson(jsonString), true);
    QCOMPARE(parString.value().toString(), "updated");
    
    // Test with boolean
    Parameter parBool(false, "BoolParam", this);
    QJsonObject jsonBool;
    jsonBool["BoolParam"] = true;
    QCOMPARE(parBool.valueFromJson(jsonBool), true);
    QCOMPARE(parBool.value().toBool(), true);
}

void TestQtNoidAppParameter::testParameterConstructorFromJsonSchemaAndValue()
{
    // Create schema and value JSON objects
    QJsonObject preset1{{"Winter", -10}};
    QJsonObject preset2{{"Summer", +20}};
    QJsonArray presetArray{preset1, preset2};
    QJsonObject temperatureSchema;
    temperatureSchema["presets"] = presetArray;
    temperatureSchema["description"] = "Current temperature";
    temperatureSchema["unit"] = "°C";
    temperatureSchema["tooltip"] = "Temperature sensor reading in Celsius";
    temperatureSchema["readOnly"] = false;
    temperatureSchema["min"] = -273.15;
    temperatureSchema["max"] = 1000.0;
    QJsonObject schema;
    schema["Temperature"] = temperatureSchema;
    
    // qDebug() << schema;

    QJsonObject value;
    value["Temperature"] = 25.5;
    
    // Create parameter from JSON
    Parameter par(schema, value, this);

    // Verify all properties were set correctly
    QCOMPARE(par.name(), "Temperature");
    QCOMPARE(par.description(), "Current temperature");
    QCOMPARE(par.unit(), "°C");
    QCOMPARE(par.tooltip(), "Temperature sensor reading in Celsius");
    QCOMPARE(par.readOnly(), false);
    QCOMPARE(par.min().toDouble(), -273.15);
    QCOMPARE(par.max().toDouble(), 1000.0);
    QCOMPARE(par.value().toDouble(), 25.5);
    QCOMPARE(par.isValueModified(), false);
    QCOMPARE(par.isSchemaModified(), false);

    QVariantMap expected({preset1.toVariantMap()});
    expected.insert(preset2.toVariantMap());
    QCOMPARE(par.presets(), expected);
}

void TestQtNoidAppParameter::testParameterConstructorFromJsonSchemaAndValueWithRangeClamp()
{
    QJsonObject temperatureSchema;
    temperatureSchema["max"] = 0;

    QJsonObject schema;
    schema["Temperature"] = temperatureSchema;

    QJsonObject value;
    value["Temperature"] = 25.5;

    Parameter par(schema, value, this);

    QCOMPARE(par.value(), 0);
    QCOMPARE(par.isValid(), true);
    QCOMPARE(par.isValueModified(), true);
    QCOMPARE(par.isSchemaModified(), false);

}

void TestQtNoidAppParameter::testParameterConstructorFromJsonSchemaOnly()
{
    // Create schema without value
    QJsonObject schema;
    QJsonObject pressureSchema;
    pressureSchema["description"] = "Atmospheric pressure";
    pressureSchema["unit"] = "hPa";
    pressureSchema["readOnly"] = true;
    pressureSchema["min"] = 800.0;
    pressureSchema["max"] = 1100.0;
    schema["Pressure"] = pressureSchema;
    
    // Create parameter from schema only
    Parameter par(schema, QJsonObject(), this);
    
    // Verify schema properties were set
    QCOMPARE(par.name(), "Pressure");
    QCOMPARE(par.description(), "Atmospheric pressure");
    QCOMPARE(par.unit(), "hPa");
    QCOMPARE(par.readOnly(), true);
    QCOMPARE(par.min().toDouble(), 800.0);
    QCOMPARE(par.max().toDouble(), 1100.0);
    
    // Value should be invalid/empty since no value was provided
    QVERIFY(!par.value().isValid());

    QCOMPARE(par.isSchemaModified(), false);
}

void TestQtNoidAppParameter::testParameterConstructorFromJsonValueOnly()
{
    // Create value without schema
    QJsonObject value;
    value["Voltage"] = 12.5;
    
    // Create parameter from value only
    Parameter par({}, value, this);
    
    // Verify name and value were set
    QCOMPARE(par.name(), "Voltage");
    QCOMPARE(par.value().toDouble(), 12.5);
    QCOMPARE(par.isValueModified(), false);

    // Other properties should be default values
    QCOMPARE(par.description(), QString());
    QCOMPARE(par.unit(), QString());
    QCOMPARE(par.tooltip(), QString());
    QCOMPARE(par.readOnly(), false);
    QVERIFY(!par.min().isValid());
    QVERIFY(!par.max().isValid());

    QCOMPARE(par.isValueModified(), false);
    QCOMPARE(par.isSchemaModified(), false);
}

void TestQtNoidAppParameter::testParameterConstructorFromJsonEmptyObjects()
{
    // Create parameter from empty objects
    Parameter par(QJsonObject(), QJsonObject(), this);
    
    // All properties should be default values
    QCOMPARE(par.name(), QString());
    QCOMPARE(par.description(), QString());
    QCOMPARE(par.unit(), QString());
    QCOMPARE(par.tooltip(), QString());
    QCOMPARE(par.readOnly(), false);
    QVERIFY(!par.min().isValid());
    QVERIFY(!par.max().isValid());
    QVERIFY(!par.value().isValid());
    QCOMPARE(par.isValueModified(), false);
    QCOMPARE(par.isSchemaModified(), false);
}

void TestQtNoidAppParameter::testParameterSchemaFromJson()
{
    Parameter par(20.0, "Temperature", this);
    
    // Create schema JSON
    QJsonObject schema;
    QJsonObject temperatureSchema;
    temperatureSchema["description"] = "Current temperature";
    temperatureSchema["unit"] = "°C";
    temperatureSchema["tooltip"] = "Displays the current temperature from the sensor";
    temperatureSchema["readOnly"] = true;
    temperatureSchema["min"] = -50.0;
    temperatureSchema["max"] = 100.0;
    temperatureSchema["label"] = "T°C";
    
    QJsonObject preset1{{"Low", -40}};
    QJsonObject preset2{{"High", 90}};
    QJsonArray presetArray{preset1, preset2};
    temperatureSchema["presets"] = presetArray;
    schema["Temperature"] = temperatureSchema;

    // Apply schema to parameter
    bool result = par.schemaFromJson(schema);
    QCOMPARE(result, true);
    QCOMPARE(par.isValueModified(), false);
    
    // Verify all schema properties were applied
    QCOMPARE(par.name(), "Temperature");
    QCOMPARE(par.description(), "Current temperature");
    QCOMPARE(par.unit(), "°C");
    QCOMPARE(par.tooltip(), "Displays the current temperature from the sensor");
    QCOMPARE(par.readOnly(), true);
    QCOMPARE(par.min().toDouble(), -50.0);
    QCOMPARE(par.max().toDouble(), 100.0);
    auto presetList = par.presets();
    QCOMPARE(presetList.count(), 2);
    QCOMPARE(par.preset("Low"), -40);   
    QCOMPARE(par.preset("High"), 90);
    QCOMPARE(par.isValueModified(), false);
    QCOMPARE(par.label(), "T°C");

    // Value should remain unchanged
    QCOMPARE(par.value().toDouble(), 20.0);

    QCOMPARE(par.isValueModified(), false);
    QCOMPARE(par.isSchemaModified(), false);

}

void TestQtNoidAppParameter::testParameterSchemaFromJsonWithEmptyName()
{
    Parameter par(1000.0);  // No name set
    QSignalSpy nameSpy(&par, &Parameter::nameChanged);
    
    // Create schema JSON
    QJsonObject schema;
    QJsonObject pressureSchema;
    pressureSchema["description"] = "Atmospheric pressure";
    pressureSchema["unit"] = "hPa";
    pressureSchema["readOnly"] = false;
    pressureSchema["min"] = 800.0;
    pressureSchema["max"] = 1100.0;
    schema["Pressure"] = pressureSchema;
    
    // Apply schema - should set name from JSON key
    bool result = par.schemaFromJson(schema);
    QCOMPARE(result, true);
    
    // Verify name was set and schema applied
    QCOMPARE(par.name(), "Pressure");
    QCOMPARE(par.description(), "Atmospheric pressure");
    QCOMPARE(par.unit(), "hPa");
    QCOMPARE(par.readOnly(), false);
    QCOMPARE(par.min().toDouble(), 800.0);
    QCOMPARE(par.max().toDouble(), 1100.0);
    QCOMPARE(nameSpy.count(), 1);
    
    // Value should remain unchanged
    QCOMPARE(par.value().toDouble(), 1000.0);
}

void TestQtNoidAppParameter::testParameterSchemaFromJsonWithNonExistentKey()
{
    Parameter par(25.0, "Temperature", this);
    
    // Create schema JSON with different key
    QJsonObject schema;
    QJsonObject pressureSchema;
    pressureSchema["description"] = "Atmospheric pressure";
    schema["Pressure"] = pressureSchema;
    
    // Apply schema - should fail because key doesn't match parameter name
    bool result = par.schemaFromJson(schema);
    QCOMPARE(result, false);
    
    // Properties should remain unchanged
    QCOMPARE(par.name(), "Temperature");
    QCOMPARE(par.description(), QString());
    QCOMPARE(par.unit(), QString());
    QCOMPARE(par.readOnly(), false);
    QVERIFY(!par.min().isValid());
    QVERIFY(!par.max().isValid());
    QCOMPARE(par.value().toDouble(), 25.0);
}

void TestQtNoidAppParameter::testParameterSchemaFromJsonEmptyObject()
{
    Parameter par(25.0, "Temperature");
    
    // Apply empty schema
    QCOMPARE(par.schemaFromJson(QJsonObject()), false);
    
    // Properties should remain unchanged
    QCOMPARE(par.name(), "Temperature");
    QCOMPARE(par.description(), QString());
    QCOMPARE(par.unit(), QString());
    QCOMPARE(par.readOnly(), false);
    QVERIFY(!par.min().isValid());
    QVERIFY(!par.max().isValid());
    QCOMPARE(par.value().toDouble(), 25.0);
}

void TestQtNoidAppParameter::testParameterSchemaFromJsonPartialSchemaShouldSetUnspecifiedParamtersToDefault()
{
    Parameter par(12.0, "Voltage", this);
    par.setDescription("Original description");
    par.setUnit("mV");
    par.setReadOnly(true);
    
    // Create partial schema (only some properties)
    QJsonObject schema;
    QJsonObject voltageSchema;
    voltageSchema["description"] = "Updated description";
    voltageSchema["unit"] = "V";
    // Note: readOnly not included, min/max not included
    schema["Voltage"] = voltageSchema;
    
    // Apply partial schema
    bool result = par.schemaFromJson(schema);
    QCOMPARE(result, true);
    
    // Only specified properties should be updated
    QCOMPARE(par.name(), "Voltage");
    QCOMPARE(par.description(), "Updated description");
    QCOMPARE(par.unit(), "V");
    QCOMPARE(par.readOnly(), false);  // Should get the default
    QVERIFY(!par.min().isValid());   // Should remain unchanged
    QVERIFY(!par.max().isValid());   // Should remain unchanged
    QCOMPARE(par.value().toDouble(), 12.0);  // Should remain unchanged
}

void TestQtNoidAppParameter::testParameterSchemaFromJsonChangeANewRangeShouldForceANewValue()
{
    // Create parameter with value outside the new range we'll set
    Parameter par(150.0, "Temperature", this);  // Current value is 150
    QSignalSpy valueSpy(&par, &Parameter::valueChanged);
    QSignalSpy rangeSpy(&par, &Parameter::rangeChanged);
    
    // Create schema with new range that will force the value to be clamped
    QJsonObject schema;
    QJsonObject temperatureSchema;
    temperatureSchema["min"] = -50.0;   // New min
    temperatureSchema["max"] = 100.0;   // New max - current value (150) exceeds this
    schema["Temperature"] = temperatureSchema;
    
    // Apply schema - should clamp the current value to the new max
    bool result = par.schemaFromJson(schema);
    QCOMPARE(result, true);
    QCOMPARE(par.isValueModified(), true); // The range change the value
    
    // Verify schema was applied
    QCOMPARE(par.min().toDouble(), -50.0);
    QCOMPARE(par.max().toDouble(), 100.0);
    
    // Value should be clamped to the new maximum
    QCOMPARE(par.value().toDouble(), 100.0);
    QCOMPARE(valueSpy.count(), 1);
    QCOMPARE(rangeSpy.count(), 2);  // Once for min change, once for max change
    
    // Test with value below new minimum
    Parameter par2(-200.0, "Voltage", this);  // Current value is -200
    QSignalSpy valueSpy2(&par2, &Parameter::valueChanged);
    
    QJsonObject schema2;
    QJsonObject voltageSchema;
    voltageSchema["min"] = -100.0;  // New min - current value (-200) is below this
    voltageSchema["max"] = 50.0;    // New max
    schema2["Voltage"] = voltageSchema;
    
    // Apply schema - should clamp the current value to the new min
    bool result2 = par2.schemaFromJson(schema2);
    QCOMPARE(result2, true);
    QCOMPARE(par.isValueModified(), true); // The range change the value

    // Value should be clamped to the new minimum
    QCOMPARE(par2.value().toDouble(), -100.0);
    QCOMPARE(par2.min().toDouble(), -100.0);
    QCOMPARE(par2.max().toDouble(), 50.0);
    QCOMPARE(valueSpy2.count(), 1);
}

void TestQtNoidAppParameter::testParameterIsValid()
{
    // Test case 1: Parameter with empty name should be invalid
    Parameter parEmptyName(this);
    parEmptyName.setValue(100.0);
    QCOMPARE(parEmptyName.isValid(), false);

    // Test case 2: Parameter with name but no value should be invalid
    Parameter parNameOnly("ValidName", this);
    QCOMPARE(parNameOnly.isValid(), false);

    // Test case 3: Parameter with valid name and value should be valid
    Parameter parNameAndValue(50.0, "ValidParam", this);
    QCOMPARE(parNameAndValue.isValid(), true);

    // Test case 4: Parameter with valid range (min < max) should be valid
    Parameter parValidRange(50.0, "RangeParam", this);
    parValidRange.setMin(0.0);
    parValidRange.setMax(100.0);
    QCOMPARE(parValidRange.isValid(), true);

    // Test case 5: Parameter with invalid range (min > max) should be invalid
    Parameter parInvalidRange(50.0, "InvalidRange", this);
    parInvalidRange.setMin(100.0);
    parInvalidRange.setMax(0.0);
    QCOMPARE(parInvalidRange.isValid(), false);

    // Test case 6: Parameter with equal min and max should be valid
    Parameter parEqualRange(50.0, "EqualRange", this);
    parEqualRange.setMin(50.0);
    parEqualRange.setMax(50.0);
    QCOMPARE(parEqualRange.isValid(), true);

    // Test case 7: Parameter with value within range should be valid
    Parameter parValueInRange(25.0, "ValueInRange", this);
    parValueInRange.setMin(0.0);
    parValueInRange.setMax(100.0);
    QCOMPARE(parValueInRange.isValid(), true);

    // Test case 8: It should be not possible to set a value out of the range
    // Or to set the range without clamping the value
    Parameter parValueBelowMin(-10.0, "ValueBelowMin", this);
    parValueBelowMin.setMin(0.0);
    parValueBelowMin.setMax(100.0);
    QCOMPARE(parValueBelowMin.isValid(), true);

    // Test case 9: Parameter with value exactly at minimum should be valid
    Parameter parValueAtMin(0.0, "ValueAtMin", this);
    parValueAtMin.setMin(0.0);
    parValueAtMin.setMax(100.0);
    QCOMPARE(parValueAtMin.isValid(), true);

    // Test case 10: Parameter with value exactly at maximum should be valid
    Parameter parValueAtMax(100.0, "ValueAtMax", this);
    parValueAtMax.setMin(0.0);
    parValueAtMax.setMax(100.0);
    QCOMPARE(parValueAtMax.isValid(), true);

    // Test case 11: Parameter with only min set and value above it should be valid
    Parameter parMinOnly(50.0, "MinOnly", this);
    parMinOnly.setMin(10.0);
    QCOMPARE(parMinOnly.isValid(), true);

    // Test case 12: Parameter with invalid value (empty QVariant) should be invalid
    Parameter parInvalidValue(123, "InvalidValue", this);
    parInvalidValue.setValue(QVariant());
    QCOMPARE(parInvalidValue.isValid(), false);

    // Test case 13: Test with string values and range
    Parameter parStringRange("StringParam", "middle", this);
    parStringRange.setMin("a");
    parStringRange.setMax("z");
    QCOMPARE(parStringRange.isValid(), true);
}

void TestQtNoidAppParameter::testParameterFromJson()
{
    Parameter par(this);

    // Create schema and value JSON objects
    QJsonObject temperatureSchema{{"unit", "°C"},
                                  {"min", -50.0},
                                  {"max", 150.0},
                                  {"description", "Test temperature parameter"},
                                  {"tooltip", "Test temperature parameter tooltip"},
                                  {"readOnly", true},
                                  {"visible", false}
    };
    QJsonObject schema{{"Temperature", temperatureSchema}};

    QJsonObject value{{"Temperature", 25.5}};

    // Test fromJson method
    bool result = par.fromJson(schema, value);
    QCOMPARE(result, true);
    QCOMPARE(par.isValueModified(), false);


    // Verify all properties were set correctly
    QCOMPARE(par.name(), "Temperature");
    QCOMPARE(par.unit(), "°C");
    QCOMPARE(par.min().toDouble(), -50.0);
    QCOMPARE(par.max().toDouble(), 150.0);
    QCOMPARE(par.description(), "Test temperature parameter");
    QCOMPARE(par.tooltip(), "Test temperature parameter tooltip");
    QCOMPARE(par.readOnly(), true);
    QCOMPARE(par.visible(), false);
    QCOMPARE(par.value().toDouble(), 25.5);
}

void TestQtNoidAppParameter::testParameterFromJsonShouldUpdateAnExistingParameter()
{
    Parameter par("InitialValue", "ExistingName", "This is an existing paramter", this);
    QCOMPARE(par.name(), "ExistingName");
    QCOMPARE(par.value().toString(), "InitialValue");

    // Create schema and value for a different parameter name
    QJsonObject pressureSchema {
        {"description", "Atmospheric pressure sensor"},
        {"unit", "hPa"},
        {"readOnly", false},
        {"min", 900.0},
        {"max", 1100.0},
    };
    QJsonObject preset1{{"High", 1050.0}};
    QJsonObject preset2{{"Low", 950.0}};
    QJsonArray presetArray{preset1, preset2};
    pressureSchema["Presets"]= presetArray;
    QJsonObject schema{{"Pressure", pressureSchema}};

    QJsonObject value{{"Pressure", 1013.25}};

    // Test fromJson method - should update name and all properties
    bool result = par.fromJson(schema, value);
    QCOMPARE(result, true);
    QCOMPARE(par.isValueModified(), false);

    // Verify properties were updated to match the JSON
    QCOMPARE(par.name(), "Pressure");
    QCOMPARE(par.description(), "Atmospheric pressure sensor");
    QCOMPARE(par.unit(), "hPa");
    QCOMPARE(par.readOnly(), false);
    QCOMPARE(par.min().toDouble(), 900.0);
    QCOMPARE(par.max().toDouble(), 1100.0);
    QCOMPARE(par.value().toDouble(), 1013.25);
}

void TestQtNoidAppParameter::testParameterFromJsonWithInvalidSchemaShouldLeaveTheParameterUnchanged()
{
    Parameter par(100.0, "TestParam", this);

    // Create invalid schema (empty object)
    QJsonObject emptySchema;

    QJsonObject value{{"TestParam", 200.0}};


    // Test fromJson with invalid schema - should fail
    bool result = par.fromJson(emptySchema, value);
    QCOMPARE(result, false);

    // Original properties should remain unchanged
    QCOMPARE(par.name(), "TestParam");
    QCOMPARE(par.value().toDouble(), 100.0);
    QCOMPARE(par.description(), QString());
    QCOMPARE(par.unit(), QString());
    QCOMPARE(par.readOnly(), false);
}

void TestQtNoidAppParameter::testParameterFromJsonWithInvalidValueShouldLeaveValueUnchanged()
{
    Parameter par(12, "MyParameter", "Parameter Description", this);

    // Create valid schema
    QJsonObject schemaMain{{"unit", "°K"},
                           {"min", 0},
                           {"max", 100}
    };
    QJsonObject schema{{"MyParameter", schemaMain}};

    // Create a value with a different name (non-matching name)
    QJsonObject value;
    value["DifferentParam"] = 15;

    // Test fromJson with invalid value - should fail
    bool result = par.fromJson(schema, value);
    QCOMPARE(result, true);
    // qDebug() << __func__ << par;

    QCOMPARE(par.name(), "MyParameter");
    QVERIFY(par.isValid()); // Value should remain valid

    // Check that the schema has been applied
    QCOMPARE(par.min(), 0);
    QCOMPARE(par.max(), 100);
    QCOMPARE(par.unit(), "°K");

    // Try to create a new one using same Schema / ValueMt
    Parameter newParam(schema, value, this);
    // qDebug() << __func__ << newParam;

    QCOMPARE(newParam.name(), "MyParameter");
    QCOMPARE(newParam.value(), QVariant()); // Value is an empty QVariant
    QCOMPARE(newParam.isValid(), false);

    // Check that the schema has been applied
    QCOMPARE(newParam.min(), 0);
    QCOMPARE(newParam.max(), 100);
    QCOMPARE(newParam.unit(), "°K");
}

void TestQtNoidAppParameter::testParameterFromJsonWithIncompleteSchemaShouldOverrideExisitingSchema()
{
    Parameter par("ExistingName", "This is an existing paramter", "InitialValue", this);
    par.setRange("A", "Z");
    par.setUnit("Char");
    par.setPreset("Low", "A");
    par.setPreset("High", "Z");

    QJsonObject testSchema;
    QJsonObject schema{{"NewParameter", testSchema}};
    QJsonObject value{{"NewParameter", "NewlValue"}};

    bool result = par.fromJson(schema, value);

    QCOMPARE(result, true);

    // Original properties should remain unchanged
    QCOMPARE(par.name(), "NewParameter");
    QCOMPARE(par.value().toString(), "NewlValue");
    QCOMPARE(par.description(), QString());
    QCOMPARE(par.unit(), QString());
    QCOMPARE(par.range(), {});
    QCOMPARE(par.presets(), {});

}

void TestQtNoidAppParameter::testParameterIsValueModifiedShouldBeFalseAfterConstructor()
{
    // Test that a newly created parameter has isChanged() = false
    Parameter param1(this);
    QCOMPARE(param1.isValueModified(), false);

    Parameter param2(42.0, this);
    QCOMPARE(param2.isValueModified(), false);

    Parameter param3(100.0, "TestParam", this);
    QCOMPARE(param3.isValueModified(), false);

    Parameter param4(25.5, "Temperature", "Temperature sensor", this);
    QCOMPARE(param4.isValueModified(), false);

    // Test with JSON constructor
    QJsonObject temperatureSchema;
    QJsonObject temperatureObject;
    temperatureObject["description"] = "Temperature";
    temperatureObject["unit"] = "°C";
    temperatureSchema["Temperature"] = temperatureObject;

    QJsonObject valueJson;
    valueJson["Temperature"] = 20.0;

    Parameter param5(temperatureSchema, valueJson, this);
    QCOMPARE(param5.isValueModified(), false);
}

void TestQtNoidAppParameter::testParameterIsValueModifiedOnlyAfterWeChangeValue()
{
    Parameter param(25.0, "TestParam", "Test parameter", this);
    QCOMPARE(param.isValueModified(), false);

    // Test value change
    param.setValue(25.0);               // Same value - no changes
    QCOMPARE(param.isValueModified(), false);
    param.setValue(30.0);
    QCOMPARE(param.isValueModified(), true);

    // min max range change should be false
    Parameter paramMinMax(25.0, this);
    paramMinMax.setMin(0);
    QCOMPARE(paramMinMax.isValueModified(), false);
    paramMinMax.setMax(100);
    QCOMPARE(paramMinMax.isValueModified(), false);
    paramMinMax.setRange(1, 99);
    QCOMPARE(paramMinMax.isValueModified(), false);

    // min triggering value clamp
    Parameter paramMin(25.0, this);
    paramMin.setMin(26);
    QCOMPARE(paramMin.value(), 26);
    QCOMPARE(paramMin.isValueModified(), true);

    // max triggering value clamp
    Parameter paramMax(25.0, this);
    paramMax.setMax(24);
    QCOMPARE(paramMax.value(), 24);
    QCOMPARE(paramMax.isValueModified(), true);

    // Presets should not change
    Parameter paramPreset(25.0, this);
    paramPreset.setRange(0, 100);
    paramPreset.setPreset("Hot", 50);
    QCOMPARE(paramPreset.isValueModified(), false);

    // ApplyPreset trigger the isValueModified flag
    paramPreset.setValue(26);
    QCOMPARE(paramPreset.isValueModified(), true);
    paramPreset.applyPreset("Hot");
    QCOMPARE(paramPreset.isValueModified(), true);

    // Check that the value is changed flag is updated
    // also the second time
    paramPreset.resetValueModifications();
    paramPreset.applyPreset("Hot");
    QCOMPARE(paramPreset.isValueModified(), true);

    // Name change should not change
    Parameter paramName(25.0, "MyName", this);
    paramName.setName("NewName");
    QCOMPARE(paramName.isValueModified(), false);

    // Description should not change
    Parameter paramDescription(25.0, this);
    paramDescription.setDescription("New description");
    QCOMPARE(paramDescription.isValueModified(), false);

    // Unit should not change
    Parameter paramUnit(25.0, this);
    paramUnit.setUnit("kg");
    QCOMPARE(paramUnit.isValueModified(), false);

    // Tooltip should not change
    Parameter paramToolTip(25.0, this);
    paramToolTip.setTooltip("New tooltip");
    QCOMPARE(paramToolTip.isValueModified(), false);

    // readOnly should not change
    Parameter paramReadOnly(25.0, this);
    paramReadOnly.setReadOnly(true);
    QCOMPARE(paramReadOnly.isValueModified(), false);

    // visible should not change
    Parameter paramVisible(25.0, this);
    paramVisible.setVisible(false);
    QCOMPARE(paramVisible.isValueModified(), false);
    paramVisible.setVisible(true);
    QCOMPARE(paramVisible.isValueModified(), false);
}

void TestQtNoidAppParameter::testParameterIsValueModifiedShouldBeFalseAfterLoadingADifferentJsonValues()
{
    // 1 - Create the parameter, store in a JsonValue,
    //     change, restore from Json
    Parameter param(25.5, "Parameter", "this is a paramter");
    QCOMPARE(param.isValueModified(), false);
    // Store current value to JSON object
    QJsonObject jsonValue = param.toJsonValue();
    param.setValue(123);
    QCOMPARE(param.isValueModified(), true);
    //Restore paramter from JSON (as with load from file)
    param.valueFromJson(jsonValue);
    QCOMPARE(param.value(), 25.5);
    QCOMPARE(param.isValueModified(), false);

    // 2 - Create the parameter, change it, store new value to json,
    //     change again and restore using JSON
    Parameter param2(25.5, "Parameter2", "this is a paramter");
    QCOMPARE(param2.isValueModified(), false);
    param2.setValue(4242);
    QCOMPARE(param2.isValueModified(), true);
    QJsonObject jsonValue2 = param2.toJsonValue();
    param2.setValue(4343);
    param2.valueFromJson(jsonValue2);
    QCOMPARE(param2.value(), 4242);
    // It is not changed because valueFromJson reset the flag and the initalValue
    QCOMPARE(param2.isValueModified(), false);
}

void TestQtNoidAppParameter::testParameterIsValueModifiedSholdBeFalseAfterSettingTheSameValue()
{
    // 1 - Create the parameter
    Parameter param(25.5, "Parameter", "this is a paramter");
    QCOMPARE(param.isValueModified(), false);

    // Store current value
    auto val = param.value();

    // 2 - Edit the parameter
    param.setValue(123);
    QCOMPARE(param.isValueModified(), true);

    // 3 Restore paramter from JSON (as with load from file)
    param.setValue(val);
    QCOMPARE(param.value(), 25.5);
    QCOMPARE(param.isValueModified(), false);
}

void TestQtNoidAppParameter::testParameterIsSchemaModifiedShouldBeFalseAfterConstructor()
{
    // Test that a newly created parameter has isSchemaModified() = false
    Parameter param1(this);
    QCOMPARE(param1.isSchemaModified(), false);

    Parameter param2(42.0, this);
    QCOMPARE(param2.isSchemaModified(), false);

    Parameter param3(100.0, "TestParam", this);
    QCOMPARE(param3.isSchemaModified(), false);

    Parameter param4(25.5, "Temperature", "Temperature sensor", this);
    QCOMPARE(param4.isSchemaModified(), false);

    // Test with JSON constructor
    QJsonObject temperatureSchema;
    QJsonObject temperatureObject;
    temperatureObject["description"] = "Temperature";
    temperatureObject["unit"] = "°C";
    temperatureSchema["Temperature"] = temperatureObject;

    QJsonObject valueJson;
    valueJson["Temperature"] = 20.0;

    Parameter param5(temperatureSchema, valueJson, this);
    QCOMPARE(param5.isSchemaModified(), false);
}

void TestQtNoidAppParameter::testParameterIsSchemaModifiedOnlyAfterSchemaPropertyChanged()
{
    // Every schema-like property change must flip isSchemaModified() to true.
    auto checkFlipsSchemaModified = [this](auto&& change) {
        Parameter par(25.0, "TestParam", this);
        QCOMPARE(par.isSchemaModified(), false);
        change(par);
        QCOMPARE(par.isSchemaModified(), true);
    };

    checkFlipsSchemaModified([](Parameter &par){ par.setName("NewName"); });
    checkFlipsSchemaModified([](Parameter &par){ par.setLabel("New label"); });
    checkFlipsSchemaModified([](Parameter &par){ par.setDescription("New description"); });
    checkFlipsSchemaModified([](Parameter &par){ par.setUnit("kg"); });
    checkFlipsSchemaModified([](Parameter &par){ par.setTooltip("New tooltip"); });
    checkFlipsSchemaModified([](Parameter &par){ par.setReadOnly(true); });
    checkFlipsSchemaModified([](Parameter &par){ par.setVisible(false); });
    checkFlipsSchemaModified([](Parameter &par){ par.setMin(0); });
    checkFlipsSchemaModified([](Parameter &par){ par.setMax(1000); });
    checkFlipsSchemaModified([](Parameter &par){ par.setPresets({{"Low", 10}, {"High", 900}}); });
}

void TestQtNoidAppParameter::testParameterIsSchemaModifiedTracksEveryPropertyAcrossMultipleChanges()
{
    // Regression test for a real bug: isSchemaModified()'s binding scans
    // every tracked property in a loop and used to `return true` as soon
    // as it found the first one that differed from the baseline. Qt's
    // automatic binding dependency tracking only registers a dependency on
    // a property that actually gets READ during an evaluation, so exiting
    // the loop early meant every property read AFTER the first mismatch
    // (in Q_PROPERTY declaration order) permanently stopped being tracked,
    // until a later evaluation happened to run the full loop again.
    //
    // Every other isSchemaModified test either changes a single property
    // on a brand-new Parameter (the very first evaluation always runs the
    // full loop, since nothing differs from the just-captured baseline yet,
    // so it can't expose this), or changes the SAME property before and
    // after a rebaseline (so property order never comes into play). This
    // test changes two DIFFERENT properties in sequence on the SAME
    // instance, with the second one ("name") coming after the first
    // ("unit") in the Q_PROPERTY declaration order, to catch the loss of
    // tracking.
    Parameter par(25.0, "TestParam", this);
    QCOMPARE(par.isSchemaModified(), false);

    // "unit" is the first tracked property in declaration order: changing
    // it is what used to make the binding's loop exit before ever reaching
    // "name", "label", "description", etc.
    par.setUnit("kg");
    QCOMPARE(par.isSchemaModified(), true);

    // Re-capture the baseline from the current state (unit: "kg"), so
    // isSchemaModified() reports false again, WITHOUT touching the
    // properties themselves the way resetSchemaModifications() does -
    // exactly what happens in real usage, where nothing resets the baseline
    // between two unrelated edits made by the user.
    par.setSchemaModified(false);
    QCOMPARE(par.isSchemaModified(), false);

    // "name" comes after "unit" in the property declaration order. If the
    // earlier "unit" change made the binding lose track of properties past
    // it, this change goes undetected and isSchemaModified() incorrectly
    // stays false.
    par.setName("NewName");
    QCOMPARE(par.isSchemaModified(), true);
}

void TestQtNoidAppParameter::testParameterIsSchemaModifiedNotAffectedByValueChange()
{
    Parameter par(25.0, "TestParam", this);
    QCOMPARE(par.isSchemaModified(), false);

    par.setValue(30.0);
    QCOMPARE(par.isValueModified(), true);
    QCOMPARE(par.isSchemaModified(), false);

    // Even when a min change clamps the current value as a side effect,
    // isSchemaModified() turns true because min changed, not because of the
    // value clamp: value is never part of the schema tracking.
    Parameter paramMin(25.0, this);
    paramMin.setMin(26);
    QCOMPARE(paramMin.value(), 26);
    QCOMPARE(paramMin.isValueModified(), true);
    QCOMPARE(paramMin.isSchemaModified(), true);
}

void TestQtNoidAppParameter::testParameterIsSchemaModifiedShouldBeFalseAfterLoadingFromJson()
{
    Parameter param(25.5, "Parameter", "this is a parameter");
    param.setUnit("kg");
    QCOMPARE(param.isSchemaModified(), true);

    QJsonObject jsonSchema = param.toJsonSchema();
    param.setTooltip("Changed again");
    QCOMPARE(param.isSchemaModified(), true);

    // schemaFromJson() re-captures the baseline, so the flag goes back to false.
    param.schemaFromJson(jsonSchema);
    QCOMPARE(param.unit(), QString("kg"));
    QCOMPARE(param.isSchemaModified(), false);
}

void TestQtNoidAppParameter::testParameterResetValueModifications()
{
    Parameter param(25.0, "TestParam", this);
    param.setValue(99.0);
    QCOMPARE(param.isValueModified(), true);

    param.resetValueModifications();
    QCOMPARE(param.value(), 25.0);
    QCOMPARE(param.isValueModified(), false);
}

void TestQtNoidAppParameter::testParameterResetValueModificationsDoesNotAffectSchema()
{
    Parameter param(25.0, "TestParam", this);
    param.setValue(99.0);
    param.setLabel("New label");
    QCOMPARE(param.isValueModified(), true);
    QCOMPARE(param.isSchemaModified(), true);

    param.resetValueModifications();
    QCOMPARE(param.value(), 25.0);
    QCOMPARE(param.isValueModified(), false);
    // resetValueModifications() only touches value: label stays as set, and the
    // schema is still reported as changed.
    QCOMPARE(param.label(), QString("New label"));
    QCOMPARE(param.isSchemaModified(), true);
}

void TestQtNoidAppParameter::testParameterResetSchemaModifications()
{
    Parameter param(25.0, "TestParam", "Original description", this);
    param.setLabel("New label");
    param.setDescription("New description");
    param.setUnit("kg");
    param.setTooltip("New tooltip");
    param.setReadOnly(true);
    param.setVisible(false);
    param.setMin(0);
    param.setMax(100);
    param.setPresets({{"Low", 10}});
    param.setName("NewName");
    QCOMPARE(param.isSchemaModified(), true);

    param.resetSchemaModifications();

    QCOMPARE(param.name(), QString("TestParam"));
    QCOMPARE(param.label(), QString());
    QCOMPARE(param.description(), QString("Original description"));
    QCOMPARE(param.unit(), QString());
    QCOMPARE(param.tooltip(), QString());
    QCOMPARE(param.readOnly(), false);
    QCOMPARE(param.visible(), true);
    QCOMPARE(param.min(), QVariant());
    QCOMPARE(param.max(), QVariant());
    QCOMPARE(param.presets(), QVariantMap());
    QCOMPARE(param.isSchemaModified(), false);
}

void TestQtNoidAppParameter::testParameterResetSchemaModificationsDoesNotAffectValue()
{
    Parameter param(25.0, "TestParam", this);
    param.setValue(99.0);
    param.setLabel("New label");
    QCOMPARE(param.isValueModified(), true);
    QCOMPARE(param.isSchemaModified(), true);

    param.resetSchemaModifications();

    // resetSchemaModifications() only touches schema properties: value stays as set,
    // and isValueModified() is still true.
    QCOMPARE(param.value(), 99.0);
    QCOMPARE(param.isValueModified(), true);
    QCOMPARE(param.label(), QString());
    QCOMPARE(param.isSchemaModified(), false);
}

void TestQtNoidAppParameter::testParameterResetSchemaModifications_MinMaxCanClampCurrentValueAsSideEffect()
{
    // Known, accepted side effect: restoring min/max via resetSchemaChange()
    // still runs through the normal setMin()/setMax() setters, which trigger
    // enforceRange() and may clamp the *current* value against the restored
    // range, even though value itself is excluded from the schema baseline.
    Parameter param(75.0, "TestParam", this);
    param.setRange(50, 100);
    param.captureBaseline(); // friend access: re-baseline with this range as "original"
    QCOMPARE(param.isSchemaModified(), false);

    param.setMin(0); // schema change: widen the range downward
    QCOMPARE(param.isSchemaModified(), true);


    param.setValue(10); // now it is allowed since min is 0
    QCOMPARE(param.value(), 10.0);

    param.resetSchemaModifications(); // restores min back to 50...

    QCOMPARE(param.min(), QVariant(50));
    // ...which re-clamps the still-unreset current value as a side effect.
    QCOMPARE(param.value(), 50.0);
    QCOMPARE(param.isSchemaModified(), false);
}

void TestQtNoidAppParameter::testParameterSetSchemaModifiedForcesTrueRegardlessOfActualChanges()
{
    // Mirrors QTextDocument::setModified(true): force isSchemaModified() to
    // report true even though nothing tracked actually differs from baseline.
    Parameter param(25.0, "TestParam", this);
    QCOMPARE(param.isSchemaModified(), false);

    QSignalSpy spy(&param, &Parameter::isSchemaModifiedChanged);

    param.setSchemaModified(true);
    QCOMPARE(param.isSchemaModified(), true);
    QCOMPARE(spy.count(), 1);
    QCOMPARE(spy.takeFirst().at(0).toBool(), true);

    // No tracked property changed: the override alone is forcing the flag.
    QCOMPARE(param.name(), QString("TestParam"));
    QCOMPARE(param.label(), QString());
}

void TestQtNoidAppParameter::testParameterSetSchemaModifiedFalseCapturesCurrentStateAsNewBaseline()
{
    // Mirrors QTextDocument::setModified(false): accept the parameter's own
    // current properties as the new reference schema.
    Parameter param(25.0, "TestParam", this);
    param.setLabel("Changed label");
    QCOMPARE(param.isSchemaModified(), true);

    QSignalSpy spy(&param, &Parameter::isSchemaModifiedChanged);
    param.setSchemaModified(false);
    QCOMPARE(param.isSchemaModified(), false);
    QCOMPARE(spy.count(), 1);
    QCOMPARE(spy.takeFirst().at(0).toBool(), false);

    // The new baseline is "label: Changed label", not the original empty
    // label: resetSchemaModifications() must restore to it, not revert it.
    param.resetSchemaModifications();
    QCOMPARE(param.label(), QString("Changed label"));
    QCOMPARE(param.isSchemaModified(), false);
}

void TestQtNoidAppParameter::testParameterSetSchemaModifiedOverrideClearedByResetSchemaModifications()
{
    Parameter param(25.0, "TestParam", this);
    QSignalSpy spy(&param, &Parameter::isSchemaModifiedChanged);

    param.setSchemaModified(true);
    QCOMPARE(param.isSchemaModified(), true);
    QCOMPARE(spy.count(), 1);
    QCOMPARE(spy.takeFirst().at(0).toBool(), true);


    // Nothing is actually tracked as changed, so clearing the override alone
    // must bring isSchemaModified() back to false.
    param.resetSchemaModifications();
    QCOMPARE(param.isSchemaModified(), false);
}

void TestQtNoidAppParameter::testParameterSetSchemaModifiedInteractionWithActualSchemaChanges()
{
    Parameter param(25.0, "TestParam", this);

    // Override true + a real schema change: still reported as modified.
    param.setSchemaModified(true);
    param.setLabel("X");
    QCOMPARE(param.isSchemaModified(), true);

    // Clearing the override re-baselines using the current state (label "X"),
    // so isSchemaModified() goes back to false even though label was edited.
    param.setSchemaModified(false);
    QCOMPARE(param.isSchemaModified(), false);
    QCOMPARE(param.label(), QString("X"));

    // A further real schema change is still detected normally afterwards.
    param.setLabel("Y");
    QCOMPARE(param.isSchemaModified(), true);
}

void TestQtNoidAppParameter::testParameterSetValueModifiedForcesTrueRegardlessOfActualChanges()
{
    // Mirrors QTextDocument::setModified(true): force isValueModified() to
    // report true even though the value itself hasn't actually changed.
    Parameter param(25.0, "TestParam", this);
    QCOMPARE(param.isValueModified(), false);

    QSignalSpy spy(&param, &Parameter::isValueModifiedChanged);

    param.setValueModified(true);
    QCOMPARE(param.isValueModified(), true);
    QCOMPARE(spy.count(), 1);
    QCOMPARE(spy.takeFirst().at(0).toBool(), true);

    // The value never changed: the override alone is forcing the flag.
    QCOMPARE(param.value(), 25.0);
}

void TestQtNoidAppParameter::testParameterSetValueModifiedFalseCapturesCurrentStateAsNewBaseline()
{
    // Mirrors QTextDocument::setModified(false): accept the parameter's own
    // current value as the new reference value.
    Parameter param(25.0, "TestParam", this);
    param.setValue(99.0);
    QCOMPARE(param.isValueModified(), true);

    QSignalSpy spy(&param, &Parameter::isValueModifiedChanged);
    param.setValueModified(false);
    QCOMPARE(param.isValueModified(), false);
    QCOMPARE(spy.count(), 1);
    QCOMPARE(spy.takeFirst().at(0).toBool(), false);

    // The new baseline is 99.0, not the original 25.0: resetValueModifications()
    // must restore to it, not revert it.
    param.resetValueModifications();
    QCOMPARE(param.value(), 99.0);
    QCOMPARE(param.isValueModified(), false);
}

void TestQtNoidAppParameter::testParameterSetValueModifiedOverrideClearedByResetValueModifications()
{
    Parameter param(25.0, "TestParam", this);
    QSignalSpy spy(&param, &Parameter::isValueModifiedChanged);

    param.setValueModified(true);
    QCOMPARE(param.isValueModified(), true);
    QCOMPARE(spy.count(), 1);
    QCOMPARE(spy.takeFirst().at(0).toBool(), true);

    // The value never actually changed, so clearing the override alone via
    // resetValueModifications() must bring isValueModified() back to false.
    param.resetValueModifications();
    QCOMPARE(param.isValueModified(), false);
}

void TestQtNoidAppParameter::testParameterSetValueModifiedInteractionWithActualValueChanges()
{
    Parameter param(25.0, "TestParam", this);

    // Override true + a real value change: still reported as modified.
    param.setValueModified(true);
    param.setValue(50.0);
    QCOMPARE(param.isValueModified(), true);

    // Clearing the override re-baselines using the current value (50.0), so
    // isValueModified() goes back to false even though the value changed.
    param.setValueModified(false);
    QCOMPARE(param.isValueModified(), false);
    QCOMPARE(param.value(), 50.0);

    // A further real value change is still detected normally afterwards.
    param.setValue(75.0);
    QCOMPARE(param.isValueModified(), true);
}

void TestQtNoidAppParameter::testParameterWithQDebugOperator()
{
    // Test parameter with minimal properties
    Parameter param1(42.0, "Basic Param", this);
    QString output1 = QDebug::toString(&param1);
    // qDebug() << __func__ << output1;

    QVERIFY(output1.contains("Parameter("));

    QVERIFY(output1.contains("name: \"Basic Param\""));
    QVERIFY(output1.contains("value: QVariant(double, 42)"));
    QVERIFY(output1.contains("isValueModified: false"));
    QVERIFY(output1.contains("isSchemaModified: false"));
    QVERIFY(output1.contains("visible: true"));
    QVERIFY(output1.contains("readOnly: false"));

    // Test parameter with full metadata
    Parameter param2(25.5, "Temperature", "Current temperature", this);
    param2.setUnit("°C");
    param2.setTooltip("Temperature sensor reading");
    param2.setRange(-50.0, 150.0);
    param2.setReadOnly(true);
    param2.setVisible(false);
    param2.setPreset("Low", -10.0);
    param2.setPreset("High", 100.0);

    QString output2 = QDebug::toString(&param2);
    // qDebug() << __func__ << output2;

    QVERIFY(output2.contains("name: \"Temperature\""));
    QVERIFY(output2.contains("value: QVariant(double, 25.5)"));
    QVERIFY(output2.contains("range: [QVariant(double, -50), QVariant(double, 150)]"));
    QVERIFY(output2.contains("readOnly: true"));
    QVERIFY(output2.contains("visible: false"));
    QVERIFY(output2.contains("desc: \"Current temperature\""));
    QVERIFY(output2.contains("tooltip: \"Temperature sensor reading\""));
    QVERIFY(output2.contains("unit: \"°C\""));
    QVERIFY(output2.contains("presets: {"));
    QVERIFY(output2.contains("Low"));
    QVERIFY(output2.contains("High"));

    // Test parameter with changed value
    Parameter param3(100.0, "ChangedParam", this);
    param3.setValue(200.0);
    QString output3 = QDebug::toString(&param3);
    QVERIFY(output3.contains("isValueModified: true"));
    QVERIFY(output3.contains("value: QVariant(double, 200)"));

    // Test parameter with changed schema
    Parameter param4(100.0, "ChangedSchema", this);
    param4.setLabel("TestChange for Schema");
    // qDebug() << __func__ << param4;
    QString output4 = QDebug::toString(&param4);
    QVERIFY(output4.contains("isValueModified: false"));
    QVERIFY(output4.contains("isSchemaModified: true"));

    // Test parameter with string value
    Parameter param5("StringValue", "StringParam", this);
    QString output5 = QDebug::toString(&param5);
    QVERIFY(output5.contains("name: \"StringParam\""));
    QVERIFY(output5.contains("value: QVariant(QString, \"StringValue\")"));

}

void TestQtNoidAppParameter::testParameterWithQDebugOperatorWithPointer()
{
    // Test with valid pointer
    Parameter *param1 = new Parameter(42.0, "PointerParam", this);
    QString output1 = QDebug::toString(param1);
    QVERIFY(output1.contains("Parameter("));
    QVERIFY(output1.contains("name: \"PointerParam\""));
    QVERIFY(output1.contains("value: QVariant(double, 42)"));
    delete param1;

    // Test with nullptr
    Parameter *param2 = nullptr;
    QString output2 = QDebug::toString(param2);
    QVERIFY(output2.contains("Parameter(nullptr)"));
}

void TestQtNoidAppParameter::testCompareVariants()
{
    Parameter par;
    QVariant a = 123;
    QVariant b = 124;
    QVERIFY(par.compareVariants(a, b, -1));
    QVERIFY(par.compareVariants(b, a, 1));
    QVERIFY(par.compareVariants(a, a, 0));

}


QTEST_MAIN(TestQtNoidAppParameter)
#include "test_app_parameter.moc"
