#include <QComboBox>
#include <QJsonArray>
#include <QJsonObject>
#include <QSignalSpy>
#include <QTest>
#include <QtNoidApp/QtNoidApp>

using namespace QtNoid::App;

class TestQtNoidAppConfig : public QObject
{
    Q_OBJECT

private slots:
    void initTestCase();
    void cleanupTestCase();
    void init();
    void cleanup();

    // Constructor tests
    void testDefaultConstructor();
    void testConstructorWithName();
    void testConstructorWithJson();
    void testConfigUniqueId();

    // Property tests
    void testNameProperty();
    void testLabelProperty();
    void testDescriptionProperty();
    void testTooltipProperty();
    void testConfigIsValueModified();
    void testConfigBindableIsValueModifiedProperty();
    void testConfigResetValueModifications();
    void testConfigResetValueModificationsDoesNotAffectSchema();
    void testConfigSetValueModifiedCascadesTrueToAllPages();
    void testConfigSetValueModifiedFalseCapturesCurrentStateAsNewBaselineForAllPages();
    void testConfigSetValueModifiedOverrideClearedByResetValueModifications();
    void testConfigSetValueModifiedWithMixedPageStates();

    void testConfigIsSchemaChanged();
    void testConfigBindableIsSchemaChangedProperty();
    void testConfigResetSchemaChange();
    void testConfigResetSchemaChangeDoesNotAffectValues();
    void testCountProperty();
    void testConfigBindableCountProperty();

    // JSON serialization tests
    void testToJsonValues();
    void testToJsonSchema();
    void testConfigValuesFromJson();
    void testConfigSchemaFromJson();

    // Container management tests
    void testAppendPage();
    void testAppendWithJson();
    void testEmplacePage();
    void testEmplaceWithJson();
    void testRemovePage();
    void testRemoveNonExistentPage();
    void testDeletingPageDirectlyUpdatesConfigBookkeeping();
    void testDeletingChangedPageDirectlyUpdatesIsValueModified();
    void testRenamingRemovedPageDoesNotAffectConfig();
    void testRenamingClearedPageDoesNotAffectConfig();
    void testClearPages();
    void testIsEmpty();

    // Access methods tests
    void testPageByIndex();
    void testPageByName();
    void testIndexOfPage();
    void testContainsPage();
    void testPagesList();
    void testParameterAndPageRenameShouldAutomaticallyUpdate();

    // Parameter access tests
    void testParameterAccess();
    void testParametersCount();

    // Operator tests
    void testOperatorStreamInsert();

    // Save/restore value tests
    void testSaveAndRestoreInt();
    void testSaveAndRestoreDouble();
    void testSaveAndRestoreString();
    void testSaveAndRestoreBool();
    void testSaveAndRestoreStringList();
    void testSaveAndRestoreVariant();
    void testSaveAndRestoreByteArray();
    void testSaveAndRestoreJsonObject();
    void testRestoreAsJsonObjectWithInvalidStoredDataReturnsDefault();

    // Signal tests
    void testNameChangedSignal();
    void testLabelChangedSignal();
    void testDescriptionChangedSignal();
    void testTooltipChangedSignal();
    void testCountChangedSignal();
    void testPageAddedSignal();
    void testPageRemovedSignal();
    void testPageRenameErrorSignal();

    // Testing aboutToBeDestroyed
    void testAboutToBeDestroyedSignal();

    // RecentFiles tests
    void testAddRecentFile();
    void testAddRecentFileShouldDoNothingIfAnEmptyString();
    void testRestoreRecentFiles();
    void testClearRecentFiles();


    // Debug output test
    void testConfigDebugOutput();

    // Iterator tests
    void testConfigBeginAndEndAndRangeLoop();
    void testConfigConstIteratorsAndConstRangeLoop();
    void testConfigReverseIteratorsAndRangeLoop();
    void testConfigConstReverseIterators();
};


void TestQtNoidAppConfig::initTestCase()
{
}


void TestQtNoidAppConfig::cleanupTestCase()
{
}


void TestQtNoidAppConfig::init()
{
}


void TestQtNoidAppConfig::cleanup()
{
}


void TestQtNoidAppConfig::testAddRecentFile()
{
    Config config("TestConfig", this);

    // Test 1: Add first file
    bool result = config.addRecentFile("C:/test/file1.txt");
    QCOMPARE(result, true);
    QStringList recentFiles = config.restoreAsStringList("RecentFiles", QStringList());
    QCOMPARE(recentFiles.size(), 1);
    QCOMPARE(recentFiles.at(0), "C:/test/file1.txt");

    // Test 2: Add multiple files (most recent should be first)
    config.addRecentFile("C:/test/file2.txt");
    config.addRecentFile("C:/test/file3.txt");
    recentFiles = config.restoreAsStringList("RecentFiles", QStringList());
    QCOMPARE(recentFiles.size(), 3);
    QCOMPARE(recentFiles.at(0), "C:/test/file3.txt");
    QCOMPARE(recentFiles.at(1), "C:/test/file2.txt");
    QCOMPARE(recentFiles.at(2), "C:/test/file1.txt");

    // Test 3: Add duplicate - should move to front and not create duplicate
    config.addRecentFile("C:/test/file1.txt");
    recentFiles = config.restoreAsStringList("RecentFiles", QStringList());
    QCOMPARE(recentFiles.size(), 3);
    QCOMPARE(recentFiles.at(0), "C:/test/file1.txt");
    QCOMPARE(recentFiles.at(1), "C:/test/file3.txt");
    QCOMPARE(recentFiles.at(2), "C:/test/file2.txt");

    // Test 4: Test max limit (default 10)
    Config config2("TestConfig2", this);
    for (int i = 1; i <= 15; i++) {
        config2.addRecentFile(QString("C:/test/file%1.txt").arg(i));
    }
    recentFiles = config2.restoreAsStringList("RecentFiles", QStringList());
    QCOMPARE(recentFiles.size(), 10);
    QCOMPARE(recentFiles.at(0), "C:/test/file15.txt");
    QCOMPARE(recentFiles.at(9), "C:/test/file6.txt");

    // Test 5: Test custom max limit
    Config config3("TestConfig3", this);
    for (int i = 1; i <= 8; i++) {
        config3.addRecentFile(QString("C:/test/file%1.txt").arg(i), 5);
    }
    recentFiles = config3.restoreAsStringList("RecentFiles", QStringList());
    QCOMPARE(recentFiles.size(), 5);
    QCOMPARE(recentFiles.at(0), "C:/test/file8.txt");
    QCOMPARE(recentFiles.at(4), "C:/test/file4.txt");

    // Test 6: Test custom parameter name
    Config config4("TestConfig4", this);
    config4.addRecentFile("C:/custom/file.txt", 10, "MyRecentFiles");
    QStringList defaultFiles = config4.restoreAsStringList("RecentFiles", QStringList());
    QStringList customFiles = config4.restoreAsStringList("MyRecentFiles", QStringList());
    QCOMPARE(defaultFiles.size(), 0);
    QCOMPARE(customFiles.size(), 1);
    QCOMPARE(customFiles.at(0), "C:/custom/file.txt");

    // Test 7: Test custom list name
    Config config5("TestConfig5", this);
    config5.addRecentFile("C:/custom/file.txt", 10, "RecentFiles", "CustomList");
    QStringList settingsList = config5.restoreAsStringList("RecentFiles", QStringList(), "Settings");
    QStringList customList = config5.restoreAsStringList("RecentFiles", QStringList(), "CustomList");
    QCOMPARE(settingsList.size(), 0);
    QCOMPARE(customList.size(), 1);
    QCOMPARE(customList.at(0), "C:/custom/file.txt");
}


void TestQtNoidAppConfig::testAddRecentFileShouldDoNothingIfAnEmptyString()
{
    Config config("TestConfig", this);

    // Test 1: Add first file
    bool res = config.addRecentFile("C:/test/file1.txt");
    QVERIFY(res);
    QStringList recentFiles = config.restoreAsStringList("RecentFiles", QStringList());
    QCOMPARE(recentFiles.size(), 1);
    QCOMPARE(recentFiles.at(0), "C:/test/file1.txt");

    // Empty String shoudl fail and leave the list untouched
    res = !config.addRecentFile("");
    QVERIFY(res);
    recentFiles = config.restoreAsStringList("RecentFiles", QStringList());
    QCOMPARE(recentFiles.size(), 1);
    QCOMPARE(recentFiles.at(0), "C:/test/file1.txt");
}


void TestQtNoidAppConfig::testRestoreRecentFiles()
{
    // Test 1: Restore with default value when parameter doesn't exist
    Config config1("TestConfig1", this);
    QStringList defaultValue = {"C:/default/file1.txt", "C:/default/file2.txt"};
    QStringList result = config1.restoreRecentFiles(defaultValue);
    QCOMPARE(result.size(), 2);
    QCOMPARE(result, defaultValue);

    // Test 2: Restore with empty default when parameter doesn't exist
    Config config2("TestConfig2", this);
    QStringList emptyResult = config2.restoreRecentFiles();
    QCOMPARE(emptyResult.size(), 0);
    QVERIFY(emptyResult.isEmpty());

    // Test 3: Restore after adding files
    Config config3("TestConfig3", this);
    config3.addRecentFile("C:/test/file1.txt");
    config3.addRecentFile("C:/test/file2.txt");
    config3.addRecentFile("C:/test/file3.txt");
    QStringList recentFiles = config3.restoreRecentFiles();
    QCOMPARE(recentFiles.size(), 3);
    QCOMPARE(recentFiles.at(0), "C:/test/file3.txt");
    QCOMPARE(recentFiles.at(1), "C:/test/file2.txt");
    QCOMPARE(recentFiles.at(2), "C:/test/file1.txt");

    // Test 4: Restore with custom parameter name
    Config config4("TestConfig4", this);
    config4.addRecentFile("C:/custom/file.txt", 10, "MyRecentFiles");
    QStringList defaultFiles = config4.restoreRecentFiles(QStringList(), "RecentFiles");
    QStringList customFiles = config4.restoreRecentFiles(QStringList(), "MyRecentFiles");
    QCOMPARE(defaultFiles.size(), 0);
    QCOMPARE(customFiles.size(), 1);
    QCOMPARE(customFiles.at(0), "C:/custom/file.txt");

    // Test 5: Restore with custom list name
    Config config5("TestConfig5", this);
    config5.addRecentFile("C:/custom/file.txt", 10, "RecentFiles", "CustomList");
    QStringList settingsList = config5.restoreRecentFiles(QStringList(), "RecentFiles", "Settings");
    QStringList customList = config5.restoreRecentFiles(QStringList(), "RecentFiles", "CustomList");
    QCOMPARE(settingsList.size(), 0);
    QCOMPARE(customList.size(), 1);
    QCOMPARE(customList.at(0), "C:/custom/file.txt");

    // Test 6: Restore returns default when list doesn't exist
    Config config6("TestConfig6", this);
    QStringList defaultForNonExistent = {"C:/fallback/file.txt"};
    QStringList resultNonExistent = config6.restoreRecentFiles(defaultForNonExistent, "RecentFiles", "NonExistentList");
    QCOMPARE(resultNonExistent, defaultForNonExistent);

    // Test 7: Restore after adding and removing duplicates
    Config config7("TestConfig7", this);
    config7.addRecentFile("C:/test/file1.txt");
    config7.addRecentFile("C:/test/file2.txt");
    config7.addRecentFile("C:/test/file1.txt"); // Duplicate - should move to front
    QStringList filesAfterDupe = config7.restoreRecentFiles();
    QCOMPARE(filesAfterDupe.size(), 2);
    QCOMPARE(filesAfterDupe.at(0), "C:/test/file1.txt");
    QCOMPARE(filesAfterDupe.at(1), "C:/test/file2.txt");

    // Test 8: Restore after reaching max limit
    Config config8("TestConfig8", this);
    for (int i = 1; i <= 15; i++) {
        config8.addRecentFile(QString("C:/test/file%1.txt").arg(i));
    }
    QStringList limitedFiles = config8.restoreRecentFiles();
    QCOMPARE(limitedFiles.size(), 10);
    QCOMPARE(limitedFiles.at(0), "C:/test/file15.txt");
    QCOMPARE(limitedFiles.at(9), "C:/test/file6.txt");

    // Test 9: Restore with custom max limit
    Config config9("TestConfig9", this);
    for (int i = 1; i <= 8; i++) {
        config9.addRecentFile(QString("C:/test/file%1.txt").arg(i), 5);
    }
    QStringList customMaxFiles = config9.restoreRecentFiles();
    QCOMPARE(customMaxFiles.size(), 5);
    QCOMPARE(customMaxFiles.at(0), "C:/test/file8.txt");
    QCOMPARE(customMaxFiles.at(4), "C:/test/file4.txt");
}


void TestQtNoidAppConfig::testClearRecentFiles()
{
    // Test 1: Clear recent files after adding some files
    Config config1("TestConfig1", this);
    config1.addRecentFile("C:/test/file1.txt");
    config1.addRecentFile("C:/test/file2.txt");
    config1.addRecentFile("C:/test/file3.txt");

    // Verify files were added
    QStringList recentFiles = config1.restoreRecentFiles();
    QCOMPARE(recentFiles.size(), 3);

    // Clear the recent files
    config1.clearRecentFiles();

    // Verify the list is now empty
    QStringList clearedFiles = config1.restoreRecentFiles();
    QCOMPARE(clearedFiles.size(), 0);
    QVERIFY(clearedFiles.isEmpty());

    // Test 2: Clear on empty list (should not crash)
    config1.clearRecentFiles();
    QStringList emptyList = config1.restoreRecentFiles();
    QCOMPARE(emptyList.size(), 0);

    // Test 3: Clear with custom parameter name
    Config config3("TestConfig3", this);
    config3.addRecentFile("C:/custom/file1.txt", 10, "MyRecentFiles");
    config3.addRecentFile("C:/custom/file2.txt", 10, "MyRecentFiles");

    // Clear the custom parameter
    config3.clearRecentFiles("MyRecentFiles");
    QStringList clearedCustomFiles = config3.restoreRecentFiles(QStringList(), "MyRecentFiles");
    QCOMPARE(clearedCustomFiles.size(), 0);

    // Test 4: Clear with custom list name
    Config config4("TestConfig4", this);
    config4.addRecentFile("C:/custom/file.txt", 10, "RecentFiles", "CustomList");

    QStringList customListFiles = config4.restoreRecentFiles(QStringList(), "RecentFiles", "CustomList");
    QCOMPARE(customListFiles.size(), 1);

    // Clear the custom list
    config4.clearRecentFiles("RecentFiles", "CustomList");

    QStringList clearedCustomList = config4.restoreRecentFiles(QStringList(), "RecentFiles", "CustomList");
    QCOMPARE(clearedCustomList.size(), 0);

    // Test 5: Clear does not affect other parameters
    Config config5("TestConfig5", this);
    config5.addRecentFile("C:/test/file1.txt");
    config5.saveValue("OtherParam", QStringLiteral("XXXXValue"));
    config5.clearRecentFiles();

    QStringList recentAfterClear = config5.restoreRecentFiles();
    QString otherParam = config5.restoreAsString("OtherParam", "");

    QCOMPARE(recentAfterClear.size(), 0);
    QCOMPARE(otherParam, "XXXXValue"); // Other parameter should remain unchanged

    // Test 6: Clear non-existent parameter (should not crash)
    Config config6("TestConfig6", this);
    config6.clearRecentFiles("NonExistent");

    // Should complete without error

    // Test 7: Clear non-existent list (should not crash)
    Config config7("TestConfig7", this);
    config7.clearRecentFiles("RecentFiles", "NonExistentList");
    // Should complete without error

    // Test 8: Add files after clearing
    Config config8("TestConfig8", this);
    config8.addRecentFile("C:/test/file1.txt");
    config8.addRecentFile("C:/test/file2.txt");
    config8.clearRecentFiles();

    // Add new files after clearing
    config8.addRecentFile("C:/test/file3.txt");
    config8.addRecentFile("C:/test/file4.txt");

    QStringList filesAfterClear = config8.restoreRecentFiles();
    QCOMPARE(filesAfterClear.size(), 2);
    QCOMPARE(filesAfterClear.at(0), "C:/test/file4.txt");
    QCOMPARE(filesAfterClear.at(1), "C:/test/file3.txt");
}


void TestQtNoidAppConfig::testConfigDebugOutput()
{
    // Test with empty config
    Config emptyConfig(this);
    emptyConfig.setName("EmptyConfig");

    QString dbgOutput = QDebug::toString(&emptyConfig);
    // qDebug() << __func__ << dbgOutput;

    // Verify output contains the config name and count
    QVERIFY(!dbgOutput.isEmpty());
    QVERIFY(dbgOutput.contains("EmptyConfig"));
    QVERIFY(dbgOutput.contains("count: 0"));

    // Test with populated config
    Config config;
    config.setName("DebugTest");
    config.setDescription("Test config for debug output");
    config.setTooltip("Test config tooltip");

    // Add multiple parameter lists
    config.saveValue("Volume", 75.0);
    config.saveValue("Theme", "light");

    dbgOutput = QDebug::toString(&config);
    // qDebug() << __func__ << dbgOutput;

    // Verify output contains expected information
    QVERIFY(!dbgOutput.isEmpty());
    QVERIFY(dbgOutput.contains("DebugTest"));
    QVERIFY(dbgOutput.contains("description"));
    QVERIFY(dbgOutput.contains("tooltip"));

    QVERIFY(dbgOutput.contains("pages: ["));
    QVERIFY(dbgOutput.contains("Settings"));
    QVERIFY(dbgOutput.contains("count: 2, visible: true"));
    QVERIFY(dbgOutput.contains("Volume"));
    QVERIFY(dbgOutput.contains("Theme"));


    // Test pointer version
    Config* ptrConfig = new Config(this);
    ptrConfig->setName("PtrTest");

    QString ptrOutput;
    QDebug ptrDebug(&ptrOutput);
    ptrDebug << ptrConfig;

    QVERIFY(!ptrOutput.isEmpty());
    QVERIFY(ptrOutput.contains("Config("));
    QVERIFY(ptrOutput.contains("PtrTest"));

    delete ptrConfig;

    // Test nullptr
    Config* nullConfig = nullptr;
    QString nullOutput;
    QDebug nullDebug(&nullOutput);
    nullDebug << nullConfig;

    QVERIFY(!nullOutput.isEmpty());
    QVERIFY(nullOutput.contains("Config(nullptr)"));

}

// Constructor tests
void TestQtNoidAppConfig::testDefaultConstructor()
{
    Config config(this);

    QVERIFY(config.name().isEmpty());
    QVERIFY(config.label().isEmpty());
    QVERIFY(config.description().isEmpty());
    QVERIFY(config.tooltip().isEmpty());
    QCOMPARE(config.count(), 0);
    QVERIFY(config.isEmpty());
}

void TestQtNoidAppConfig::testConstructorWithName()
{
    Config config("MyConfig", this);

    QCOMPARE(config.name(), "MyConfig");
}

void TestQtNoidAppConfig::testConstructorWithJson()
{
    // Create schema JSON
    QJsonObject page1Details({{"description", "Page 1"}});
    QJsonObject page1Schema({{"Settings", page1Details}});
    QJsonArray pagesArray({page1Schema});

    QJsonObject schemaMain({
        {"label", "Test label"},
        {"description", "Test description"},
        {"tooltip", "Test tooltip"},
        {"pages", pagesArray}
    });
    QJsonObject schema({{"TestConfig", schemaMain}});
    // qDebug() << __func__ << "Schema:" << schema;

    // Create value JSON
    QJsonObject param1({{"Volume", 50}});
    QJsonObject param2({{"Theme", "light"}});
    QJsonArray params({param1, param2});
    QJsonObject page1Main({{"parameters", params}});
    QJsonObject page1({{"Settings", page1Main}});
    QJsonObject valueMain({{"pages", QJsonArray({page1})}});
    QJsonObject value({{"TestConfig", valueMain}});
    // qDebug() << __func__ << "Value:" << value;

    // Create config from JSON
    Config config(schema, value, this);
    // qDebug() << __func__ << config;

    QCOMPARE(config.name(), "TestConfig");
    QCOMPARE(config.label(), "Test label");
    QCOMPARE(config.description(), "Test description");
    QCOMPARE(config.tooltip(), "Test tooltip");

    auto volume = config.restoreAsInt("Volume", 0);
    QCOMPARE(volume, 50);
    auto theme = config.restoreAsString("Theme", "");
    QCOMPARE(theme, "light");

    QCOMPARE(config.count(), 1);
    QVERIFY(config.contains("Settings"));
    QCOMPARE(config.parametersCount("Settings"), 2);
}

void TestQtNoidAppConfig::testConfigUniqueId()
{
    // Test that each Config instance gets a unique ID
    Config config1(this);
    Config config2(QJsonObject(), QJsonObject(), this);
    Config config3("NamedConfig", this);

    int id1 = config1.uniqueId();
    int id2 = config2.uniqueId();
    int id3 = config3.uniqueId();

    // Verify that IDs are different
    QVERIFY(id1 != id2);
    QVERIFY(id2 != id3);
    QVERIFY(id1 != id3);

    // Verify that ID doesn't change for the same instance
    QCOMPARE(config1.uniqueId(), id1);
    QCOMPARE(config2.uniqueId(), id2);
    QCOMPARE(config3.uniqueId(), id3);

    // Test that IDs are sequential (based on the implementation)
    QCOMPARE(id2, id1 + 1);
    QCOMPARE(id3, id2 + 1);
}

// Property tests
void TestQtNoidAppConfig::testNameProperty()
{
    Config config(this);

    QVERIFY(config.name().isEmpty());

    config.setName("TestName");
    QCOMPARE(config.name(), "TestName");

    config.setName("NewName");
    QCOMPARE(config.name(), "NewName");

    // Test bindable
    QBindable<QString> bindableName = config.bindableName();
    QVERIFY(bindableName.isValid());
    QCOMPARE(bindableName.value(), "NewName");
}

void TestQtNoidAppConfig::testLabelProperty()
{
    Config config(this);

    QVERIFY(config.label().isEmpty());

    config.setLabel("Test label");
    QCOMPARE(config.label(), "Test label");

    config.setLabel("New label");
    QCOMPARE(config.label(), "New label");

    // Test bindable
    QBindable<QString> bindableLabel = config.bindableLabel();
    QVERIFY(bindableLabel.isValid());
    QCOMPARE(bindableLabel.value(), "New label");
}

void TestQtNoidAppConfig::testDescriptionProperty()
{
    Config config(this);

    QVERIFY(config.description().isEmpty());

    config.setDescription("Test description");
    QCOMPARE(config.description(), "Test description");

    config.setDescription("New description");
    QCOMPARE(config.description(), "New description");

    // Test bindable
    QBindable<QString> bindableDesc = config.bindableDescription();
    QVERIFY(bindableDesc.isValid());
    QCOMPARE(bindableDesc.value(), "New description");
}

void TestQtNoidAppConfig::testTooltipProperty()
{
    Config config(this);

    QVERIFY(config.tooltip().isEmpty());

    config.setTooltip("Test tooltip");
    QCOMPARE(config.tooltip(), "Test tooltip");

    config.setTooltip("New tooltip");
    QCOMPARE(config.tooltip(), "New tooltip");

    // Test bindable
    QBindable<QString> bindableTooltip = config.bindableTooltip();
    QVERIFY(bindableTooltip.isValid());
    QCOMPARE(bindableTooltip.value(), "New tooltip");
}

void TestQtNoidAppConfig::testConfigIsValueModified()
{
    // We create a config object with 2 pages with 1 parameter for page
    Config config(this);
    ParametersPage* page1 = config.emplace("Page1");
    ParametersPage* page2 = config.emplace("Page2");

    Parameter* p1 = page1->emplace(10, "Param1");
    Parameter* p2 = page2->emplace(5, "Param2");

    // No parameter changed yet
    QCOMPARE(config.isValueModified(), false);

    QSignalSpy spy(&config, &Config::isValueModifiedChanged);

    // Changing a parameter on page1 should flip the aggregate to true
    p1->setValue(99);
    QCOMPARE(config.isValueModified(), true);
    QCOMPARE(spy.count(), 1);
    QCOMPARE(spy.takeFirst().at(0).toBool(), true);

    // A parameter changing on a second page too should not emit again (already true)
    p2->setValue(50);
    QCOMPARE(config.isValueModified(), true);
    QCOMPARE(spy.count(), 0);

    // Reverting the first page's parameter: the second page is still changed,
    // so the aggregate stays true
    p1->setValue(10);
    QCOMPARE(config.isValueModified(), true);
    QCOMPARE(spy.count(), 0);

    // Reverting the last changed parameter: the aggregate must go back to false
    p2->setValue(5);
    QCOMPARE(config.isValueModified(), false);
    QCOMPARE(spy.count(), 1);
    QCOMPARE(spy.takeFirst().at(0).toBool(), false);

    // Appending a page that is already "changed" should activate the flag immediately
    ParametersPage* modifiedPage = new ParametersPage("ModifiedPage", this);
    modifiedPage->emplace(0, "ModifiedParameter")->setValue(100);
    QCOMPARE(modifiedPage->isValueModified(), true);

    bool res = config.append(modifiedPage);
    QCOMPARE(res, true);
    QCOMPARE(config.isValueModified(), true);
    QCOMPARE(spy.count(), 1);
    QCOMPARE(spy.takeFirst().at(0).toBool(), true);

    // Removing that page (it stays alive, detached from Config) should
    // bring the aggregate back to false
    config.remove(modifiedPage);
    QCOMPARE(config.isValueModified(), false);
    QCOMPARE(spy.count(), 1);
    QCOMPARE(spy.takeFirst().at(0).toBool(), false);

    delete modifiedPage;
}

void TestQtNoidAppConfig::testConfigBindableIsValueModifiedProperty()
{
    Config config(this);
    ParametersPage* page = config.emplace("Page1");
    Parameter* p1 = page->emplace(10, "Param1");

    auto bindableIsValueModified = config.bindableIsValueModified();
    QVERIFY(bindableIsValueModified.isValid());
    QCOMPARE(bindableIsValueModified.value(), false);

    // Test binding to another property
    QProperty<bool> externalProperty;
    externalProperty.setBinding([&]() { return bindableIsValueModified.value(); });
    QCOMPARE(externalProperty.value(), false);

    // Changing the parameter on the contained page should propagate through the binding
    p1->setValue(20);
    QCOMPARE(bindableIsValueModified.value(), true);
    QCOMPARE(externalProperty.value(), true);

    // Reverting the value should propagate back to false
    p1->setValue(10);
    QCOMPARE(bindableIsValueModified.value(), false);
    QCOMPARE(externalProperty.value(), false);
}

void TestQtNoidAppConfig::testConfigResetValueModifications()
{
    Config config(this);
    ParametersPage* page1 = config.emplace("Page1");
    ParametersPage* page2 = config.emplace("Page2");
    Parameter* p1 = page1->emplace(10, "Param1");
    Parameter* p2 = page2->emplace(5, "Param2");

    p1->setValue(99);
    p2->setValue(50);
    QCOMPARE(config.isValueModified(), true);

    config.resetValueModifications();

    QCOMPARE(p1->value(), 10);
    QCOMPARE(p2->value(), 5);
    QCOMPARE(p1->isValueModified(), false);
    QCOMPARE(p2->isValueModified(), false);
    QCOMPARE(config.isValueModified(), false);
}

void TestQtNoidAppConfig::testConfigResetValueModificationsDoesNotAffectSchema()
{
    Config config(this);
    ParametersPage* page = config.emplace("Page1");
    Parameter* p1 = page->emplace(10, "Param1");
    p1->setValue(99);
    page->setLabel("Page label");
    config.setDescription("Config description");

    QCOMPARE(config.isValueModified(), true);
    QCOMPARE(config.isSchemaModified(), true);

    config.resetValueModifications();

    QCOMPARE(p1->value(), 10);
    QCOMPARE(config.isValueModified(), false);
    // resetValueModifications() only touches values: schema changes at every
    // level (Config, page, parameter) must survive.
    QCOMPARE(page->label(), QString("Page label"));
    QCOMPARE(config.description(), QString("Config description"));
    QCOMPARE(config.isSchemaModified(), true);
}

void TestQtNoidAppConfig::testConfigSetValueModifiedCascadesTrueToAllPages()
{
    // Config::setValueModified() has no override flag of its own: it
    // cascades to every contained ParametersPage, and Config's own aggregate
    // flag follows automatically through the counter already wired up.
    Config config(this);
    ParametersPage* page1 = config.emplace("Page1");
    ParametersPage* page2 = config.emplace("Page2");
    page1->emplace(10, "Param1");
    page2->emplace(5, "Param2");
    QCOMPARE(config.isValueModified(), false);

    QSignalSpy spy(&config, &Config::isValueModifiedChanged);

    config.setValueModified(true);
    QCOMPARE(page1->isValueModified(), true);
    QCOMPARE(page2->isValueModified(), true);
    QCOMPARE(config.isValueModified(), true);
    QCOMPARE(spy.count(), 1);
    QCOMPARE(spy.takeFirst().at(0).toBool(), true);
}

void TestQtNoidAppConfig::testConfigSetValueModifiedFalseCapturesCurrentStateAsNewBaselineForAllPages()
{
    Config config(this);
    ParametersPage* page1 = config.emplace("Page1");
    ParametersPage* page2 = config.emplace("Page2");
    Parameter* p1 = page1->emplace(10, "Param1");
    Parameter* p2 = page2->emplace(5, "Param2");

    p1->setValue(99);
    QCOMPARE(config.isValueModified(), true);

    config.setValueModified(false);
    QCOMPARE(page1->isValueModified(), false);
    QCOMPARE(page2->isValueModified(), false);
    QCOMPARE(config.isValueModified(), false);

    // Each page's new baseline is its own current value (99 for p1, 5 for
    // p2), not whatever it started with: resetValueModifications() must
    // restore to it, not revert it.
    p1->setValue(100);
    p2->setValue(6);
    config.resetValueModifications();
    QCOMPARE(p1->value(), 99);
    QCOMPARE(p2->value(), 5);
    QCOMPARE(config.isValueModified(), false);
}

void TestQtNoidAppConfig::testConfigSetValueModifiedOverrideClearedByResetValueModifications()
{
    Config config(this);
    ParametersPage* page1 = config.emplace("Page1");
    ParametersPage* page2 = config.emplace("Page2");
    page1->emplace(10, "Param1");
    page2->emplace(5, "Param2");

    config.setValueModified(true);
    QCOMPARE(config.isValueModified(), true);

    // Neither page actually changed, so cascading resetValueModifications()
    // alone must bring everything back to false.
    config.resetValueModifications();
    QCOMPARE(page1->isValueModified(), false);
    QCOMPARE(page2->isValueModified(), false);
    QCOMPARE(config.isValueModified(), false);
}

void TestQtNoidAppConfig::testConfigSetValueModifiedWithMixedPageStates()
{
    Config config(this);
    ParametersPage* page1 = config.emplace("Page1");
    ParametersPage* page2 = config.emplace("Page2");
    Parameter* p1 = page1->emplace(10, "Param1");
    Parameter* p2 = page2->emplace(5, "Param2");
    Q_UNUSED(p2)

    // page1 is genuinely modified, page2 is not.
    p1->setValue(99);
    QCOMPARE(page1->isValueModified(), true);
    QCOMPARE(page2->isValueModified(), false);
    QCOMPARE(config.isValueModified(), true);

    // Forcing true cascades to every page, including the one already modified.
    config.setValueModified(true);
    QCOMPARE(page1->isValueModified(), true);
    QCOMPARE(page2->isValueModified(), true);
    QCOMPARE(config.isValueModified(), true);

    // Clearing cascades too: each page's current state becomes its own new
    // baseline, regardless of whether it had a real change beforehand.
    config.setValueModified(false);
    QCOMPARE(page1->isValueModified(), false);
    QCOMPARE(page2->isValueModified(), false);
    QCOMPARE(config.isValueModified(), false);

    // p1's new baseline is 99, not the original 10.
    p1->resetValueModifications();
    QCOMPARE(p1->value(), 99);
}

void TestQtNoidAppConfig::testConfigIsSchemaChanged()
{
    Config config(this);
    ParametersPage* page1 = config.emplace("Page1");
    ParametersPage* page2 = config.emplace("Page2");

    // Nothing changed yet
    QCOMPARE(config.isSchemaModified(), false);

    QSignalSpy spy(&config, &Config::isSchemaModifiedChanged);

    // Changing Config's own schema property flips the aggregate to true
    config.setLabel("New label");
    QCOMPARE(config.isSchemaModified(), true);
    QCOMPARE(spy.count(), 1);
    QCOMPARE(spy.takeFirst().at(0).toBool(), true);

    // Restoring that own property back to the baseline value (without going
    // through resetSchemaChange()) must recompute the flag back to false:
    // isSchemaChanged compares against the baseline, it is not a sticky flag.
    config.setLabel(QString());
    QCOMPARE(config.isSchemaModified(), false);
    QCOMPARE(spy.count(), 1);
    QCOMPARE(spy.takeFirst().at(0).toBool(), false);

    // A contained ParametersPage's schema change should aggregate too
    page1->setLabel("Page1 label");
    QCOMPARE(config.isSchemaModified(), true);
    QCOMPARE(spy.count(), 1);
    QCOMPARE(spy.takeFirst().at(0).toBool(), true);

    // A second page's schema changing too should not emit again (already true)
    page2->setLabel("Page2 label");
    QCOMPARE(config.isSchemaModified(), true);
    QCOMPARE(spy.count(), 0);

    // Reverting the first page: the second is still changed, aggregate stays true
    page1->resetSchemaModifications();
    QCOMPARE(config.isSchemaModified(), true);
    QCOMPARE(spy.count(), 0);

    // Reverting the last changed page: aggregate must go back to false
    page2->resetSchemaModifications();
    QCOMPARE(config.isSchemaModified(), false);
    QCOMPARE(spy.count(), 1);
    QCOMPARE(spy.takeFirst().at(0).toBool(), false);

    // Appending a page that is already "schema changed" activates the flag immediately
    ParametersPage* modifiedPage = new ParametersPage("ModifiedPage", this);
    modifiedPage->setLabel("already changed");
    QCOMPARE(modifiedPage->isSchemaModified(), true);

    config << modifiedPage;
    QCOMPARE(config.isSchemaModified(), true);
    QCOMPARE(spy.count(), 1);
    QCOMPARE(spy.takeFirst().at(0).toBool(), true);

    // Removing that page (it stays alive, detached from Config) should
    // bring the aggregate back to false
    config.remove(modifiedPage);
    QCOMPARE(config.isSchemaModified(), false);
    QCOMPARE(spy.count(), 1);
    QCOMPARE(spy.takeFirst().at(0).toBool(), false);

    delete modifiedPage;
}

void TestQtNoidAppConfig::testConfigBindableIsSchemaChangedProperty()
{
    Config config(this);
    ParametersPage* page = config.emplace("Page1");

    auto bindableIsSchemaChanged = config.bindableIsSchemaModified();
    QVERIFY(bindableIsSchemaChanged.isValid());
    QCOMPARE(bindableIsSchemaChanged.value(), false);

    QProperty<bool> externalProperty;
    externalProperty.setBinding([&]() { return bindableIsSchemaChanged.value(); });
    QCOMPARE(externalProperty.value(), false);

    // Changing the contained page's schema should propagate through the binding
    page->setLabel("New label");
    QCOMPARE(bindableIsSchemaChanged.value(), true);
    QCOMPARE(externalProperty.value(), true);

    // Reverting the page's schema should propagate back to false
    page->resetSchemaModifications();
    QCOMPARE(bindableIsSchemaChanged.value(), false);
    QCOMPARE(externalProperty.value(), false);
}

void TestQtNoidAppConfig::testConfigResetSchemaChange()
{
    Config config("TestConfig", this);
    ParametersPage* page = config.emplace("Page1");
    page->setLabel("Page label");
    config.setLabel("Config label");
    config.setDescription("Config description");
    config.setTooltip("Config tooltip");

    QCOMPARE(config.isSchemaModified(), true);

    config.resetSchemaModifications();

    QCOMPARE(config.label(), QString());
    QCOMPARE(config.description(), QString());
    QCOMPARE(config.tooltip(), QString());
    QCOMPARE(config.isSchemaModified(), false);

    // Cascades down to every contained ParametersPage too.
    QCOMPARE(page->label(), QString());
    QCOMPARE(page->isSchemaModified(), false);
}

void TestQtNoidAppConfig::testConfigResetSchemaChangeDoesNotAffectValues()
{
    Config config(this);
    ParametersPage* page = config.emplace("Page1");
    Parameter* p1 = page->emplace(10, "Param1");
    p1->setValue(99);
    page->setLabel("Page label");
    config.setDescription("Config description");

    QCOMPARE(config.isValueModified(), true);
    QCOMPARE(config.isSchemaModified(), true);

    config.resetSchemaModifications();

    // resetSchemaChange() only touches schema properties: values stay as set.
    QCOMPARE(p1->value(), 99);
    QCOMPARE(config.isValueModified(), true);
    QCOMPARE(config.description(), QString());
    QCOMPARE(page->label(), QString());
    QCOMPARE(config.isSchemaModified(), false);
}

void TestQtNoidAppConfig::testCountProperty()
{
    Config config(this);

    QCOMPARE(config.count(), 0);

    config.emplace("Page1");
    QCOMPARE(config.count(), 1);

    config.emplace("Page2");
    QCOMPARE(config.count(), 2);

    config.remove("Page1");
    QCOMPARE(config.count(), 1);

    config.clear();
    QCOMPARE(config.count(), 0);
}

void TestQtNoidAppConfig::testConfigBindableCountProperty()
{    
    Config config(this);

    // Get the bindable property
    auto bindableCount = config.bindableCount();
    QVERIFY(bindableCount.isValid());
    QCOMPARE(bindableCount.value(), 0);

    // Test binding to another property
    QProperty<int> externalProperty;
    externalProperty.setBinding([&]() { return bindableCount.value(); });
    QCOMPARE(externalProperty.value(), 0);

    // Add pages and verify binding updates
    QSignalSpy countChangedSpy(&config, &Config::countChanged);

    // Add a page using emplace
    config.emplace("Page1");
    QCOMPARE(config.count(), 1);
    QCOMPARE(bindableCount.value(), 1);
    QCOMPARE(externalProperty.value(), 1);
    QCOMPARE(countChangedSpy.count(), 1);

    // Add a page using append
    ParametersPage* page2 = new ParametersPage("Page2", &config);
    config.append(page2);
    QCOMPARE(config.count(), 2);
    QCOMPARE(bindableCount.value(), 2);
    QCOMPARE(externalProperty.value(), 2);
    QCOMPARE(countChangedSpy.count(), 2);

    // Add a page using emplace from JSON
    QJsonObject pageSchema({{"description", "This is Page 3"}});
    QJsonObject schema({{"Page3", pageSchema}});
    QJsonObject param({{"Key", "Value"}});
    QJsonObject valueMain({{"parameters", QJsonArray{param} }});
    QJsonObject value({{"Page3", valueMain}});
    config.emplace(schema, value);
    QCOMPARE(config.count(), 3);
    QCOMPARE(bindableCount.value(), 3);
    QCOMPARE(externalProperty.value(), 3);
    QCOMPARE(countChangedSpy.count(), 3);

    // Remove a page by reference
    config.remove(page2);
    QCOMPARE(config.count(), 2);
    QCOMPARE(bindableCount.value(), 2);
    QCOMPARE(externalProperty.value(), 2);
    QCOMPARE(countChangedSpy.count(), 4);

    // Remove a page by name
    config.remove("Page3");
    QCOMPARE(config.count(), 1);
    QCOMPARE(bindableCount.value(), 1);
    QCOMPARE(externalProperty.value(), 1);
    QCOMPARE(countChangedSpy.count(), 5);

    // Clear config and verify binding updates
    config.clear();
    QCOMPARE(config.count(), 0);
    QCOMPARE(bindableCount.value(), 0);
    QCOMPARE(externalProperty.value(), 0);
    QCOMPARE(countChangedSpy.count(), 6);

    // Verify signal was emitted with correct values
    QList<QVariant> arguments = countChangedSpy.at(0);
    QCOMPARE(arguments.at(0).toInt(), 1);
    arguments = countChangedSpy.at(1);
    QCOMPARE(arguments.at(0).toInt(), 2);
    arguments = countChangedSpy.at(2);
    QCOMPARE(arguments.at(0).toInt(), 3);
    arguments = countChangedSpy.at(3);
    QCOMPARE(arguments.at(0).toInt(), 2);
    arguments = countChangedSpy.at(4);
    QCOMPARE(arguments.at(0).toInt(), 1);
    arguments = countChangedSpy.at(5);
    QCOMPARE(arguments.at(0).toInt(), 0);
}


// JSON serialization tests
void TestQtNoidAppConfig::testToJsonValues()
{
    Config config("TestConfig", this);
    config.saveValue("Volume", 75);
    config.saveValue("Theme", "dark");

    QJsonObject json = config.toJsonValues();
    // qDebug() << __func__ << config;
    // qDebug() << __func__ << json;

    QVERIFY(json.contains("TestConfig"));
    QJsonObject jsonMain = json["TestConfig"].toObject();
    QJsonArray pagesArray = jsonMain["pages"].toArray();
    QVERIFY(pagesArray.size() == 1);
}

void TestQtNoidAppConfig::testToJsonSchema()
{
    Config config("TestConfig", this);
    config.setLabel("Test label");
    config.setDescription("Test description");
    config.setTooltip("Test tooltip");
    config.emplace("Page1", "Page 1 description");

    QJsonObject json = config.toJsonSchema();

    QVERIFY(json.contains("TestConfig"));
    QJsonObject schemaMain = json["TestConfig"].toObject();
    QCOMPARE(schemaMain["label"].toString(), "Test label");
    QCOMPARE(schemaMain["description"].toString(), "Test description");
    QCOMPARE(schemaMain["tooltip"].toString(), "Test tooltip");
    QVERIFY(schemaMain.contains("pages"));
}


void TestQtNoidAppConfig::testConfigValuesFromJson()
{
    Config config("TestConfig", this);

    // Create value JSON
    QJsonObject param1({{"Volume", 80}});
    QJsonObject param2({{"Intensity", 500}});
    QJsonArray params({param1, param2});
    QJsonObject pageValue({{"parameters", params}});
    QJsonObject pageMain({{"Settings", pageValue}});
    QJsonArray pagesArray({pageMain});
    QJsonObject valueMain({{"pages", pagesArray}});
    QJsonObject value({{"TestConfig", valueMain}});

    // qDebug() << __func__ << value;
    bool result = config.valuesFromJson(value);
    // qDebug() << __func__ << config;

    QVERIFY(result);
    QCOMPARE(config.name(), "TestConfig");
    QCOMPARE(config.restoreAsInt("Volume", 0), 80);
    QCOMPARE(config.restoreAsInt("Intensity", 0), 500);

    // Test using a Config object with 0 pages
    Config config2(this);
    QJsonObject valueMain2({{"pages", QJsonArray()}});
    QJsonObject value2({{"TestConfig2", valueMain2}});

    // qDebug() << __func__ << value2;
    result = config2.valuesFromJson(value2);
    // qDebug() << __func__ << config2;

    QVERIFY(result);
    QCOMPARE(config2.name(), "TestConfig2");
    QCOMPARE(config2.count(), 0);
}


void TestQtNoidAppConfig::testConfigSchemaFromJson()
{
    Config config(this);

    // Create schema JSON
    QJsonObject schema;

    QJsonObject pageDetails({{"description", "Settings page"}});
    QJsonObject pageSchema({{"Settings",pageDetails}});
    QJsonArray pagesArray({pageSchema});
    QJsonObject schemaMain({{"label", "Loaded label"},
                            {"description", "Loaded description"},
                            {"tooltip", "Loaded tooltip"},
                            {"pages", pagesArray}});
    schema["LoadedConfig"] = schemaMain;

    // qDebug() << __func__ << schema;
    bool result = config.schemaFromJson(schema);
    // qDebug() << __func__ << config;

    QVERIFY(result);
    QCOMPARE(config.name(), "LoadedConfig");
    QCOMPARE(config.label(), "Loaded label");
    QCOMPARE(config.description(), "Loaded description");
    QCOMPARE(config.tooltip(), "Loaded tooltip");
    QVERIFY(config.contains("Settings"));
    QCOMPARE(config.parametersCount(), 0);

}

// Container management tests
void TestQtNoidAppConfig::testAppendPage()
{
    Config config(this);
    QSignalSpy pageSpy(&config, &Config::pageAdded);
    QVERIFY(pageSpy.isValid());

    ParametersPage* page = new ParametersPage("Page1", &config);
    bool result = config.append(page);

    QVERIFY(result);
    QCOMPARE(pageSpy.count(), 1);
    auto argument = pageSpy.takeFirst();
    auto actual = argument.at(0).value<ParametersPage*>();
    QCOMPARE(actual, page);

    QCOMPARE(config.count(), 1);
    QVERIFY(config.contains("Page1"));

    // Test appending nullptr
    result = config.append(nullptr);
    QVERIFY(!result);
    QCOMPARE(config.count(), 1);

    // Test appending page with duplicate name
    ParametersPage* duplicate = new ParametersPage("Page1", &config);
    result = config.append(duplicate);
    QVERIFY(!result);
    QCOMPARE(config.count(), 1);
    delete duplicate;

    // Test appending page with empty name
    ParametersPage* emptyName = new ParametersPage("", &config);
    result = config.append(emptyName);
    QVERIFY(!result);
    delete emptyName;

}

void TestQtNoidAppConfig::testAppendWithJson()
{
    Config config(this);

    QJsonObject pageSchema({{"description", "Page description"}});
    QJsonObject schema({{"Page1", pageSchema}});

    QJsonObject param1({{"Key","Value"}});
    QJsonObject param2({{"Int", 123}});
    QJsonArray params({{param1, param2}});
    QJsonObject valueMain({{"parameters", params}});
    QJsonObject value({{"Page1", valueMain}});

    bool result = config.append(schema, value);
    // qDebug() << __func__ << config;

    QVERIFY(result);
    QCOMPARE(config.count(), 1);
    QVERIFY(config.contains("Page1"));
    QCOMPARE(config.restoreAsString("Key", "", "Page1"), "Value");
    QCOMPARE(config.restoreAsInt("Int", 0, "Page1"), 123);
}

void TestQtNoidAppConfig::testEmplacePage()
{
    Config config(this);

    ParametersPage* page = config.emplace("Page1", "Page 1 description");

    QVERIFY(page != nullptr);
    QCOMPARE(config.count(), 1);
    QCOMPARE(page->name(), "Page1");
    QCOMPARE(page->description(), "Page 1 description");
    QVERIFY(config.contains("Page1"));

    // Test emplace with empty name
    ParametersPage* emptyPage = config.emplace("");
    QVERIFY(emptyPage == nullptr);
    QCOMPARE(config.count(), 1);

    // Test emplace with duplicate name
    ParametersPage* duplicate = config.emplace("Page1");
    QVERIFY(duplicate == nullptr);
    QCOMPARE(config.count(), 1);
}

void TestQtNoidAppConfig::testEmplaceWithJson()
{
    Config config(this);

    QJsonObject schemaPageMain({{"description", "Page description"},
                                {"tooltip", "Page Tooltip"}});
    QJsonObject schemaPage({{"DriversPage", schemaPageMain}});

    QJsonObject value1({{"Citizenship", true}});
    QJsonObject value2({{"DrivingLicenseNumber", 12345}});
    QJsonObject valueMain({{"parameters", QJsonArray({value1, value2})}});
    QJsonObject value({{"DriversPage", valueMain}});

    ParametersPage* page = config.emplace(schemaPage, value);
    // qDebug() << __func__ << page;

    QVERIFY(page != nullptr);
    QCOMPARE(config.count(), 1);
    QVERIFY(config.contains("DriversPage"));

    QCOMPARE(config.restoreAsBool("Citizenship", false, "DriversPage"), true);
    QCOMPARE(config.restoreAsInt("DrivingLicenseNumber", 0, "DriversPage"), 12345);
}

void TestQtNoidAppConfig::testRemovePage()
{
    Config config(this);
    QSignalSpy spy(&config, &Config::pageRemoved);

    ParametersPage* page1 = config.emplace("Page1");
    ParametersPage* page2 = config.emplace("Page2");
    ParametersPage* page3 = config.emplace("Page3");
    QCOMPARE(config.count(), 3);

    config.remove(page1);   // Remove by reference
    QCOMPARE(spy.count(), 1);
    auto args = spy.takeFirst();
    auto actual = args.at(0).value<ParametersPage*>();
    QCOMPARE(actual, page1);


    config.remove("Page2"); // Remove by Name
    QCOMPARE(spy.count(), 1);
    args = spy.takeFirst();
    actual = args.at(0).value<ParametersPage*>();
    QCOMPARE(actual, page2);

    // I left Page3 on purpose
    QCOMPARE(config.count(), 1);
    QVERIFY(!config.contains(page1));
    QVERIFY(!config.contains(page2));
    QVERIFY(config.contains(page3));
    QVERIFY(config.contains("Page3"));

}

void TestQtNoidAppConfig::testRemoveNonExistentPage()
{
    Config config(this);

    config.emplace("Page1");
    config.emplace("Page2");

    QSignalSpy spy(&config, &Config::pageRemoved);
    QVERIFY(spy.isValid());

    // Test removing nullptr
    config.remove(static_cast<ParametersPage*>(nullptr));
    QCOMPARE(config.count(), 2);
    QCOMPARE(spy.count(), 0);

    config.remove("NonExistentPage");
    QCOMPARE(config.count(), 2);
    QCOMPARE(spy.count(), 0);

    // Test removing not related page: this must not fire pageRemoved for a
    // page that was never part of this Config.
    ParametersPage list(this);
    config.remove(&list);
    QCOMPARE(config.count(), 2);
    QCOMPARE(spy.count(), 0);
}

void TestQtNoidAppConfig::testDeletingPageDirectlyUpdatesConfigBookkeeping()
{
    Config config(this);

    ParametersPage* page = config.emplace("Page1");
    QVERIFY(page != nullptr);
    QCOMPARE(config.count(), 1);

    page->setName("Page1Rename");
    QVERIFY(config.contains("Page1Rename"));

    QSignalSpy spy(&config, &Config::pageRemoved);
    QVERIFY(spy.isValid());

    // Delete the page directly, NOT through Config::remove(). This only
    // updates Config's bookkeeping if it reacts to
    // ParametersPage::aboutToBeDestroyed: the generic QObject::destroyed()
    // fires from inside ~QObject(), after ~ParametersPage() has already run,
    // so a qobject_cast<ParametersPage*> on that signal's sender is always
    // nullptr and such a handler is dead code.
    delete page;

    QCOMPARE(spy.count(), 1);
    QCOMPARE(config.count(), 0);
    QVERIFY(config.isEmpty());
    QVERIFY(!config.contains("Page1Rename"));
}

void TestQtNoidAppConfig::testDeletingChangedPageDirectlyUpdatesIsValueModified()
{
    Config config(this);

    ParametersPage* page = new ParametersPage("Page1");
    Parameter* p1 = page->emplace(10, "Param1");
    config << page;

    p1->setValue(99);
    QCOMPARE(config.isValueModified(), true);

    QSignalSpy spy(&config, &Config::isValueModifiedChanged);

    // Delete the page directly (not through Config::remove()): this only
    // decrements Config's counter correctly if onPageAboutToBeDestroyed()
    // uses the wasChanged argument carried by ParametersPage::aboutToBeDestroyed,
    // since by the time the generic QObject::destroyed() mechanics would run,
    // page->isValueModified() could no longer be queried safely.
    delete page;

    QCOMPARE(config.isValueModified(), false);
    QCOMPARE(spy.count(), 1);
    QCOMPARE(spy.takeFirst().at(0).toBool(), false);
}

void TestQtNoidAppConfig::testRenamingRemovedPageDoesNotAffectConfig()
{
    Config config(this);

    ParametersPage* page = config.emplace("Page1");
    QVERIFY(page != nullptr);

    config.remove(page);
    QCOMPARE(config.count(), 0);

    QSignalSpy spy(&config, &Config::pageRenameError);
    QVERIFY(spy.isValid());

    // The page is still alive (parented to config, not deleted) but no
    // longer part of it so it should not trigger Config::onPageNameEdited()
    // that happens when there is a rename of a non existing page
    page->setName("Page1Renamed");

    QCOMPARE(spy.count(), 0);
    QVERIFY(!config.contains("Page1"));
    QVERIFY(!config.contains("Page1Renamed"));
}

void TestQtNoidAppConfig::testRenamingClearedPageDoesNotAffectConfig()
{
    Config config(this);

    ParametersPage* page = config.emplace("Page1");
    QVERIFY(page != nullptr);

    config.clear();
    QCOMPARE(config.count(), 0);

    QSignalSpy spy(&config, &Config::pageRenameError);
    QVERIFY(spy.isValid());

    page->setName("Page1Renamed");

    QCOMPARE(spy.count(), 0);
    QVERIFY(!config.contains("Page1"));
    QVERIFY(!config.contains("Page1Renamed"));
}

void TestQtNoidAppConfig::testClearPages()
{
    Config config(this);

    config.emplace("Page1");
    config.emplace("Page2");
    config.emplace("Page3");

    QCOMPARE(config.count(), 3);

    config.clear();

    QCOMPARE(config.count(), 0);
    QVERIFY(config.isEmpty());

    // Test clearing empty config
    config.clear();
    QCOMPARE(config.count(), 0);

}

void TestQtNoidAppConfig::testIsEmpty()
{
    Config config(this);
    QVERIFY(config.isEmpty());

    config.emplace("Page1");
    QVERIFY(!config.isEmpty());

    config.clear();
    QVERIFY(config.isEmpty());

}

// Access methods tests
void TestQtNoidAppConfig::testPageByIndex()
{
    Config config(this);

    ParametersPage* page1 = config.emplace("Page1");
    ParametersPage* page2 = config.emplace("Page2");

    QCOMPARE(config.page(0), page1);
    QCOMPARE(config.page(1), page2);

    // Test out of bounds
    QVERIFY(config.page(10) == nullptr);
    QVERIFY(config.page(-1) == nullptr);
}

void TestQtNoidAppConfig::testPageByName()
{
    Config config(this);

    ParametersPage* page1 = config.emplace("Page1");
    ParametersPage* page2 = config.emplace("Page2");

    QCOMPARE(config.page("Page1"), page1);
    QCOMPARE(config.page("Page2"), page2);

    // Test non-existent page
    QVERIFY(config.page("NonExistent") == nullptr);

}

void TestQtNoidAppConfig::testIndexOfPage()
{
    Config config(this);

    ParametersPage* page1 = config.emplace("Page1");
    ParametersPage* page2 = config.emplace("Page2");

    // index using object
    QCOMPARE(config.indexOf(page1), 0);
    QCOMPARE(config.indexOf(page2), 1);

    // index using name
    QCOMPARE(config.indexOf("Page1"), 0);
    QCOMPARE(config.indexOf("Page2"), 1);

    // Test non-existent page
    ParametersPage* external = new ParametersPage("External");
    QCOMPARE(config.indexOf(external), -1);
    QCOMPARE(config.indexOf("external"), -1);

    delete external;

}


void TestQtNoidAppConfig::testContainsPage()
{
    Config config(this);

    ParametersPage* page1 = config.emplace("Page1");

    QVERIFY(config.contains(page1));
    QVERIFY(config.contains("Page1"));

    // Test non-existent page
    ParametersPage* external = new ParametersPage("External");
    QVERIFY(!config.contains(external));
    QVERIFY(!config.contains("external"));
    delete external;

}

void TestQtNoidAppConfig::testPagesList()
{
    Config config(this);

    ParametersPage* page1 = config.emplace("Page1");
    ParametersPage* page2 = config.emplace("Page2");
    ParametersPage* page3 = config.emplace("Page3");

    QList<ParametersPage*> pages = config.pages();


    QCOMPARE(pages.size(), 3);
    QVERIFY(pages.contains(page1));
    QVERIFY(pages.contains(page2));
    QVERIFY(pages.contains(page3));

}

void TestQtNoidAppConfig::testParameterAndPageRenameShouldAutomaticallyUpdate()
{
    Config config("AppConfig", this);

    // Create parameter and page
    Parameter parameter(123, "PARAM", this);
    ParametersPage page("PAGE", this);
    page << parameter;
    config << page;
    // qDebug() << __func__ << config;

    // Try to rename the value
    parameter.setName("ParamNewName");
    page.setName("PageNewName");
    // qDebug() << __func__ << config;

    // Check the new names are in place
    auto actual = config.restoreAsInt("ParamNewName", -1, "PageNewName");
    QCOMPARE(actual, 123);
}


// Parameter access tests
void TestQtNoidAppConfig::testParameterAccess()
{
    Config config(this);

    config.saveValue("Volume", 75);

    Parameter* param = config.parameter("Volume", "Settings");
    QVERIFY(param != nullptr);
    QCOMPARE(param->name(), "Volume");
    QCOMPARE(param->value(), 75);


    // Test non-existent parameter
    Parameter* nonExistent = config.parameter("NonExistent", "Settings");
    QVERIFY(nonExistent == nullptr);


    // Test non-existent page
    Parameter* nonExistentPage = config.parameter("Volume", "NonExistentPage");
    QVERIFY(nonExistentPage == nullptr);
}

void TestQtNoidAppConfig::testParametersCount()
{
    Config config(this);

    // Test 1: Count with default page name "Settings" - page doesn't exist yet
    int count = config.parametersCount();
    QCOMPARE(count, 0);

    // Test 2: Count after adding parameters to default "Settings" page
    config.saveValue("Volume", 75);
    config.saveValue("Theme", "dark");
    config.saveValue("Language", "en");
    count = config.parametersCount();
    QCOMPARE(count, 3);

    // Test 3: Count with explicit "Settings" page name
    count = config.parametersCount("Settings");
    QCOMPARE(count, 3);

    // Test 4: Count for non-existent page
    count = config.parametersCount("NonExistentPage");
    QCOMPARE(count, 0);

    // Test 5: Count with custom page name
    config.saveValue("Width", 1920, "Display");
    config.saveValue("Height", 1080, "Display");
    count = config.parametersCount("Display");
    QCOMPARE(count, 2);

    // Verify Settings page still has 3 parameters
    count = config.parametersCount("Settings");
    QCOMPARE(count, 3);

    // Test 6: Count for empty page
    config.emplace("EmptyPage");
    count = config.parametersCount("EmptyPage");
    QCOMPARE(count, 0);

    // Test 7: Count after adding parameters to previously empty page
    config.saveValue("Key1", "Value1", "EmptyPage");
    config.saveValue("Key2", "Value2", "EmptyPage");
    count = config.parametersCount("EmptyPage");
    QCOMPARE(count, 2);

    // Test 8: Verify count doesn't change when updating existing parameter
    config.saveValue("Volume", 50); // Update existing
    count = config.parametersCount("Settings");
    QCOMPARE(count, 3); // Should still be 3
}

void TestQtNoidAppConfig::testOperatorStreamInsert()
{
    Config config(this);
    QSignalSpy pageAddedSpy(&config, &Config::pageAdded);
    QSignalSpy countSpy(&config, &Config::countChanged);

    // Test 1: operator<< with ParametersPage reference
    ParametersPage page1("Page1", &config);
    config << page1;

    QCOMPARE(config.count(), 1);
    QVERIFY(config.contains("Page1"));
    QCOMPARE(config.page(0), &page1);
    QCOMPARE(pageAddedSpy.count(), 1);
    QCOMPARE(countSpy.count(), 1);

    // Test 2: operator<< with ParametersPage pointer
    ParametersPage* page2 = new ParametersPage("Page2", &config);
    config << page2;

    QCOMPARE(config.count(), 2);
    QVERIFY(config.contains("Page2"));
    QCOMPARE(config.page(1), page2);
    QCOMPARE(pageAddedSpy.count(), 2);
    QCOMPARE(countSpy.count(), 2);

    // Test 3: Chaining operator<< calls
    ParametersPage* page3 = new ParametersPage("Page3", &config);
    ParametersPage* page4 = new ParametersPage("Page4", &config);
    config << page3 << page4;

    QCOMPARE(config.count(), 4);
    QVERIFY(config.contains("Page3"));
    QVERIFY(config.contains("Page4"));
    QCOMPARE(pageAddedSpy.count(), 4);
    QCOMPARE(countSpy.count(), 4);

    // Test 4: operator<< with nullptr pointer (should do nothing)
    ParametersPage* nullPage = nullptr;
    config << nullPage;

    QCOMPARE(config.count(), 4); // Count should not change
    QCOMPARE(pageAddedSpy.count(), 4); // No signal should be emitted

    // Test 5: operator<< with duplicate name (should fail but not crash)
    ParametersPage* duplicate = new ParametersPage("Page1", &config);
    config << duplicate;

    QCOMPARE(config.count(), 4); // Count should not change
    QCOMPARE(pageAddedSpy.count(), 4); // No signal should be emitted
    delete duplicate; // Clean up since it wasn't added

    // Test 6: operator<< with empty name (should fail)
    ParametersPage* emptyName = new ParametersPage("", &config);
    config << emptyName;

    QCOMPARE(config.count(), 4); // Count should not change
    QCOMPARE(pageAddedSpy.count(), 4); // No signal should be emitted
    delete emptyName; // Clean up since it wasn't added

    // Test 7: Verify that operator<< returns Config reference for chaining
    Config config2(this);
    ParametersPage page5("Page5", &config2);
    ParametersPage page6("Page6", &config2);

    Config& result = (config2 << page5 << page6);

    QCOMPARE(&result, &config2); // Should return reference to same object
    QCOMPARE(config2.count(), 2);

    // Test 8: Mixed reference and pointer chaining
    Config config3(this);
    ParametersPage pageRef("PageRef", &config3);
    ParametersPage* pagePtr = new ParametersPage("PagePtr", &config3);

    config3 << pageRef << pagePtr;

    QCOMPARE(config3.count(), 2);
    QVERIFY(config3.contains("PageRef"));
    QVERIFY(config3.contains("PagePtr"));
}

// Save/restore value tests
void TestQtNoidAppConfig::testSaveAndRestoreInt()
{
    Config config(this);

    bool result = config.saveValue("Volume", 75);
    QVERIFY(result);

    int value = config.restoreAsInt("Volume", 0);
    QCOMPARE(value, 75);

    // Test default value
    int defaultValue = config.restoreAsInt("NonExistent", 100);
    QCOMPARE(defaultValue, 100);

    // Test updating value
    config.saveValue("Volume", 50);
    value = config.restoreAsInt("Volume", 0);
    QCOMPARE(value, 50);
}

void TestQtNoidAppConfig::testSaveAndRestoreDouble()
{
    Config config(this);

    bool result = config.saveValue("Opacity", 0.75);
    QVERIFY(result);

    double value = config.restoreAsDouble("Opacity", 0.0);
    QCOMPARE(value, 0.75);

    // Test default value
    double defaultValue = config.restoreAsDouble("NonExistent", 1.0);
    QCOMPARE(defaultValue, 1.0);
}

void TestQtNoidAppConfig::testSaveAndRestoreString()
{
    Config config(this);

    bool result = config.saveValue("Theme", QString("dark"));
    QVERIFY(result);

    QString value = config.restoreAsString("Theme", "");
    QCOMPARE(value, "dark");

    // Test default value
    QString defaultValue = config.restoreAsString("NonExistent", "light");
    QCOMPARE(defaultValue, "light");
}

void TestQtNoidAppConfig::testSaveAndRestoreBool()
{
    Config config(this);

    bool result = config.saveValue("Enabled", true);
    QVERIFY(result);

    bool value = config.restoreAsBool("Enabled", false);
    QCOMPARE(value, true);

    // Test default value
    bool defaultValue = config.restoreAsBool("NonExistent", false);
    QCOMPARE(defaultValue, false);
}

void TestQtNoidAppConfig::testSaveAndRestoreStringList()
{
    Config config(this);

    QStringList list = {"item1", "item2", "item3"};
    bool result = config.saveValue("Items", list);
    QVERIFY(result);

    QStringList value = config.restoreAsStringList("Items", QStringList());
    QCOMPARE(value.size(), 3);
    QCOMPARE(value, list);

    // Test default value
    QStringList defaultList = {"default1"};
    QStringList defaultValue = config.restoreAsStringList("NonExistent", defaultList);
    QCOMPARE(defaultValue, defaultList);
}

void TestQtNoidAppConfig::testSaveAndRestoreVariant()
{
    Config config(this);

    QVariant variant(42);
    bool result = config.saveValue("Value", variant);
    QVERIFY(result);

    QVariant value = config.restoreAsVariant("Value", QVariant());
    QCOMPARE(value.toInt(), 42);

    // Test default value
    QVariant defaultVariant("default");
    QVariant defaultValue = config.restoreAsVariant("NonExistent", defaultVariant);
    QCOMPARE(defaultValue.toString(), "default");
}

void TestQtNoidAppConfig::testSaveAndRestoreByteArray()
{
    Config config(this);

    QByteArray data = "Hello World";
    bool result = config.saveValue("Data", data);
    QVERIFY(result);

    QByteArray value = config.restoreAsByteArray("Data", QByteArray());
    QCOMPARE(value, data);

    // Test default value
    QByteArray defaultData = "default";
    QByteArray defaultValue = config.restoreAsByteArray("NonExistent", defaultData);
    QCOMPARE(defaultValue, defaultData);
}

void TestQtNoidAppConfig::testSaveAndRestoreJsonObject()
{
    Config config(this);

    // A nested object, to make sure the round trip through the QVariant
    // (which holds the QJsonObject directly, not as text) survives more
    // than just flat key/value pairs.
    QJsonObject json;
    json["name"] = "test";
    json["count"] = 42;
    json["value"] = 42.53;
    json["tags"] = QJsonArray{"a", "b", "c"};
    QJsonObject nested;
    nested["enabled"] = true;
    json["nested"] = nested;

    bool result = config.saveValue("Data", json);
    QVERIFY(result);

    QJsonObject value = config.restoreAsJson("Data", QJsonObject());
    QCOMPARE(value, json);

    // Test default value
    QJsonObject defaultJson;
    defaultJson["default"] = true;
    QJsonObject defaultValue = config.restoreAsJson("NonExistent", defaultJson);
    QCOMPARE(defaultValue, defaultJson);
}

void TestQtNoidAppConfig::testRestoreAsJsonObjectWithInvalidStoredDataReturnsDefault()
{
    Config config(this);

    // Store a plain string under the parameter directly (bypassing
    // saveValue(QJsonObject)), to exercise the not-an-object fallback in
    // restoreAsJson() rather than crashing or returning a garbage object.
    bool result = config.saveValue("Data", QString("not valid json"));
    QVERIFY(result);

    QJsonObject defaultJson;
    defaultJson["default"] = true;
    QJsonObject value = config.restoreAsJson("Data", defaultJson);
    QCOMPARE(value, defaultJson);
}

// Signal tests
void TestQtNoidAppConfig::testNameChangedSignal()
{
    Config config(this);
    QSignalSpy spy(&config, &Config::nameChanged);

    config.setName("TestName");
    QCOMPARE(spy.count(), 1);
    auto arguments = spy.takeFirst();
    QCOMPARE(arguments.at(0).toString(), "TestName");

    config.setName("NewName");
    QCOMPARE(spy.count(), 1);
    arguments = spy.takeFirst();
    QCOMPARE(arguments.at(0).toString(), "NewName");

}

void TestQtNoidAppConfig::testLabelChangedSignal()
{
    Config config(this);
    QSignalSpy spy(&config, &Config::labelChanged);

    config.setLabel("Test label");
    QCOMPARE(spy.count(), 1);
    auto arguments = spy.takeFirst();
    QCOMPARE(arguments.at(0).toString(), "Test label");
}

void TestQtNoidAppConfig::testDescriptionChangedSignal()
{
    Config config(this);
    QSignalSpy spy(&config, &Config::descriptionChanged);

    config.setDescription("Test description");
    QCOMPARE(spy.count(), 1);
    auto arguments = spy.takeFirst();
    QCOMPARE(arguments.at(0).toString(), "Test description");
}


void TestQtNoidAppConfig::testTooltipChangedSignal()
{
    Config config(this);
    QSignalSpy spy(&config, &Config::tooltipChanged);

    config.setTooltip("Test tooltip");
    QCOMPARE(spy.count(), 1);
    auto arguments = spy.takeFirst();
    QCOMPARE(arguments.at(0).toString(), "Test tooltip");

}

void TestQtNoidAppConfig::testCountChangedSignal()
{
    Config config(this);
    QSignalSpy spy(&config, &Config::countChanged);

    config.emplace("Page1");
    QCOMPARE(spy.count(), 1);
    auto arguments = spy.takeFirst();
    QCOMPARE(arguments.at(0).toInt(), 1);

    config.emplace("Page2");
    QCOMPARE(spy.count(), 1);
    arguments = spy.takeFirst();
    QCOMPARE(arguments.at(0).toInt(), 2);

    config.clear();
    QCOMPARE(spy.count(), 1);
    arguments = spy.takeFirst();
    QCOMPARE(arguments.at(0).toInt(), 0);
}


void TestQtNoidAppConfig::testPageAddedSignal()
{
    Config config(this);
    QSignalSpy spy(&config, &Config::pageAdded);

    auto page1 = config.emplace("Page1");
    QCOMPARE(spy.count(), 1);
    auto param = spy.takeFirst();
    QCOMPARE(param.at(0).value<ParametersPage*>(), page1);

    auto page2 = config.emplace("Page2");
    QCOMPARE(spy.count(), 1);
    param = spy.takeFirst();
    QCOMPARE(param.at(0).value<ParametersPage*>(), page2);
}


void TestQtNoidAppConfig::testPageRemovedSignal()
{
    Config config(this);
    QSignalSpy spy(&config, &Config::pageRemoved);

    ParametersPage* page1 = config.emplace("Page1");
    ParametersPage* page2 = config.emplace("Page2");

    config.remove(page1);
    QCOMPARE(spy.count(), 1);
    auto param = spy.takeFirst();
    QCOMPARE(param.at(0).value<ParametersPage*>(), page1);


    config.remove("Page2");
    QCOMPARE(spy.count(), 1);
    param = spy.takeFirst();
    QCOMPARE(param.at(0).value<ParametersPage*>(), page2);

}

void TestQtNoidAppConfig::testPageRenameErrorSignal()
{
    Config config(this);

    config.emplace("Page1");
    config.emplace("Page2");

    QSignalSpy spy(&config, &Config::pageRenameError);

    ParametersPage* page1 = config.page("Page1");

    // Try to rename to an existing name - should trigger error
    page1->setName("Page2");


    QCOMPARE(spy.count(), 1);
    QList<QVariant> arguments = spy.takeFirst();
    QCOMPARE(arguments.at(0).toString(), "Page1");
    QCOMPARE(arguments.at(1).toString(), "Page2");

}

void TestQtNoidAppConfig::testAboutToBeDestroyedSignal()
{
    auto config = new Config("TestConfig");
    const quintptr expectedAddress = reinterpret_cast<quintptr>(config);

    QSignalSpy spy(config, &Config::aboutToBeDestroyed);
    QVERIFY(spy.isValid());

    delete config;

    // qDebug() << "0x" << Qt::hex << expectedAddress;

    QCOMPARE(spy.count(), 1);
    QList<QVariant> arguments = spy.takeFirst();
    QCOMPARE(reinterpret_cast<quintptr>(arguments.at(0).value<Config*>()), expectedAddress);
}


void TestQtNoidAppConfig::testConfigBeginAndEndAndRangeLoop()
{
    Config config("TestConfig", this);

    // Test empty config
    QVERIFY(config.begin() == config.end());

    // Add some pages
    config.emplace("First", "First page");
    config.emplace("Second", "Second page");
    config.emplace("Third", "Third page");

    // Test that begin() != end() for non-empty config
    QVERIFY(config.begin() != config.end());

    // Test iterator dereferencing
    Config::iterator it = config.begin();
    QVERIFY(it != config.end());

    ParametersPage* firstPage = *it;
    QVERIFY(firstPage != nullptr);
    QCOMPARE(firstPage->name(), "First");
    QCOMPARE(firstPage->description(), "First page");

    // Test iterator increment
    ++it;
    QVERIFY(it != config.end());
    ParametersPage* secondPage = *it;
    QVERIFY(secondPage != nullptr);
    QCOMPARE(secondPage->name(), "Second");
    QCOMPARE(secondPage->description(), "Second page");

    // Test post-increment
    auto prevIt = it++;
    QVERIFY(it != config.end());
    QVERIFY(prevIt != it);
    ParametersPage* thirdPage = *it;
    QVERIFY(thirdPage != nullptr);
    QCOMPARE(thirdPage->name(), "Third");
    QCOMPARE(thirdPage->description(), "Third page");

    // Test iterator index() method
    QCOMPARE(config.begin().index(), 0);
    auto secondIt = config.begin();
    ++secondIt;
    QCOMPARE(secondIt.index(), 1);

    // Test bidirectional iterator (decrement)
    auto lastIt = config.end();
    --lastIt;
    ParametersPage* lastPage = *lastIt;
    QVERIFY(lastPage != nullptr);
    QCOMPARE(lastPage->name(), "Third");
    QCOMPARE(lastPage->description(), "Third page");

    // Test post-decrement
    auto postDecIt = lastIt--;
    QCOMPARE((*postDecIt)->name(), "Third");
    QCOMPARE((*lastIt)->name(), "Second");

    // Test range-based for loop
    QStringList expectedList = {"First", "Second", "Third"};
    QStringList nameList;
    for(auto page : config){
        nameList << page->name();
    }
    QCOMPARE(nameList, expectedList);
}

void TestQtNoidAppConfig::testConfigConstIteratorsAndConstRangeLoop()
{
    Config config("TestConfig", this);

    // Add some pages
    config.emplace("Alpha", "Alpha page");
    config.emplace("Beta", "Beta page");
    config.emplace("Gamma", "Gamma page");

    // Create a const reference to the config
    const Config& constConfig = config;

    // ===== Test begin() const and end() const =====
    // Test empty vs non-empty
    QVERIFY(constConfig.begin() != constConfig.end());

    // Test const iterator dereferencing
    Config::const_iterator cit = constConfig.begin();
    const ParametersPage* firstPage = *cit;
    QVERIFY(firstPage != nullptr);
    QCOMPARE(firstPage->name(), "Alpha");
    QCOMPARE(firstPage->description(), "Alpha page");

    // Test const iterator increment
    ++cit;
    QVERIFY(cit != constConfig.end());
    const ParametersPage* secondPage = *cit;
    QVERIFY(secondPage != nullptr);
    QCOMPARE(secondPage->name(), "Beta");
    QCOMPARE(secondPage->description(), "Beta page");

    // Test post-increment
    auto prevCit = cit++;
    QVERIFY(prevCit != cit);
    const ParametersPage* thirdPage = *cit;
    QVERIFY(thirdPage != nullptr);
    QCOMPARE(thirdPage->name(), "Gamma");
    QCOMPARE(thirdPage->description(), "Gamma page");

    // Test reaching end
    ++cit;
    QVERIFY(cit == constConfig.end());

    // ===== Test cbegin() and cend() =====
    // Test that cbegin() != cend() for non-empty config
    QVERIFY(constConfig.cbegin() != constConfig.cend());

    // Test cbegin() dereferencing
    auto cbegIt = constConfig.cbegin();
    const ParametersPage* cbegPage = *cbegIt;
    QVERIFY(cbegPage != nullptr);
    QCOMPARE(cbegPage->name(), "Alpha");
    QCOMPARE(cbegPage->description(), "Alpha page");

    // Test cbegin() index method
    QCOMPARE(constConfig.cbegin().index(), 0);
    auto secondCbegIt = constConfig.cbegin();
    ++secondCbegIt;
    QCOMPARE(secondCbegIt.index(), 1);

    // ===== Test bidirectional const iterator operations =====
    // Test decrement from end
    auto lastCit = constConfig.cend();
    --lastCit;
    const ParametersPage* lastPage = *lastCit;
    QVERIFY(lastPage != nullptr);
    QCOMPARE(lastPage->name(), "Gamma");
    QCOMPARE(lastPage->description(), "Gamma page");

    // Test post-decrement
    auto postDecCit = lastCit--;
    QCOMPARE((*postDecCit)->name(), "Gamma");
    QCOMPARE((*lastCit)->name(), "Beta");

    // ===== Test iterator conversion from mutable to const =====
    // Test that mutable iterator can be converted to const iterator
    Config::iterator mutIt = config.begin();
    Config::const_iterator constFromMut = mutIt;

    QCOMPARE((*constFromMut)->name(), "Alpha");
    QCOMPARE((*constFromMut)->description(), "Alpha page");

    // Verify they point to the same element
    QVERIFY(*mutIt == *constFromMut);

    // ===== Test const range-based for loop =====
    QStringList constNames;
    QStringList constDescriptions;

    // Test const range-based for loop
    for (const ParametersPage* page : constConfig) {
        QVERIFY(page != nullptr);
        constNames << page->name();
        constDescriptions << page->description();
    }

    QCOMPARE(constNames.size(), 3);
    QCOMPARE(constNames, QStringList({"Alpha", "Beta", "Gamma"}));
    QCOMPARE(constDescriptions, QStringList({"Alpha page", "Beta page", "Gamma page"}));

    // ===== Test that const iterators prevent modification =====
    // This should compile (reading)
    auto constIt = constConfig.cbegin();
    QString pageName = (*constIt)->name();
    QCOMPARE(pageName, "Alpha");

    // ===== Test empty const config =====
    Config emptyConfig("EmptyTest", this);
    const Config& constEmptyConfig = emptyConfig;

    QVERIFY(constEmptyConfig.begin() == constEmptyConfig.end());
    QVERIFY(constEmptyConfig.cbegin() == constEmptyConfig.cend());

    // Test const range-based for loop with empty config
    int constCount = 0;
    for ([[maybe_unused]] const ParametersPage* page : constEmptyConfig) {
        constCount++;
    }
    QCOMPARE(constCount, 0);
}

void TestQtNoidAppConfig::testConfigReverseIteratorsAndRangeLoop()
{
    Config config("TestConfig", this);

    // Add some pages
    config.emplace("First", "First page");
    config.emplace("Second", "Second page");
    config.emplace("Third", "Third page");
    config.emplace("Fourth", "Fourth page");

    // ===== Test rbegin() and rend() basic functionality =====
    QVERIFY(config.rbegin() != config.rend());

    // Test reverse iterator dereferencing - should start from last element
    Config::reverse_iterator rit = config.rbegin();
    ParametersPage* lastPage = *rit;
    QVERIFY(lastPage != nullptr);
    QCOMPARE(lastPage->name(), "Fourth");  // Should be the last element
    QCOMPARE(lastPage->description(), "Fourth page");

    // ===== Test reverse iterator increment (moves backward through config) =====
    ++rit;
    QVERIFY(rit != config.rend());
    ParametersPage* thirdPage = *rit;
    QVERIFY(thirdPage != nullptr);
    QCOMPARE(thirdPage->name(), "Third");
    QCOMPARE(thirdPage->description(), "Third page");

    // Test post-increment
    auto prevRit = rit++;
    QVERIFY(rit != config.rend());
    QVERIFY(prevRit != rit);
    ParametersPage* secondPage = *rit;
    QVERIFY(secondPage != nullptr);
    QCOMPARE(secondPage->name(), "Second");
    QCOMPARE(secondPage->description(), "Second page");

    // Continue to first element
    ++rit;
    QVERIFY(rit != config.rend());
    ParametersPage* firstPage = *rit;
    QVERIFY(firstPage != nullptr);
    QCOMPARE(firstPage->name(), "First");
    QCOMPARE(firstPage->description(), "First page");

    // Test reaching rend()
    ++rit;
    QVERIFY(rit == config.rend());

    // ===== Test reverse iterator range-based for loop simulation =====
    QStringList reverseNames;
    QStringList reverseDescriptions;

    // Manually iterate through reverse iterators
    for (auto revIt = config.rbegin(); revIt != config.rend(); ++revIt) {
        ParametersPage* page = *revIt;
        QVERIFY(page != nullptr);
        reverseNames << page->name();
        reverseDescriptions << page->description();
    }

    // Verify reverse order
    QCOMPARE(reverseNames.size(), 4);
    QCOMPARE(reverseNames, QStringList({"Fourth", "Third", "Second", "First"}));
    QCOMPARE(reverseDescriptions, QStringList({"Fourth page", "Third page", "Second page", "First page"}));

    // ===== Test reverse iterator arrow operator =====
    auto rbeginIt = config.rbegin();
    QCOMPARE((*rbeginIt)->name(), "Fourth");
    QCOMPARE((*rbeginIt)->description(), "Fourth page");

    // ===== Test relationship between normal and reverse iterators =====
    // rbegin() should correspond to the element before end()
    auto normalEnd = config.end();
    --normalEnd;
    auto reverseBegin = config.rbegin();
    QCOMPARE((*normalEnd)->name(), (*reverseBegin)->name());
    QCOMPARE((*normalEnd)->description(), (*reverseBegin)->description());

    // ===== Test empty config reverse iterators =====
    Config emptyConfig("EmptyTest", this);
    QVERIFY(emptyConfig.rbegin() == emptyConfig.rend());

    // Test reverse iteration over empty config
    int reverseCount = 0;
    for (auto revIt = emptyConfig.rbegin(); revIt != emptyConfig.rend(); ++revIt) {
        reverseCount++;
    }
    QCOMPARE(reverseCount, 0);

    // ===== Test reverse iterator with std::reverse algorithm simulation =====
    // Use reverse iterators to create a reversed copy
    QStringList normalOrder;
    QStringList reversedOrder;

    // Normal order
    for (auto it = config.begin(); it != config.end(); ++it) {
        normalOrder << (*it)->name();
    }

    // Reversed order using reverse iterators
    for (auto rit = config.rbegin(); rit != config.rend(); ++rit) {
        reversedOrder << (*rit)->name();
    }

    // Verify they are opposite
    QCOMPARE(normalOrder, QStringList({"First", "Second", "Third", "Fourth"}));
    QCOMPARE(reversedOrder, QStringList({"Fourth", "Third", "Second", "First"}));

    // ===== Test reverse iterator decrement (moves forward through config) =====
    // Start from rbegin() and use decrement to move "forward" in reverse direction
    auto rLastIt = config.rbegin();
    ++rLastIt; ++rLastIt; ++rLastIt; // Move to "First"
    QCOMPARE((*rLastIt)->name(), "First");

    // Test pre-decrement (should move to "Second")
    --rLastIt;
    QCOMPARE((*rLastIt)->name(), "Second");

    // Test post-decrement
    auto postDecRit = rLastIt--;
    QCOMPARE((*postDecRit)->name(), "Second");
    QCOMPARE((*rLastIt)->name(), "Third");
}

void TestQtNoidAppConfig::testConfigConstReverseIterators()
{
    Config config("TestConfig", this);

    // Add some pages
    config.emplace("First", "First page");
    config.emplace("Second", "Second page");
    config.emplace("Third", "Third page");
    config.emplace("Fourth", "Fourth page");

    // Create a const reference to the config
    const Config& constConfig = config;

    // ===== Test rbegin() const and rend() const =====
    // Test that const rbegin() != rend() for non-empty config
    QVERIFY(constConfig.rbegin() != constConfig.rend());

    // Test const reverse iterator dereferencing - should start from last element
    Config::const_reverse_iterator crit = constConfig.rbegin();
    QVERIFY(crit != constConfig.rend());

    const ParametersPage* lastPage = *crit;
    QVERIFY(lastPage != nullptr);
    QCOMPARE(lastPage->name(), "Fourth");  // Should be the last element
    QCOMPARE(lastPage->description(), "Fourth page");

    // ===== Test const reverse iterator increment (moves backward through config) =====
    // Test pre-increment (moves to previous element in normal order)
    ++crit;
    QVERIFY(crit != constConfig.rend());
    const ParametersPage* thirdPage = *crit;
    QVERIFY(thirdPage != nullptr);
    QCOMPARE(thirdPage->name(), "Third");
    QCOMPARE(thirdPage->description(), "Third page");

    // Test post-increment
    auto prevCrit = crit++;
    QVERIFY(crit != constConfig.rend());
    QVERIFY(prevCrit != crit);
    const ParametersPage* secondPage = *crit;
    QVERIFY(secondPage != nullptr);
    QCOMPARE(secondPage->name(), "Second");
    QCOMPARE(secondPage->description(), "Second page");

    // Continue to first element
    ++crit;
    QVERIFY(crit != constConfig.rend());
    const ParametersPage* firstPage = *crit;
    QVERIFY(firstPage != nullptr);
    QCOMPARE(firstPage->name(), "First");
    QCOMPARE(firstPage->description(), "First page");

    // Test reaching rend()
    ++crit;
    QVERIFY(crit == constConfig.rend());

    // ===== Test crbegin() and crend() =====
    // Test that crbegin() != crend() for non-empty config
    QVERIFY(constConfig.crbegin() != constConfig.crend());

    // Test crbegin() dereferencing - should start from last element
    Config::const_reverse_iterator crbit = constConfig.crbegin();
    QVERIFY(crbit != constConfig.crend());

    const ParametersPage* crbPage = *crbit;
    QVERIFY(crbPage != nullptr);
    QCOMPARE(crbPage->name(), "Fourth");
    QCOMPARE(crbPage->description(), "Fourth page");

    // Test crbegin() increment
    ++crbit;
    QVERIFY(crbit != constConfig.crend());
    const ParametersPage* crbSecondPage = *crbit;
    QVERIFY(crbSecondPage != nullptr);
    QCOMPARE(crbSecondPage->name(), "Third");
    QCOMPARE(crbSecondPage->description(), "Third page");

    // ===== Test const reverse iterator range-based for loop simulation =====
    QStringList constReverseNames;
    QStringList constReverseDescriptions;

    // Manually iterate through const reverse iterators using rbegin() const
    for (auto constRevIt = constConfig.rbegin(); constRevIt != constConfig.rend(); ++constRevIt) {
        const ParametersPage* page = *constRevIt;
        QVERIFY(page != nullptr);
        constReverseNames << page->name();
        constReverseDescriptions << page->description();
    }

    // Verify const reverse order
    QCOMPARE(constReverseNames.size(), 4);
    QCOMPARE(constReverseNames, QStringList({"Fourth", "Third", "Second", "First"}));
    QCOMPARE(constReverseDescriptions, QStringList({"Fourth page", "Third page", "Second page", "First page"}));

    // ===== Test const reverse iterator range-based for loop with crbegin/crend =====
    QStringList crNames;
    QStringList crDescriptions;

    // Manually iterate through const reverse iterators using crbegin()/crend()
    for (auto crIt = constConfig.crbegin(); crIt != constConfig.crend(); ++crIt) {
        const ParametersPage* page = *crIt;
        QVERIFY(page != nullptr);
        crNames << page->name();
        crDescriptions << page->description();
    }

    // Verify crbegin/crend produces same result as rbegin/rend const
    QCOMPARE(crNames, constReverseNames);
    QCOMPARE(crDescriptions, constReverseDescriptions);

    // ===== Test const reverse iterator arrow operator =====
    auto crbeginIt = constConfig.crbegin();
    QCOMPARE((*crbeginIt)->name(), "Fourth");
    QCOMPARE((*crbeginIt)->description(), "Fourth page");

    auto rbeginConstIt = constConfig.rbegin();
    QCOMPARE((*rbeginConstIt)->name(), "Fourth");
    QCOMPARE((*rbeginConstIt)->description(), "Fourth page");

    // ===== Test relationship between const normal and const reverse iterators =====
    // rbegin() const should correspond to the element before end() const
    auto constNormalEnd = constConfig.end();
    --constNormalEnd;
    auto constReverseBegin = constConfig.rbegin();

    QCOMPARE((*constNormalEnd)->name(), (*constReverseBegin)->name());
    QCOMPARE((*constNormalEnd)->description(), (*constReverseBegin)->description());

    // Same test for crbegin() and cend()
    auto constCEnd = constConfig.cend();
    --constCEnd;
    auto constCRBegin = constConfig.crbegin();

    QCOMPARE((*constCEnd)->name(), (*constCRBegin)->name());
    QCOMPARE((*constCEnd)->description(), (*constCRBegin)->description());

    // ===== Test empty const config reverse iterators =====
    Config emptyConfig("EmptyTest", this);
    const Config& constEmptyConfig = emptyConfig;

    QVERIFY(constEmptyConfig.rbegin() == constEmptyConfig.rend());
    QVERIFY(constEmptyConfig.crbegin() == constEmptyConfig.crend());

    // Test const reverse iteration over empty config
    int constReverseCount = 0;
    for (auto constRevIt = constEmptyConfig.rbegin(); constRevIt != constEmptyConfig.rend(); ++constRevIt) {
        constReverseCount++;
    }
    QCOMPARE(constReverseCount, 0);

    // Test crbegin/crend with empty config
    int crCount = 0;
    for (auto crIt = constEmptyConfig.crbegin(); crIt != constEmptyConfig.crend(); ++crIt) {
        crCount++;
    }
    QCOMPARE(crCount, 0);

    // ===== Test const correctness =====
    // This should compile (reading from const iterator)
    auto constIt = constConfig.crbegin();
    QString pageName = (*constIt)->name();
    QCOMPARE(pageName, "Fourth");

    // ===== Test bidirectional const reverse iterator operations =====
    // Test decrement operations on const reverse iterators
    auto constLastRevIt = constConfig.rbegin();
    ++constLastRevIt; ++constLastRevIt; ++constLastRevIt; // Move to "First"
    QCOMPARE((*constLastRevIt)->name(), "First");

    // Test pre-decrement (should move to "Second")
    --constLastRevIt;
    QCOMPARE((*constLastRevIt)->name(), "Second");

    // Test post-decrement
    auto postDecConstRevIt = constLastRevIt--;
    QCOMPARE((*postDecConstRevIt)->name(), "Second");
    QCOMPARE((*constLastRevIt)->name(), "Third");
}


QTEST_MAIN(TestQtNoidAppConfig)
#include "test_app_config.moc"
