#include "QtNoidApp/configglobal.h"
#include <QGlobalStatic>

namespace QtNoid {
namespace App {

Q_GLOBAL_STATIC_WITH_ARGS(ConfigFile, globalConfigInstance, (""))

ConfigFile *ConfigGlobal::instance()
{
    // qDebug() << __func__ ;
    return globalConfigInstance;
}

} // namespace App
} // namespace QtNoid
