//=============================================================================
// parameterspage.cpp
//=============================================================================
#include "QtNoidApp/parameterspage.h"
#include <QDebug>
#include <QJsonObject>
#include <QJsonArray>
#include <QMetaMethod>

namespace QtNoid {
namespace App {

QMutex ParametersPage::s_uniqueIdMutex;
int ParametersPage::s_nextUniqueId(200);  // thread-safe


int ParametersPage::getNextUniqueId()
{
    QMutexLocker locker(&s_uniqueIdMutex);
    if (s_nextUniqueId == INT_MAX) {
        s_nextUniqueId = 0;  // Reset if overflow
    }
    return s_nextUniqueId++;
}


namespace {
bool isTrackedForIsSchemaModified(const QMetaProperty &prop)
{
    static const QSet<QByteArray> excluded = {
        "objectName", "count", "isValueModified", "isSchemaModified"
    };
    return prop.isReadable() && !excluded.contains(prop.name());
}
}

void ParametersPage::captureBaseline()
{
    m_schemaBaseline.clear();
    const QMetaObject *mo = &ParametersPage::staticMetaObject;
    for (int ii = 0; ii < mo->propertyCount(); ++ii) {
        QMetaProperty prop = mo->property(ii);
        if (isTrackedForIsSchemaModified(prop)) {
            m_schemaBaseline.insert(prop.name(), prop.read(this));
        }
    }
}

void ParametersPage::updateIsSchemaModified()
{
    if (m_forceSchemaModified.value()) {
        m_isSchemaModified = true;
        return;
    }

    bool ownChanged = false;
    const QMetaObject *mo = metaObject();
    for (int ii = 0; ii < mo->propertyCount(); ++ii) {
        QMetaProperty prop = mo->property(ii);
        if (isTrackedForIsSchemaModified(prop) && prop.read(this) != m_schemaBaseline.value(prop.name())) {
            ownChanged = true;
            break;
        }
    }
    m_isSchemaModified = ownChanged || (m_parameterSchemaModifiedCounter > 0);
}


ParametersPage::ParametersPage(QObject *parent)
    : QObject(parent), m_uniqueId(getNextUniqueId()), m_count(0), m_visible(true)
{
    initInternalConnections();
    captureBaseline();
}

ParametersPage::ParametersPage(const QString &name, QObject *parent)
    : QObject(parent), m_name(name), m_uniqueId(getNextUniqueId()), m_count(0), m_visible(true)
{
    initInternalConnections();
    captureBaseline();
}

ParametersPage::ParametersPage(const QJsonObject &schemaList, const QJsonObject &valueList, QObject *parent)
    : QObject(parent), m_uniqueId(getNextUniqueId()), m_count(0), m_visible(true)
{
    initInternalConnections();

    // Scan schemaList and valueList to recreate the page
    // Get the name from schema or from value
    if (schemaList.count() == 1) {
        setName(schemaList.constBegin().key());
    } else if (valueList.count() == 1) {
        setName(valueList.constBegin().key());
    }

    // Get Value first to avoid ReadOnly blocking the update
    valuesFromJson(valueList);
    schemaFromJson(schemaList);

    captureBaseline();
}

ParametersPage::~ParametersPage()
{
    emit aboutToBeDestroyed(this);
}


QJsonObject ParametersPage::toJsonValues() const
{
    QString name = m_name;
    if(name.isEmpty()) {
        name = "pageName";
    }

    QJsonArray parametersArray;
    for (auto it = m_parametersByIndex.constBegin(); it != m_parametersByIndex.constEnd(); ++it) {
        Parameter* param = it.value();
        parametersArray.append(param->toJsonValue());
    }

    QJsonObject main({{"parameters", parametersArray}});
    QJsonObject json({{name, main}});
    return json;
}

QJsonObject ParametersPage::toJsonSchema() const
{
    QString name = m_name;
    if(name.isEmpty()) {
        name = "PageName";
    }

    QJsonArray parametersArray;
    for (auto it = m_parametersByIndex.constBegin(); it != m_parametersByIndex.constEnd(); ++it) {
        Parameter* param = it.value();
        parametersArray.append(param->toJsonSchema());
    }

    QJsonObject schemaObject;
    schemaObject["description"] = m_description.value();
    schemaObject["tooltip"] = m_tooltip.value();
    schemaObject["parameters"] = parametersArray;
    schemaObject["visible"] = m_visible.value();
    schemaObject["label"] = m_label.value();
    schemaObject["readOnly"] = m_readOnly.value();


    QJsonObject schema;
    schema[name] = schemaObject;

    return schema;
}

/**
 * @brief ParameterList::valuesFromJson load or update values using an JSON file
 * @param json
 * @return
 */
bool ParametersPage::valuesFromJson(const QJsonObject &json)
{
    QString name = m_name.value();
    if(name.isEmpty() && (json.count() == 1)) {
        // Get the unique JSON object and use it to set the name
        name = json.begin().key();
        setName(name);
        captureBaseline();
    }
    else if(!json.contains(name)) {
        // This is not the correct JSON model
        return false;
    }

    // Load parameters
    const QJsonObject jsonMain = json[name].toObject();
    const QJsonArray parametersArray = jsonMain["parameters"].toArray();
    // qDebug() << __func__ << parametersArray;

    for (const QJsonValue& value : parametersArray) {
        if (value.isObject()) {
            const QJsonObject valueObj = value.toObject();
            const auto valueName = valueObj.constBegin().key();
            const auto valueVal = valueObj.constBegin().value().toVariant();
            Parameter* par = m_parametersByName.value(valueName, nullptr);
            if(par == nullptr) {
                auto newParam = new Parameter(valueVal, valueName, this);
                if(!append(newParam)) {
                    delete newParam;
                }
            }
            else {
                par->setValue(valueVal);
            }
        }
    }
    return true;
}

bool ParametersPage::schemaFromJson(const QJsonObject &json)
{
    QString name = m_name.value();
    if(name.isEmpty() && (json.count() == 1)) {
        // Get the unique JSON object and use it to set the name
        name = json.begin().key();
        setName(name);
    }
    else if(!json.contains(name)) {
        // This is not the correct JSON model
        return false;
    }

    const QJsonObject schemaMain = json[name].toObject();

    if(schemaMain.contains("visible")) {
        setVisible(schemaMain["visible"].toBool());
    }
    if(schemaMain.contains("description")) {
        setDescription(schemaMain["description"].toString());
    }
    if(schemaMain.contains("tooltip")) {
        setTooltip(schemaMain["tooltip"].toString());
    }
    if(schemaMain.contains("label")) {
        setLabel(schemaMain["label"].toString());
    }
    if(schemaMain.contains("readOnly")) {
        setReadOnly(schemaMain["readOnly"].toBool());
    }

    // Load parameters from schema and update the object if present
    const QJsonArray schemaArray = schemaMain["parameters"].toArray();
    for (const QJsonValue& schema : schemaArray) {
        if (schema.isObject()) {
            const QJsonObject schemaObj = schema.toObject();
            const auto valueName = schemaObj.constBegin().key();
            Parameter* par = m_parametersByName.value(valueName, nullptr);
            if(par == nullptr) {
                auto newParam = new Parameter(schemaObj, {}, this);
                if(!append(newParam)) {
                    delete newParam;
                }
            }
            else {
                par->schemaFromJson(schemaObj);
            }
        }
    }

    captureBaseline();

    return true;
}


QString ParametersPage::name() const
{
    return m_name.value();
}


void ParametersPage::setName(const QString &newName)
{
    if(m_name == newName)
        return;

    QString oldName = m_name;
    m_name = newName;
    emit nameEdited(oldName, newName);
}


QBindable<QString> ParametersPage::bindableName()
{
    return QBindable<QString>(&m_name);
}

QString ParametersPage::label() const
{
    return m_label.value();
}

void ParametersPage::setLabel(const QString &newLabel)
{
    m_label = newLabel;
}

QBindable<QString> ParametersPage::bindableLabel()
{
    return QBindable<QString>(&m_label);
}

QString ParametersPage::description() const
{
    return m_description.value();
}

void ParametersPage::setDescription(const QString &value)
{
    m_description = value;
}

QBindable<QString> ParametersPage::bindableDescription()
{
    return QBindable<QString>(&m_description);
}

QString ParametersPage::tooltip() const
{
    return m_tooltip.value();
}

void ParametersPage::setTooltip(const QString &value)
{
    m_tooltip = value;
}

QBindable<QString> ParametersPage::bindableTooltip()
{
    return QBindable<QString>(&m_tooltip);
}

bool ParametersPage::readOnly() const
{
    return m_readOnly.value();
}

void ParametersPage::setReadOnly(bool value)
{
    m_readOnly = value;
}

QBindable<bool> ParametersPage::bindableReadOnly()
{
    return QBindable<bool>(&m_readOnly);
}

bool ParametersPage::visible() const
{
    return m_visible.value();
}

void ParametersPage::setVisible(bool value)
{
    m_visible = value;
}

QBindable<bool> ParametersPage::bindableVisible()
{
    return QBindable<bool>(&m_visible);
}

bool ParametersPage::isValueModified() const
{
    return m_isValueModified.value();
}

QBindable<bool> ParametersPage::bindableIsValueModified()
{
    return QBindable<bool>(&m_isValueModified);
}

void ParametersPage::setValueModified(bool modified)
{
    for (auto it = m_parametersByIndex.constBegin(); it != m_parametersByIndex.constEnd(); ++it) {
        it.value()->setValueModified(modified);
    }
}

void ParametersPage::resetValueModifications()
{
    for (auto it = m_parametersByIndex.constBegin(); it != m_parametersByIndex.constEnd(); ++it) {
        it.value()->resetValueModifications();
    }
}

bool ParametersPage::isSchemaModified() const
{
    return m_isSchemaModified.value();
}

QBindable<bool> ParametersPage::bindableIsSchemaModified()
{
    return QBindable<bool>(&m_isSchemaModified);
}

void ParametersPage::setSchemaModified(bool modified)
{
    if (modified) {
        m_forceSchemaModified = true;
    } else {
        m_forceSchemaModified = false;
        captureBaseline();   // accept the page's own current properties as the new baseline
    }
    updateIsSchemaModified();
}

void ParametersPage::resetSchemaModifications()
{
    m_forceSchemaModified = false;

    const QMetaObject *mo = metaObject();
    for (const QByteArray &propName : m_schemaBaseline.keys()) {
        auto idx = mo->indexOfProperty(propName);
        if (idx < 0) {
            continue;
        }
        QMetaProperty prop = mo->property(idx);
        if (prop.isWritable()) {
            prop.write(this, m_schemaBaseline.value(propName));
        }
    }

    for (auto it = m_parametersByIndex.constBegin(); it != m_parametersByIndex.constEnd(); ++it) {
        it.value()->resetSchemaModifications();
    }

    updateIsSchemaModified();
}

int ParametersPage::count() const
{
    return m_count.value();
}

QBindable<int> ParametersPage::bindableCount()
{
    return QBindable<int>(&m_count);
}

bool ParametersPage::append(Parameter *parameter)
{
    if (parameter == nullptr) {
        return false;
    }
    // int paramterId = parameter->uniqueId();
    if (m_parametersByUniqueId.contains(parameter->uniqueId())) {
        return false;
    }

    auto paramName = parameter->name();
    if(paramName.isEmpty()){
        return false;
    }

    if (m_parametersByName.contains(paramName)) {
        return false;
    }

    // Update all indexes
    appendParameterAndUpdateIndexs(parameter);
    return true;
}

bool ParametersPage::append(const QJsonObject& schema, const QJsonObject& value)
{
    Parameter* parameter = new Parameter(schema, value, this);
    auto res = append(parameter);
    if(!res) {
        delete parameter;
    }
    return res;
}

Parameter* ParametersPage::emplace(const QVariant& initialValue, const QString& name, const QString& description)
{
    if(name.isEmpty()) {
        return {};
    }
    if (m_parametersByName.contains(name)) {
        return {};
    }

    Parameter* parameter = new Parameter(initialValue, name, description, this);
    appendParameterAndUpdateIndexs(parameter);

    return parameter;
}

Parameter* ParametersPage::emplace(const QJsonObject& schema, const QJsonObject& value)
{
    Parameter* parameter = new Parameter(schema, value, this);
    bool res = append(parameter);
    if(!res) {
        delete parameter;
        return nullptr;
    }
    return parameter;
}

void ParametersPage::removeParameterInternal(Parameter *parameter)
{
    m_parametersByUniqueId.remove(parameter->uniqueId());
    m_parametersByName.remove(parameter->name());

    int idx = m_parameterToIndex.value(parameter, -1);
    if (idx != -1) {
        m_parameterToIndex.remove(parameter);
        m_parametersByIndex.remove(idx);
    }

    if (parameter->isValueModified()) {
        onParameterIsValueModifiedChanged(false);
    }
    if (parameter->isSchemaModified()) {
        onParameterIsSchemaModifiedChanged(false);
    }

    disconnect(parameter, &Parameter::aboutToBeDestroyed, this, &ParametersPage::onParameterAboutToBeDestroyed);
    disconnect(parameter, &Parameter::nameEdited, this, &ParametersPage::onParameterNameEdited);
    disconnect(parameter, &Parameter::isValueModifiedChanged, this, &ParametersPage::onParameterIsValueModifiedChanged);
    disconnect(parameter, &Parameter::isSchemaModifiedChanged, this, &ParametersPage::onParameterIsSchemaModifiedChanged);


    emit parameterRemoved(parameter);
    m_count = m_parametersByIndex.count();

    if (m_parametersByIndex.isEmpty()) {
        m_nextParameterIndex = 0;
    }
}

bool ParametersPage::canModify(const QString &parameterName) const
{
    if (m_readOnly.value()) {
        emit const_cast<ParametersPage*>(this)->writeAttemptedWhileReadOnly(parameterName);
        return false;
    }
    return true;
}


void ParametersPage::removeParameter(Parameter *parameter)
{
    if (parameter == nullptr) {
        return;
    }
    if (!m_parametersByUniqueId.contains(parameter->uniqueId())) {
        // Not part of this list
        return;
    }
    removeParameterInternal(parameter);
}

void ParametersPage::removeParameter(const QString &name)
{
    Parameter* parameter = m_parametersByName.value(name, nullptr);
    if (parameter == nullptr) {
        return;
    }
    removeParameterInternal(parameter);
}

void ParametersPage::clear()
{
    if(isEmpty()) return;

    for (auto it = m_parametersByIndex.begin(); it != m_parametersByIndex.end(); ++it) {
        Parameter* param = it.value();
        disconnect(param, &Parameter::aboutToBeDestroyed, this, &ParametersPage::onParameterAboutToBeDestroyed);
        disconnect(param, &Parameter::nameEdited, this, &ParametersPage::onParameterNameEdited);
        disconnect(param, &Parameter::isValueModifiedChanged, this, &ParametersPage::onParameterIsValueModifiedChanged);
        disconnect(param, &Parameter::isSchemaModifiedChanged, this, &ParametersPage::onParameterIsSchemaModifiedChanged);
        emit parameterRemoved(param);
    }

    m_valueModifiedCounter = 0;
    m_isValueModified = false;
    m_parameterSchemaModifiedCounter = 0;
    updateIsSchemaModified();

    m_parametersByUniqueId.clear();
    m_parametersByIndex.clear();
    m_parameterToIndex.clear();
    m_parametersByName.clear();

    m_nextParameterIndex = 0;
    m_count = 0;
}

bool ParametersPage::isEmpty() const
{
    return m_parametersByIndex.isEmpty();
}

Parameter *ParametersPage::parameter(int index) const
{
    return m_parametersByIndex.value(index, nullptr);
}

Parameter *ParametersPage::parameter(const QString &name) const
{
    return m_parametersByName.value(name, nullptr);
}

int ParametersPage::indexOf(Parameter *parameter) const
{
    return m_parameterToIndex.value(parameter, -1);
}

int ParametersPage::indexOf(const QString &name) const
{
    Parameter *param = m_parametersByName.value(name, nullptr);

    return m_parameterToIndex.value(param, -1);
}

bool ParametersPage::contains(Parameter *parameter) const
{
    return m_parameterToIndex.contains(parameter);
}

bool ParametersPage::contains(const QString &name) const
{
    return m_parametersByName.contains(name);
}

QList<Parameter *> ParametersPage::parameters() const
{
    // return m_parameterToIndex.keys(); -> this doesn't guarantee the sorting
    QList<Parameter*> res;
    for(auto it = m_parametersByIndex.cbegin(); it != m_parametersByIndex.cend(); ++it) {
        res << it.value();
    }
    return res;
}

QVariant ParametersPage::value(const QString &name) const
{
    Parameter *param = m_parametersByName.value(name, nullptr);
    if(param == nullptr)
        return {};

    return param->value();
}

bool ParametersPage::setValue(const QString &name, const QVariant &value)
{
    Parameter *param = m_parametersByName.value(name, nullptr);
    if(param == nullptr) {
        return false;
    }

    if (!canModify(name)) {
        return false;
    }
    param->setValue(value);
    return true;
}

void ParametersPage::applyPreset(const QString &presetName)
{
    for (auto it = m_parametersByIndex.constBegin(); it != m_parametersByIndex.constEnd(); ++it) {
        Parameter* param = it.value();
        param->applyPreset(presetName);
    }
}


void ParametersPage::initInternalConnections()
{
    static const QMetaMethod onOwnPropertyChangedSlot = ParametersPage::staticMetaObject.method(
        ParametersPage::staticMetaObject.indexOfSlot("onOwnPropertyChanged()"));

    for (int ii = 0; ii < ParametersPage::staticMetaObject.propertyCount(); ++ii) {
        QMetaProperty prop = ParametersPage::staticMetaObject.property(ii);
        if (isTrackedForIsSchemaModified(prop) && prop.hasNotifySignal()) {
            connect(this, prop.notifySignal(), this, onOwnPropertyChangedSlot);
        }
    }
}


void ParametersPage::onParameterNameEdited(const QString &oldName, const QString &newName)
{
    if(!m_parametersByName.contains(oldName)) {
        emit parameterRenameError(oldName, newName);
        return;
    }

    if(m_parametersByName.contains(newName)) {
        emit parameterRenameError(oldName, newName);
        return;
    }

    Parameter* currentParameter = m_parametersByName.take(oldName);
    m_parametersByName.insert(newName, currentParameter);

    return;
}

void ParametersPage::onParameterIsValueModifiedChanged(bool changed)
{
    if(changed) {
        ++m_valueModifiedCounter;
    }
    else {
        --m_valueModifiedCounter;
    }
    m_isValueModified = (m_valueModifiedCounter >0);
}

void ParametersPage::onParameterIsSchemaModifiedChanged(bool changed)
{
    if(changed) {
        ++m_parameterSchemaModifiedCounter;
    }
    else {
        --m_parameterSchemaModifiedCounter;
    }
    updateIsSchemaModified();
}

void ParametersPage::appendParameterAndUpdateIndexs(Parameter *parameter)
{
    m_parametersByUniqueId.insert(parameter->uniqueId(), parameter);
    m_parameterToIndex.insert(parameter, m_nextParameterIndex);
    m_parametersByIndex.insert(m_nextParameterIndex, parameter);
    m_nextParameterIndex++;
    m_parametersByName.insert(parameter->name(), parameter);
    connect(parameter, &Parameter::aboutToBeDestroyed, this, &ParametersPage::onParameterAboutToBeDestroyed);
    connect(parameter, &Parameter::nameEdited, this, &ParametersPage::onParameterNameEdited);
    connect(parameter, &Parameter::isValueModifiedChanged, this, &ParametersPage::onParameterIsValueModifiedChanged);
    connect(parameter, &Parameter::isSchemaModifiedChanged, this, &ParametersPage::onParameterIsSchemaModifiedChanged);

    if(parameter->isValueModified()) {
        onParameterIsValueModifiedChanged(true);
    }
    if(parameter->isSchemaModified()) {
        onParameterIsSchemaModifiedChanged(true);
    }

    emit parameterAdded(parameter);
    m_count = m_parametersByIndex.count();
}

void ParametersPage::onOwnPropertyChanged()
{
    updateIsSchemaModified();
}

void ParametersPage::onParameterAboutToBeDestroyed(Parameter *parameter)
{
    int idx = m_parameterToIndex.value(parameter, -1);
    if(idx == -1) {
        return;
    }
    m_parameterToIndex.remove(parameter);
    m_parametersByUniqueId.remove(parameter->uniqueId());
    m_parametersByIndex.remove(idx);

    QString key = m_parametersByName.key(parameter);
    m_parametersByName.remove(key);

    if (parameter->isValueModified()) {
        onParameterIsValueModifiedChanged(false);
    }
    if (parameter->isSchemaModified()) {
        onParameterIsSchemaModifiedChanged(false);
    }

    emit parameterRemoved(parameter);
    m_count = m_parametersByIndex.count();
    if (isEmpty()) {
        m_nextParameterIndex = 0;
    }
}




} // namespace App
} // namespace QtNoid
