#include "QtNoidApp/core.h"
#include <QApplication>
#include <QDir>
#include <QFileInfo>
#include <QMainWindow>
#include <QWidget>
#include <QScreen>
#include <QShortcut>
#include <QClipboard>
#include <QColorSpace>
#include <QtNoidCommon/QtNoidCommon>

namespace QtNoid {
namespace App {

/**
 * @brief Core::appExeOrAppBundlePath is used to manage files into the
 * application exectuion folder or the Application Bundle folder.
 * This is helpful to save cunfiguration files or resources for the application.
 * @return the Application Executable or the Application Boundle folder
 */
QString Core::appExeOrAppBundleDirPath()
{
    auto appFilePath = qApp->applicationDirPath();
    if(appFilePath.contains(".app/Contents/MacOS")){
        // This is a bundle for macOS
        QFileInfo FI(appFilePath);
        QDir dir;
        FI.setFile(dir.cleanPath(FI.filePath() + "/../../../"));
        return FI.filePath();
    }
    else {
        return appFilePath;
    }
}


QString Core::appExeOrAppBundleFilePath()
{
    auto appFilePath = qApp->applicationFilePath();
    if(appFilePath.contains(".app/Contents/MacOS")){
        // This is a bundle for macOS
        QFileInfo FI(appFilePath);
        QDir dir;
        FI.setFile(dir.cleanPath(FI.filePath() + "/../../../"));
        return FI.filePath();
    }
    else {
        return appFilePath;
    }
}


QString Core::filePathAsAppSibling(const QString &fileName)
{

    QString cleanFName;
    if(fileName.isEmpty()) {
        cleanFName = qApp->applicationName() + ".json";
    }
    else {
        QFileInfo FI(fileName);
        cleanFName = FI.fileName();
    }
    // qDebug() << __func__ << cleanFName;

    auto res = appExeOrAppBundleDirPath() + "/" +cleanFName;
    return res;
}



QMainWindow *Core::mainWindowFromWidget(QWidget &ref)
{
    return mainWindowFromWidget(&ref);
}

QMainWindow *Core::mainWindowFromWidget(QWidget *ref)
{
    if (ref == nullptr)
        return nullptr;

    QObject *parent = ref->parent();
    if (parent == nullptr) {
        // Could be this is already the main window
        return qobject_cast<QMainWindow *>(ref);;
    }
    // Loop till the QMainWindow
    while (parent->isWidgetType()) {
        if (parent->parent() == nullptr) {
            break;
        }
        parent = parent->parent();
    }
    return qobject_cast<QMainWindow *>(parent);
}



QString Core::groupNameFromObjectOrClass(const QObject &ref)
{
    return groupNameFromObjectOrClass(&ref);
}

QString Core::groupNameFromObjectOrClass(const QObject *ref)
{
    if (ref == nullptr)
        return QString();

    auto groupName = ref->objectName();
    if(groupName.isEmpty()) {
        return QtNoid::Common::Text::convertToCamelCase(ref->metaObject()->className());
    }
    else {
        return QtNoid::Common::Text::convertToCamelCase(groupName);
    }
}

bool Core::updateMainWindowTitle(bool changed, QWidget *ref)
{
    auto mainWindow = mainWindowFromWidget(ref);
    if(mainWindow == nullptr)
    {
        return false;
    }

    auto current = mainWindow->windowTitle();
    if(!current.isEmpty() && current.last(1) == "*") {
        current = current.removeLast();
    }
    current = current.trimmed();
    // qDebug() << __func__ << current;
    if(changed) {
        current += "*";
    }
    mainWindow->setWindowTitle(current);

    return true;
}

QImage Core::fullDialogGrab(QWidget *ref)
{
    auto mainWindow = mainWindowFromWidget(ref);
    if(mainWindow == nullptr)
    {
        return {};
    }

    QScreen* screen = mainWindow->screen();
    QRect windowRect = mainWindow->frameGeometry();
    QPoint screenOffset = screen->geometry().topLeft();
    QRect relativeRect = windowRect.translated(-screenOffset);
    QPixmap pixMap = screen->grabWindow(0,
                                        relativeRect.x(),
                                        relativeRect.y(),
                                        relativeRect.width(),
                                        relativeRect.height());

    // This conversion to Image is necessary for macOS
    QImage img = pixMap.toImage();
    img.setColorSpace(QColorSpace());
    return img;
}


}   // namespace App
}   // namespace QtNoid
