#include "QtNoidApp/parameter.h"
#include <QDebug>
#include <QJsonArray>
#include <QJsonObject>
#include <QJsonValue>
#include <QMetaProperty>



namespace QtNoid {
namespace App {

QMutex Parameter::s_uniqueIdMutex;
int Parameter::s_nextUniqueId(2000);  // thread-safe

int Parameter::getNextUniqueId()
{
    QMutexLocker locker(&s_uniqueIdMutex);
    if (s_nextUniqueId == INT_MAX) {
        s_nextUniqueId = 0;  // Reset if overflow
    }
    return s_nextUniqueId++;
}


namespace {
bool isTrackedForIsSchemaModified(const QMetaProperty &prop)
{
    static const QSet<QByteArray> excluded = {
        "objectName", "value", "range", "isValid", "isValueModified", "isSchemaModified"
    };
    return prop.isReadable() && !excluded.contains(prop.name());
}
}

void Parameter::captureBaseline()
{
    const bool wasSchemaModified = m_isSchemaModified.value();
    m_isSchemaModified.setValueBypassingBindings(m_forceSchemaModified.value());
    m_schemaBaseline.clear();
    const QMetaObject mo = Parameter::staticMetaObject;
    for (int ii = 0; ii < mo.propertyCount(); ++ii) {
        QMetaProperty prop = mo.property(ii);
        if (isTrackedForIsSchemaModified(prop)) {
            m_schemaBaseline.insert(prop.name(), prop.read(this));
        }
    }
    if (m_isSchemaModified.value() != wasSchemaModified) {
        m_isSchemaModified.notify();
    }
}


Parameter::Parameter(QObject *parent)
    : QObject(parent), m_uniqueId(getNextUniqueId()), m_visible(true)
{
    initInternalConnections();
    captureBaseline();
    initIsSchemaModifiedConnections();
}

Parameter::Parameter(const QVariant &initialValue, QObject *parent)
    : QObject(parent), m_initialValue(initialValue), m_uniqueId(getNextUniqueId()),
    m_value(initialValue), m_visible(true)
{
    initInternalConnections();
    captureBaseline();
    initIsSchemaModifiedConnections();
}

Parameter::Parameter(const QVariant &initialValue, const QString &name, QObject *parent)
    : QObject(parent), m_initialValue(initialValue), m_uniqueId(getNextUniqueId()),
    m_name(name), m_value(initialValue), m_visible(true)
{
    initInternalConnections();
    captureBaseline();
    initIsSchemaModifiedConnections();
}

Parameter::Parameter(const QVariant &initialValue, const QString &name, const QString &description, QObject *parent)
    : QObject(parent), m_initialValue(initialValue), m_uniqueId(getNextUniqueId()),
    m_name(name), m_description(description), m_value(initialValue), m_visible(true)
{
    initInternalConnections();
    captureBaseline();
    initIsSchemaModifiedConnections();
}

Parameter::Parameter(const QJsonObject &schema, const QJsonObject &value, QObject *parent)
    : QObject(parent), m_uniqueId(getNextUniqueId()), m_visible(true)
{
    initInternalConnections();
    // Extract parameter name from schema Json (first key) or value Json (first key)
    QString paramName;
    if (!schema.isEmpty()) {
        paramName = schema.begin().key();
    } else if (!value.isEmpty()) {
        paramName = value.begin().key();
    }
    
    if (!paramName.isEmpty()) {
        m_name = paramName;
        valueFromJson(value);
        schemaFromJson(schema);
    }
    captureBaseline();
    initIsSchemaModifiedConnections();
}

Parameter::~Parameter()
{
    emit aboutToBeDestroyed(this);
}

QJsonObject Parameter::toJsonValue() const
{
    QJsonObject res;
    QString name = m_name;
    if(name.isEmpty()) {
        name = "Name";
    }
    res[name] = QJsonValue::fromVariant(value());
    return res;
}

QJsonObject Parameter::toJsonSchema() const
{
    QJsonObject schema;
    schema["description"] = m_description.value();
    schema["unit"] = m_unit.value();
    schema["tooltip"] = m_tooltip.value();
    schema["readOnly"] = m_readOnly.value();
    schema["visible"] = m_visible.value();
    schema["min"] = QJsonValue::fromVariant(m_min.value());
    schema["max"] = QJsonValue::fromVariant(m_max.value());


    if(m_presets.value().count() > 0) {
        QVariantMap presetsMap = m_presets;
        QJsonArray presetsArray;
        for (auto it = presetsMap.constBegin(); it != presetsMap.constEnd(); ++it) {
            QJsonObject item;
            item[it.key()] = it.value().toJsonValue();
            presetsArray.append(item);
        }
        schema["presets"] = presetsArray;
    }

    schema["label"] = m_label.value();
    QString name = m_name;
    if(name.isEmpty()) {
        name = "Name";
    }    

    QJsonObject res;
    res[name] = schema;
    return res;
}

bool Parameter::fromJson(const QJsonObject &schema, const QJsonObject &value)
{
    // Override the parameter name using schema
    if(schema.isEmpty())
        return false;

    QString paramName = schema.begin().key();
    if(paramName.isEmpty())
        return false;

    m_name = paramName;

    auto resJson = valueFromJson(value);
    auto resSchema = schemaFromJson(schema);

    if(resJson || resSchema) {
        // Conversion is successfull if at least one is successfull
        return true;
    }
    else {
        return false;
    }
}

bool Parameter::valueFromJson(const QJsonObject& json)
{
    QString name = m_name.value();    
    if(name.isEmpty() && (json.count() == 1)) {
        // Get the unique JSON object and use it to set the name
        name = json.begin().key();
        setName(name);
        QVariant value = json.value(name).toVariant();
        m_initialValue = value;
        m_value = value;
        captureBaseline();
        return true;
    }

    if(json.contains(name)) {
        QVariant value = json[name].toVariant();
        m_initialValue = value;
        m_value = value;
        captureBaseline();
        return true;
    }
    return false;
}

bool Parameter::schemaFromJson(const QJsonObject &json)
{
    // Sanity check
    if(json.isEmpty())
        return false;

    // Get parameter name - use existing name or first key in JSON
    QString paramName = m_name.value();
    if (paramName.isEmpty()) {
        paramName = json.begin().key();
        setName(paramName);
    }
    
    if (!json.contains(paramName)) {
        return false;
    }
    
    QJsonObject schemaData = json[paramName].toObject();
    if (schemaData.contains("label")) {
        setLabel(schemaData["label"].toString());
    } else {
        setLabel(QString());
    }

    // Load schema properties
    if (schemaData.contains("description")) {
        setDescription(schemaData["description"].toString());
    }
    else{
        setDescription(QString());
    }
    if (schemaData.contains("unit")) {
        setUnit(schemaData["unit"].toString());
    }
    else {
        setUnit(QString());
    }
    if (schemaData.contains("tooltip")) {
        setTooltip(schemaData["tooltip"].toString());
    }
    else {
        setTooltip(QString());
    }
    if (schemaData.contains("readOnly")) {
        setReadOnly(schemaData["readOnly"].toBool());
    }
    else {
        setReadOnly(false);
    }
    if (schemaData.contains("visible")) {
        setVisible(schemaData["visible"].toBool());
    }
    else {
        setVisible(true);
    }
    QVariant min;
    QVariant max;
    if (schemaData.contains("min")) {
        min = schemaData["min"].toVariant();
    }
    if (schemaData.contains("max")) {
        max=schemaData["max"].toVariant();
    }
    setRange(min, max);

    if (schemaData.contains("presets")) {
        const QJsonArray presetList = schemaData["presets"].toArray();
        for(auto it = presetList.constBegin(); it != presetList.constEnd(); ++it) {
            if(it->isObject()) {
                QJsonObject preset = it->toObject();
                QString name = preset.begin().key();
                QVariant val = preset.begin().value().toVariant();
                setPreset(name, val);
            }
        }
    }
    else {
        setPresets({});
    }

    captureBaseline();
    return true;
}

void Parameter::initInternalConnections()
{
    auto onRangeBoundaryChanged = [this](const QVariant&) {
        enforceRange();
        emit rangeChanged(m_min.value(), m_max.value());
    };
    connect(this, &Parameter::minChanged, this, onRangeBoundaryChanged);
    connect(this, &Parameter::maxChanged, this, onRangeBoundaryChanged);

    // This automatically track any changes in parameters used by computeIsValid()
    m_isValid.setBinding([this]{ return computeIsValid(); });
    m_isValueModified.setBinding([this]{
        if (m_forceValueModified.value()) {
            return true;
        }
        return m_value.value() != m_initialValue.value();
    });

}

void Parameter::initIsSchemaModifiedConnections()
{
    // qDebug() << Q_FUNC_INFO;
    // This automatically track any changes in properties used by m_isSchemaModified()
    m_isSchemaModified.setBinding([this]{
        if (m_forceSchemaModified.value()) {
            return true;
        }
        const QMetaObject mo = Parameter::staticMetaObject;
        bool anyChanged = false;
        for (int ii = 0; ii < mo.propertyCount(); ++ii) {
            QMetaProperty prop = mo.property(ii);
            // qDebug() << "initIsSchemaModifiedConnections" << prop.name() << "current: " << prop.read(this) << "baseline" << m_schemaBaseline.value(prop.name());
            if (isTrackedForIsSchemaModified(prop) && prop.read(this) != m_schemaBaseline.value(prop.name())) {
                anyChanged = true;
            }
        }        
        return anyChanged;
    });
}

QVariant Parameter::value() const
{
    return m_value.value();
}

void Parameter::setValue(const QVariant &val)
{
    if (canModify()) {
        // No needs for checking if different or to manually emit value changed
        auto newVal = clampValue(val);
        m_value = newVal;
    }
}
QBindable<QVariant> Parameter::bindableValue()
{
    return QBindable<QVariant>(&m_value);
}


QVariant Parameter::min() const
{
    return m_min.value();
}

void Parameter::setMin(const QVariant &val)
{
    m_min = val;
}

QBindable<QVariant> Parameter::bindableMin()
{
    return QBindable<QVariant>(&m_min);
}

QVariant Parameter::max() const
{
    return m_max.value();
}
void Parameter::setMax(const QVariant &val)
{
    m_max = val;
}

QBindable<QVariant> Parameter::bindableMax()
{
    return QBindable<QVariant>(&m_max);
}

std::pair<QVariant, QVariant> Parameter::range() const
{
    return {m_min.value(), m_max.value()};
}

void Parameter::setRange(const QVariant &min, const QVariant &max)
{
    QVariant newMin = min;
    QVariant newMax = max;

    // Enoforce min lower than max
    if(min.isValid() && max.isValid()) {
        if(compareVariants(min, max, 1)) {
            std::swap(newMin, newMax);
        }
    }

    // Are min and max going to change value?
    const bool minWillChange = (newMin != m_min.value());
    const bool maxWillChange = (newMax != m_max.value());

    m_min.setValueBypassingBindings(newMin);
    m_max.setValueBypassingBindings(newMax);

    // Now both value are in place, we can notify.
    // If changed, this will call also enforceRange
    if (minWillChange) m_min.notify();
    if (maxWillChange) m_max.notify();

    return;
}
void Parameter::setRange(const std::pair<QVariant, QVariant>& newRange)
{
    setRange(newRange.first, newRange.second);
}

/**
 * @brief Parameter::rangeIsValid
 * @return true if min, max are valid and if max > min (strictly)
 */
bool Parameter::rangeIsValid() const
{
    if(!m_min.value().isValid())
        return false;

    if(!m_max.value().isValid())
        return false;

    if (!compareVariants(m_max.value(), m_min.value(), 1)) {
        return false;
    }

    return true;
 }


QVariantMap Parameter::presets() const
{
    return m_presets.value();
}

void Parameter::setPresets(const QVariantMap &presets)
{
    m_presets = presets;
}

void Parameter::clearPresets()
{
    m_presets = QVariantMap();
}

QVariant Parameter::preset(const QString &name) const
{
    if(!m_presets.value().contains(name)) {
        return QVariant();
    }
    return m_presets.value()[name];
}

void Parameter::setPreset(const QString &name, const QVariant &value)
{
    QVariantMap current = m_presets.value();
    current[name] = value;
    m_presets = current;
}

void Parameter::setPreset(const std::pair<QString, QVariant> &preset)
{
    setPreset(preset.first, preset.second);
}

void Parameter::removePreset(const QString &name)
{
    if(m_presets.value().contains(name)) {
        QVariantMap currentPresets = m_presets.value();
        currentPresets.remove(name);
        m_presets = currentPresets;
    }
}

/**
 * @brief Parameter::applyPreset this override also read only but not range
 * @param name
 * @return
 */
bool Parameter::applyPreset(const QString &name)
{
    if(!m_presets.value().contains(name)) {
        return false;
    }

    auto val = m_presets.value()[name];
    auto newVal = clampValue(val);
    m_value = newVal;
    return true;
}

QBindable<QVariantMap> Parameter::bindablePresets()
{
    return QBindable<QVariantMap>(&m_presets);
}

QString Parameter::name() const
{
    return m_name.value();
}

void Parameter::setName(const QString &newName)
{
    if(m_name == newName)
        return;

    QString oldName = m_name;
    m_name = newName;

    emit nameEdited(oldName, newName);
}

QBindable<QString> Parameter::bindableName()
{
    return QBindable<QString>(&m_name);
}

QString Parameter::label() const
{
    return m_label.value();
}

void Parameter::setLabel(const QString &value)
{
    m_label = value;
}

QBindable<QString> Parameter::bindableLabel()
{
    return QBindable<QString>(&m_label);
}

QString Parameter::description() const
{
    return m_description.value();
}

void Parameter::setDescription(const QString &value)
{
    m_description = value;
}

QBindable<QString> Parameter::bindableDescription()
{
    return QBindable<QString>(&m_description);
}


QString Parameter::unit() const
{
    return m_unit.value();
}

void Parameter::setUnit(const QString &value)
{
    m_unit = value;
}

QBindable<QString> Parameter::bindableUnit()
{
    return QBindable<QString>(&m_unit);
}

QString Parameter::tooltip() const
{
    return m_tooltip.value();
}

void Parameter::setTooltip(const QString &value)
{
    m_tooltip = value;
}

QBindable<QString> Parameter::bindableTooltip()
{
    return QBindable<QString>(&m_tooltip);
}

bool Parameter::readOnly() const
{
    return m_readOnly.value();
}
void Parameter::setReadOnly(bool value)
{
    m_readOnly = value;
}

QBindable<bool> Parameter::bindableReadOnly()
{
    return QBindable<bool>(&m_readOnly);
}

bool Parameter::visible() const
{
    return m_visible.value();
}

void Parameter::setVisible(bool value)
{
    m_visible = value;
}

QBindable<bool> Parameter::bindableVisible()
{
    return QBindable<bool>(&m_visible);
}

bool Parameter::isValid() const
{
    return m_isValid.value();
}

QBindable<bool> Parameter::bindableIsValid()
{
    return QBindable<bool>(&m_isValid);
}

bool Parameter::isValueModified() const
{
    return m_isValueModified;
}

QBindable<bool> Parameter::bindableIsValueModified()
{
    return QBindable<bool>(&m_isValueModified);
}

void Parameter::setValueModified(bool modified)
{
    if (modified) {
        m_forceValueModified = true;
    } else {
        m_forceValueModified = false;
        m_initialValue = m_value.value();   // accept the current value as the new reference
    }
}

void Parameter::resetValueModifications()
{
    m_value = m_initialValue;
    m_forceValueModified = false;
}


bool Parameter::isSchemaModified() const
{
    return m_isSchemaModified;
}

QBindable<bool> Parameter::bindableIsSchemaModified()
{
    return QBindable<bool>(&m_isSchemaModified);
}

void Parameter::setSchemaModified(bool modified)
{
    if (modified) {
        m_forceSchemaModified = true;
    } else {
        m_forceSchemaModified = false;
        captureBaseline();
    }
}

void Parameter::resetSchemaModifications()
{
    const QMetaObject mo = Parameter::staticMetaObject;
    for(const QByteArray &propName : m_schemaBaseline.keys()) {
        auto idx = mo.indexOfProperty(propName);
        if(idx<0) {
            continue;
        }
        QMetaProperty prop = mo.property(idx);
        if(!prop.isWritable()) {
            continue;
        }
        prop.write(this, m_schemaBaseline.value(propName));
    }
    m_forceSchemaModified = false;
}

bool Parameter::canModify() const
{
    if(m_readOnly.value()) {
        emit const_cast<Parameter*>(this)->writeAttemptedWhileReadOnly(m_name.value(), m_value.value());
        return false;
    }
    return true;
}


bool Parameter::computeIsValid() const
{
    if (!m_value.value().isValid()) {
        return false;
    }

    // Parameter must have a non-empty name
    if (m_name.value().isEmpty()) {
        return false;
    }

    // If min/max are set, they must be valid
    if (m_min.value().isValid() && m_max.value().isValid()) {
        if (compareVariants(m_min.value(), m_max.value(), 1)) {
            return false;
        }
    }

    // If value is set and range is defined, value must be within range
    if (m_value.value().isValid()) {
        if (m_min.value().isValid() && compareVariants(m_value.value(), m_min.value(), -1)) {
            return false;
        }
        if (m_max.value().isValid() && compareVariants(m_value.value(), m_max.value(), 1)) {
            return false;
        }
    }

    return true;
}


void Parameter::enforceRange()
{
    if(!m_value.value().isValid())
        return;

    auto newVal = clampValue(m_value);
    if (newVal == m_value.value())
        return;              // the value is coherent with the range

    if (!canModify())
        return;

    m_value = newVal;
}

QVariant Parameter::clampValue(const QVariant &value) const
{
    // qDebug() << __func__ << "value:" << value << "range:" << range();
    QVariant result = value;

    // Clamp to min value
    if (m_min.value().isValid() && compareVariants(value, m_min, -1)) {
        result = m_min.value();
    }

    // Clamp to max value
    if (m_max.value().isValid() && compareVariants(value, m_max, 1)) {
        result = m_max.value();
    }

    return result;
}

/**
 * @brief Parameter::compareVariants
 * @param a
 * @param b
 * @param comparison -1 sa < sb, 0 sa == sb, +1 sa > sb
 * @return
 */
bool Parameter::compareVariants(const QVariant &a, const QVariant &b, int comparison) const
{
    if (!a.isValid() || !b.isValid())
        return false;

    // qDebug() << __func__ << a.metaType() << b.metaType();

    // Case 0: integer
    QMetaType longLongType = QMetaType::fromType<long long>();
    if(a.metaType() == longLongType && b.metaType() == longLongType) {
        auto da = a.toLongLong();
        auto db = b.toLongLong();
        switch (comparison) {
        case -1: return da < db;
        case 0:  return da == db;
        case 1:  return da > db;
        }
    }

    // Case 1: integer
    QMetaType intType = QMetaType::fromType<int>();
    if(a.metaType() == intType && b.metaType() == intType) {
        auto da = a.toInt();
        auto db = b.toInt();
        switch (comparison) {
        case -1: return da < db;
        case 0:  return da == db;
        case 1:  return da > db;
        }
    }
    // Case 2: double
    QMetaType doubleType = QMetaType::fromType<double>();
    if(a.metaType() == doubleType && b.metaType() == doubleType) {
        auto da = a.toDouble();
        auto db = b.toDouble();
        switch (comparison) {
        case -1: return da < db;
        case 0:  return qFuzzyCompare(da, db);
        case 1:  return da > db;
        }
    }

    // Case 3: double and integer mixed
    // If one of the 2 is an integer, or a double, then I process it as double
    bool canBeDouble = false;
    if(a.metaType() == longLongType) {
        canBeDouble = true;
    }
    else if(b.metaType() == longLongType) {
        canBeDouble = true;
    }
    else if(a.metaType() == doubleType) {
        canBeDouble = true;
    }
    else if(b.metaType() == doubleType) {
        canBeDouble = true;
    }
    else if(a.metaType() == intType) {
        canBeDouble = true;
    }
    else if(b.metaType() == intType) {
        canBeDouble = true;
    }

    if(canBeDouble) {
        double da = a.toDouble();
        double db = b.toDouble();
        switch (comparison) {
        case -1: return da < db;
        case 0:  return qFuzzyCompare(da, db);
        case 1:  return da > db;
        }
    }

    // Case 4: Fallback to string comparison
    QString sa = a.toString();
    QString sb = b.toString();
    switch (comparison) {
    case -1: return sa < sb;
    case 0:  return sa == sb;
    case 1:  return sa > sb;
    }

    return false;
}


} // namespace App
} // namespace QtNoid
