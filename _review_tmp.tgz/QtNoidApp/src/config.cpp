//=============================================================================
// config.cpp
//=============================================================================
#include "QtNoidApp/config.h"
#include <QDebug>
#include <QJsonObject>
#include <QJsonArray>
#include <QComboBox>

namespace QtNoid {
namespace App {

QMutex Config::s_uniqueIdMutex;
int Config::s_nextUniqueId(20);  // thread-safe

int Config::getNextUniqueId()
{
    QMutexLocker locker(&s_uniqueIdMutex);
    if (s_nextUniqueId == INT_MAX) {
        s_nextUniqueId = 20;  // Reset if overflow
    }
    return s_nextUniqueId++;
}


namespace {
bool isTrackedForIsSchemaModified(const QMetaProperty &prop)
{
    static const QSet<QByteArray> excluded = {
        "objectName", "count", "isValueModified", "isSchemaModified"
    };
    return prop.isReadable() && !excluded.contains(prop.name());
}
}


void Config::initInternalConnections()
{
    static const QMetaMethod onOwnPropertyChangedSlot = Config::staticMetaObject.method(
        Config::staticMetaObject.indexOfSlot("onOwnPropertyChanged()"));

    for (int ii = 0; ii < Config::staticMetaObject.propertyCount(); ++ii) {
        QMetaProperty prop = Config::staticMetaObject.property(ii);
        if (isTrackedForIsSchemaModified(prop) && prop.hasNotifySignal()) {
            connect(this, prop.notifySignal(), this, onOwnPropertyChangedSlot);
        }
    }
}


void Config::captureBaseline()
{
    m_schemaBaseline.clear();
    const QMetaObject *mo = &Config::staticMetaObject;
    for (int ii = 0; ii < mo->propertyCount(); ++ii) {
        QMetaProperty prop = mo->property(ii);
        if (isTrackedForIsSchemaModified(prop)) {
            m_schemaBaseline.insert(prop.name(), prop.read(this));
        }
    }
}

void Config::updateIsSchemaModified()
{
    bool ownChanged = false;
    const QMetaObject *mo = metaObject();
    for (int ii = 0; ii < mo->propertyCount(); ++ii) {
        QMetaProperty prop = mo->property(ii);
        if (isTrackedForIsSchemaModified(prop) && prop.read(this) != m_schemaBaseline.value(prop.name())) {
            ownChanged = true;
            break;
        }
    }
    m_isSchemaModified = m_forceSchemaModified || ownChanged || (m_schemaModifiedCounter > 0);
}




Config::Config(QObject *parent)
    : QObject(parent), m_uniqueId(getNextUniqueId()), m_count(0)
{
    initInternalConnections();
    captureBaseline();

}


Config::Config(const QString &name, QObject *parent)
    : QObject(parent), m_uniqueId(getNextUniqueId()), m_name(name), m_count(0)
{
    initInternalConnections();
    captureBaseline();

}


Config::Config(const QJsonObject &schemaConfig, const QJsonObject &valueConfig, QObject *parent)
    : QObject(parent), m_uniqueId(getNextUniqueId()), m_count(0)
{
    initInternalConnections();

    // Resolve the name once, preferring the schema's key and falling back to
    // the value's key. schemaFromJson()/valuesFromJson() each resolve the
    // name only from their own single argument, so this combined lookup has
    // to stay here -- it's the only place that sees both JSON objects at
    // once -- and must run before delegating to them, so they find m_name
    // already set and just verify their own JSON contains it.
    QString name = m_name.value();
    if(name.isEmpty() && (schemaConfig.count() == 1)) {
        name = schemaConfig.constBegin().key();
        setName(name);
    }
    else if(name.isEmpty() && (valueConfig.count() == 1)) {
        name = valueConfig.constBegin().key();
        setName(name);
    }
    else {
        // There are no useful data in schema or value
        captureBaseline();
        return;
    }

    schemaFromJson(schemaConfig);
    valuesFromJson(valueConfig);
    captureBaseline();

}

Config::~Config()
{
    emit aboutToBeDestroyed(this);
}

QJsonObject Config::toJsonValues() const
{
    QString name = m_name;
    if(name.isEmpty()) {
        name = "ConfigName";
    }

    QJsonArray listsArray;
    for (auto it = m_pagesByIndex.constBegin(); it != m_pagesByIndex.constEnd(); ++it) {
        ParametersPage* list = it.value();
        listsArray.append(list->toJsonValues());
    }

    QJsonObject jsonMain({{"pages", listsArray}});
    QJsonObject json({{name, jsonMain}});

    return json;
}

QJsonObject Config::toJsonSchema() const
{
    QString name = m_name;
    if(name.isEmpty()) {
        name = "ConfigName";
    }

    QJsonArray listsArray;
    for (auto it = m_pagesByIndex.constBegin(); it != m_pagesByIndex.constEnd(); ++it) {
        ParametersPage* list = it.value();
        listsArray.append(list->toJsonSchema());
    }

    QJsonObject schemaMain;
    schemaMain["label"] = m_label.value();
    schemaMain["description"] = m_description.value();
    schemaMain["tooltip"] = m_tooltip.value();
    schemaMain["pages"] = listsArray;

    QJsonObject schema ({{name, schemaMain}});

    return schema;
}

/**
 * @brief Config::valuesFromJson load or update values using a JSON file
 * @param json
 * @return
 */
bool Config::valuesFromJson(const QJsonObject &json)
{
    QString name = m_name.value();
    if(name.isEmpty() && (json.count() == 1)) {
        // Get the unique JSON object and use it to set the name
        name = json.begin().key();
        setName(name);
        captureBaseline();
    }
    else if(!json.contains(name)) {
        // This is not the correct JSON model
        return false;
    }

    // Load parameter lists
    const QJsonObject valueMain = json[name].toObject();
    const QJsonArray valueArray = valueMain["pages"].toArray();
    for (const QJsonValue& value : valueArray) {
        if (value.isObject()) {
            const QJsonObject valueObj = value.toObject();
            const auto valueName = valueObj.constBegin().key();
            ParametersPage* page = m_pagesByName.value(valueName, nullptr);
            if(page == nullptr) {
                page = new ParametersPage(this);
                page->setName(valueName);
                if(!append(page)) {
                    // not a good object
                    delete page;
                    continue;
                }
            }
            page->valuesFromJson(valueObj);
        }
    }
    return true;
}

bool Config::schemaFromJson(const QJsonObject &json)
{
    QString name = m_name.value();
    if(name.isEmpty() && (json.count() == 1)) {
        // Get the unique JSON object and use it to set the name
        name = json.begin().key();
        setName(name);
        captureBaseline();
    }
    else if(!json.contains(name)) {
        // This is not the correct JSON model
        return false;
    }

    // Load description and tooltip from schema
    const QJsonObject schemaMain = json[name].toObject();

    if(schemaMain.contains("label")) {
        setLabel(schemaMain["label"].toString());
    }
    if(schemaMain.contains("description")) {
        setDescription(schemaMain["description"].toString());
    }
    if(schemaMain.contains("tooltip")) {
        setTooltip(schemaMain["tooltip"].toString());
    }

    // Load parameter lists from schema and update the object if present
    const QJsonArray schemaArray = schemaMain["pages"].toArray();
    for (const QJsonValue& schema : schemaArray) {
        if (schema.isObject()) {
            const QJsonObject schemaObj = schema.toObject();
            const auto valueName = schemaObj.constBegin().key();
            ParametersPage* page = m_pagesByName.value(valueName, nullptr);
            if(page == nullptr) {
                page = new ParametersPage(this);
                page->setName(valueName);
                if(!append(page)) {
                    delete page;
                    continue;
                }
            }
            page->schemaFromJson(schemaObj);
        }
    }
    return true;
}

QString Config::name() const
{
    return m_name.value();
}

void Config::setName(const QString &value)
{
    m_name = value;
}

QBindable<QString> Config::bindableName()
{
    return QBindable<QString>(&m_name);
}

QString Config::label() const
{
    return m_label.value();
}

void Config::setLabel(const QString &value)
{
    m_label = value;
}

QBindable<QString> Config::bindableLabel()
{
    return QBindable<QString>(&m_label);
}


QString Config::description() const
{
    return m_description.value();
}


void Config::setDescription(const QString &value)
{
    m_description = value;
}


QBindable<QString> Config::bindableDescription()
{
    return QBindable<QString>(&m_description);
}


QString Config::tooltip() const
{
    return m_tooltip.value();
}


void Config::setTooltip(const QString &value)
{
    m_tooltip = value;
}


QBindable<QString> Config::bindableTooltip()
{
    return QBindable<QString>(&m_tooltip);
}


bool Config::isValueModified() const
{
    return m_isValueModified.value();
}
QBindable<bool> Config::bindableIsValueModified()
{
    return QBindable<bool>(&m_isValueModified);
}

void Config::setValueModified(bool modified)
{
    for (auto it = m_pagesByIndex.constBegin(); it != m_pagesByIndex.constEnd(); ++it) {
        it.value()->setValueModified(modified);
    }
}

void Config::resetValueModifications()
{
    for (auto it = m_pagesByIndex.constBegin(); it != m_pagesByIndex.constEnd(); ++it) {
        it.value()->resetValueModifications();
    }
}

bool Config::isSchemaModified() const
{
    return m_isSchemaModified.value();
}

QBindable<bool> Config::bindableIsSchemaModified()
{
    return QBindable<bool>(&m_isSchemaModified);
}

void Config::setSchemaModified(bool modified)
{
    m_forceSchemaModified = modified;
    if (!modified) {
        captureBaseline();   // own current state becomes the new reference
        // REMEMBER ALSO pages
    }
    // Explicit recompute: if nothing above actually changed a tracked property's
    // value (e.g. captureBaseline() re-captures identical values), nothing would
    // otherwise trigger onOwnPropertyChanged(), leaving m_isSchemaModified stale.
    // Same staleness risk we already fixed in Parameter::captureBaseline().
    updateIsSchemaModified();
}

void Config::resetSchemaModifications()
{
    const QMetaObject *mo = metaObject();
    for (const QByteArray &propName : m_schemaBaseline.keys()) {
        auto idx = mo->indexOfProperty(propName);
        if (idx < 0) {
            continue;
        }
        QMetaProperty prop = mo->property(idx);
        if (prop.isWritable()) {
            prop.write(this, m_schemaBaseline.value(propName));
        }
    }

    for (auto it = m_pagesByIndex.constBegin(); it != m_pagesByIndex.constEnd(); ++it) {
        it.value()->resetSchemaModifications();
    }

    m_forceSchemaModified = false;
    updateIsSchemaModified();   // same staleness guard as above
}


int Config::count() const
{
    return m_count.value();
}

QBindable<int> Config::bindableCount()
{
    return QBindable<int>(&m_count);
}

bool Config::append(ParametersPage *page)
{
    if (page == nullptr) {
        return false;
    }

    auto pageName = page->name();
    if(pageName.isEmpty()){
        return false;
    }

    if (m_pagesByName.contains(pageName)) {
        return false;
    }

    // Update all indexes
    appendPageAndUpdateIndexs(page);
    return true;
}

bool Config::append(const QJsonObject& schema, const QJsonObject& value)
{
    ParametersPage* page = new ParametersPage(schema, value, this);
    auto res = append(page);
    if(!res) {
        delete page;
    }
    return res;
}

ParametersPage* Config::emplace(const QString& name, const QString& description)
{
    if(name.isEmpty()) {
        return {};
    }
    if (m_pagesByName.contains(name)) {
        return {};
    }

    ParametersPage* page = new ParametersPage(name, this);
    page->setDescription(description);

    appendPageAndUpdateIndexs(page);

    return page;
}

ParametersPage* Config::emplace(const QJsonObject& schema, const QJsonObject& values)
{
    ParametersPage* page = new ParametersPage(schema, values, this);
    bool res = append(page);
    if(!res) {
        delete page;
        return {};
    }
    return page;
}


void Config::remove(ParametersPage *page)
{
    if (page == nullptr) {
        return;
    }

    if (!m_pagesByUniqueId.contains(page->uniqueId())) {
        // Not part of this Config
        return;
    }

    m_pagesByUniqueId.remove(page->uniqueId());
    m_pagesByName.remove(page->name());

    int idx = m_pageToIndex.value(page, -1);
    m_pageToIndex.remove(page);
    m_pagesByIndex.remove(idx);

    if (page->isValueModified()) {
        onPageIsValueModifiedChanged(false);
    }
    if (page->isSchemaModified()) {
        onPageIsSchemaModifiedChanged(false);
    }

    disconnect(page, &ParametersPage::aboutToBeDestroyed, this, &Config::onPageAboutToBeDestroyed);
    disconnect(page, &ParametersPage::nameEdited, this, nullptr);
    disconnect(page, &ParametersPage::isValueModifiedChanged, this, &Config::onPageIsValueModifiedChanged);
    disconnect(page, &ParametersPage::isSchemaModifiedChanged, this, &Config::onPageIsSchemaModifiedChanged);

    emit pageRemoved(page);
    m_count = m_pagesByIndex.count();
}


void Config::remove(const QString &pageName)
{
    ParametersPage* page = m_pagesByName.value(pageName, nullptr);
    if(page == nullptr) {
        return;
    }
    remove(page);
}


void Config::clear()
{

    if(isEmpty()) return;

    for (auto it = m_pagesByIndex.begin(); it != m_pagesByIndex.end(); ++it) {
        ParametersPage* page = it.value();
        m_pagesByUniqueId.remove(page->uniqueId());
        m_pagesByName.remove(page->name());
        m_pageToIndex.remove(page);

        disconnect(page, &ParametersPage::aboutToBeDestroyed, this, &Config::onPageAboutToBeDestroyed);
        disconnect(page, &ParametersPage::nameEdited, this, nullptr);
        disconnect(page, &ParametersPage::isValueModifiedChanged, this, &Config::onPageIsValueModifiedChanged);
        disconnect(page, &ParametersPage::isSchemaModifiedChanged, this, &Config::onPageIsSchemaModifiedChanged);

        emit pageRemoved(page);
    }
    // After removing all - it's time to clear also last index
    m_pagesByIndex.clear();

    m_valueModifiedCounter = 0;
    m_isValueModified = false;
    m_schemaModifiedCounter = 0;
    updateIsSchemaModified();

    m_count = 0;
}


bool Config::isEmpty() const
{
    return m_pagesByIndex.isEmpty();
}


ParametersPage *Config::page(int index) const
{
    return m_pagesByIndex.value(index, nullptr);
}


ParametersPage *Config::page(const QString &pageName) const
{
    return m_pagesByName.value(pageName, nullptr);
}


int Config::indexOf(ParametersPage *page) const
{
    return m_pageToIndex.value(page, -1);
}


int Config::indexOf(const QString &pageName) const
{
    ParametersPage *list = m_pagesByName.value(pageName, nullptr);
    return m_pageToIndex.value(list, -1);
}


bool Config::contains(ParametersPage *page) const
{
    return m_pageToIndex.contains(page);
}


bool Config::contains(const QString &pageName) const
{
    return m_pagesByName.contains(pageName);
}


QList<ParametersPage *> Config::pages() const
{
    QList<ParametersPage*> res;
    for(auto it = m_pagesByIndex.cbegin(); it != m_pagesByIndex.cend(); ++it) {
        res << it.value();
    }
    return res;
}


int Config::parametersCount(const QString &pageName) const
{
    ParametersPage* page = m_pagesByName.value(pageName, nullptr);
    if(page == nullptr)
        return {};

    return page->count();
}


Parameter* Config::parameter(const QString& paramName, const QString& pageName) const
{
    ParametersPage* page = m_pagesByName.value(pageName, nullptr);
    if(page == nullptr)
        return {};

    return page->parameter(paramName);
}


bool Config::saveValuePrivate(const QString &paramName, const QVariant &value, const QString &pageName)
{
    // qDebug() << __func__ << value;
    ParametersPage* page = m_pagesByName.value(pageName, nullptr);
    if(page != nullptr) {

        // Update existing page
        if(page->contains(paramName)) {
            // Update the existing value
            return page->setValue(paramName, value);
        }
        // Create the new value
        auto newParam = page->emplace(value, paramName);
        if(newParam == nullptr) {
            return false;
        }
        return true;
    }

    // Create the list and the parameter
    page = emplace(pageName);
    if(page == nullptr) {
        return false;
    }
    auto param = page->emplace(value, paramName);
    if(param == nullptr) {
        return false;
    }

    return true;
}


bool Config::restoreAsBool(const QString &paramName, bool defaultValue, const QString &pageName) const
{
    ParametersPage* page = m_pagesByName.value(pageName, nullptr);
    if(page == nullptr)
        return defaultValue;

    if(!page->contains(paramName))
        return defaultValue;

    return page->value(paramName).toBool();
}


/**
 * @brief Config::setValue: save and create if not exists
 * @param paramName
 * @param value
 * @param listName
 * @return
 */
bool Config::saveValue(const QString &paramName, bool value, const QString &pageName)
{
    return saveValuePrivate(paramName, value, pageName);
}


int Config::restoreAsInt(const QString &paramName, int defaultValue, const QString &pageName) const
{
    ParametersPage* page = m_pagesByName.value(pageName, nullptr);
    if(page == nullptr)
        return defaultValue;

    if(!page->contains(paramName))
        return defaultValue;

    return page->value(paramName).toInt();
}


bool Config::saveValue(const QString &paramName, int value, const QString &pageName)
{
    return saveValuePrivate(paramName, value, pageName);
}


double Config::restoreAsDouble(const QString &paramName, double defaultValue, const QString &pageName) const
{
    ParametersPage* page = m_pagesByName.value(pageName, nullptr);
    if(page == nullptr)
        return defaultValue;

    if(!page->contains(paramName))
        return defaultValue;

    return page->value(paramName).toDouble();
}


bool Config::saveValue(const QString &paramName, double value, const QString &pageName)
{
    return saveValuePrivate(paramName, value, pageName);
}


QString Config::restoreAsString(const QString &paramName, const QString &defaultValue, const QString &pageName) const
{
    ParametersPage* page = m_pagesByName.value(pageName, nullptr);
    if(page == nullptr)
        return defaultValue;

    if(!page->contains(paramName))
        return defaultValue;

    return page->value(paramName).toString();
}


bool Config::saveValue(const QString &paramName, const QString &value, const QString &pageName)
{
    return saveValuePrivate(paramName, value, pageName);
}


QStringList Config::restoreAsStringList(const QString &paramName, const QStringList &defaultValue, const QString &pageName) const
{
    ParametersPage* page = m_pagesByName.value(pageName, nullptr);
    if(page == nullptr)
        return defaultValue;

    if(!page->contains(paramName))
        return defaultValue;

    return page->value(paramName).toStringList();
}


bool Config::saveValue(const QString &paramName, const QStringList &value, const QString &pageName)
{
    return saveValuePrivate(paramName, value, pageName);
}


QVariant Config::restoreAsVariant(const QString& paramName, const QVariant &defaultValue, const QString& pageName) const
{
    ParametersPage* page = m_pagesByName.value(pageName, nullptr);
    if(page == nullptr)
        return defaultValue;

    if(!page->contains(paramName))
        return defaultValue;

    return page->value(paramName);
}


bool Config::saveValue(const QString& paramName, const QVariant& value, const QString& pageName)
{
    return saveValuePrivate(paramName, value, pageName);
}


QByteArray Config::restoreAsByteArray(const QString &paramName, const QByteArray defaultValue, const QString &pageName) const
{
    ParametersPage* page = m_pagesByName.value(pageName, nullptr);
    if(page == nullptr)
        return defaultValue;

    if(!page->contains(paramName))
        return defaultValue;

    auto valueAsString = page->value(paramName).toString();

    return QByteArray::fromBase64(valueAsString.toUtf8());
}


bool Config::saveValue(const QString &paramName, const QByteArray &value, const QString &pageName)
{
    auto valueString = QString::fromUtf8(value.toBase64());
    return saveValuePrivate(paramName, valueString, pageName);
}

QJsonObject Config::restoreAsJson(const QString &paramName, const QJsonObject defaultValue, const QString &pageName) const
{
    ParametersPage* page = m_pagesByName.value(pageName, nullptr);
    if(page == nullptr)
        return defaultValue;

    if(!page->contains(paramName))
        return defaultValue;

    const QJsonValue storedValue = QJsonValue::fromVariant(page->value(paramName));
    if(!storedValue.isObject()) {
        return defaultValue;
    }

    return storedValue.toObject();
}

bool Config::saveValue(const QString &paramName, const QJsonObject &value, const QString &pageName)
{
    return saveValuePrivate(paramName, value, pageName);
}

QStringList Config::restoreRecentFiles(const QStringList defaultValue, const QString &paramName, const QString &pageName) const
{
    ParametersPage* page = m_pagesByName.value(pageName, nullptr);
    if(page == nullptr)
        return defaultValue;

    if(!page->contains(paramName))
        return defaultValue;

    return page->value(paramName).toStringList();
}

void Config::clearRecentFiles(const QString &paramName, const QString &pageName)
{
    ParametersPage* page = m_pagesByName.value(pageName, nullptr);
    if(page == nullptr)
        return;

    if(page->contains(paramName)){
        page->setValue(paramName, QStringList());
    }
}

bool Config::addRecentFile(QString filePath, int max, const QString &paramName, const QString &pageName)
{
    // qDebug() << __func__ << filePath << max << paramName << listName;

    if(filePath.isEmpty())
        return false;

    ParametersPage* page = m_pagesByName.value(pageName, nullptr);

    // Create the list and the parameter
    QStringList filePathList;
    if(page == nullptr) {
        // Create a new page and item
        page = emplace(pageName);
        if(page == nullptr) {
            return false;
        }
        filePathList << filePath;
        page->emplace(filePathList, paramName);
        return true;
    }

    // Expand the list or create if not available
    if(!page->contains(paramName)) {
        filePathList << filePath;
        page->emplace(filePathList, paramName);
        return true;
    }

    filePathList = page->value(paramName).toStringList();
    // Remove the file if it already exists to avoid duplicates
    filePathList.removeAll(filePath);
    filePathList.prepend(filePath);
    // Enforce maximum limit
    if(filePathList.size() > max) {
        filePathList.resize(max);
    }

    page->setValue(paramName, filePathList);

    return true;
}


void Config::onOwnPropertyChanged()
{
    updateIsSchemaModified();
}


void Config::onPageAboutToBeDestroyed(ParametersPage *page)
{
    int idx = m_pageToIndex.value(page, -1);
    if(idx == -1) {
        return;
    }
    m_pageToIndex.remove(page);
    m_pagesByIndex.remove(idx);
    m_pagesByUniqueId.remove(page->uniqueId());

    // Remove from m_pagesByName using the pointer, not page->name(),
    // because the name could have been edited after insertion.
    QString key = m_pagesByName.key(page);
    m_pagesByName.remove(key);

    if (page->isValueModified()) {
        onPageIsValueModifiedChanged(false);
    }
    if (page->isSchemaModified()) {
        onPageIsSchemaModifiedChanged(false);
    }

    emit pageRemoved(page);
    m_count = m_pagesByIndex.count();
    if (isEmpty()) {
        m_nextPageIndex = 0;
    }
}


void Config::onPageNameEdited(const QString &oldName, const QString &newName)
{
    if(!m_pagesByName.contains(oldName)) {
        emit pageRenameError(oldName, newName);
        return;
    }

    if(m_pagesByName.contains(newName)) {
        emit pageRenameError(oldName, newName);
        return;
    }

    ParametersPage* page = m_pagesByName.take(oldName);
    m_pagesByName.insert(newName, page);

    return;
}

void Config::onPageIsValueModifiedChanged(bool changed)
{
    if(changed) {
        ++m_valueModifiedCounter;
    }
    else {
        --m_valueModifiedCounter;
    }
    m_isValueModified = (m_valueModifiedCounter > 0);
}

void Config::onPageIsSchemaModifiedChanged(bool changed)
{
    if(changed) {
        ++m_schemaModifiedCounter;
    }
    else {
        --m_schemaModifiedCounter;
    }
    updateIsSchemaModified();
}

void Config::appendPageAndUpdateIndexs(ParametersPage *page)
{
    m_pageToIndex.insert(page, m_nextPageIndex);
    m_pagesByIndex.insert(m_nextPageIndex, page);

    // NOW I can increment the pageIndex
    m_nextPageIndex++;
    m_pagesByName.insert(page->name(), page);
    m_pagesByUniqueId.insert(page->uniqueId(), page);

    connect(page, &ParametersPage::aboutToBeDestroyed, this, &Config::onPageAboutToBeDestroyed);
    connect(page, &ParametersPage::nameEdited, this, &Config::onPageNameEdited);
    connect(page, &ParametersPage::isValueModifiedChanged, this, &Config::onPageIsValueModifiedChanged);
    connect(page, &ParametersPage::isSchemaModifiedChanged, this, &Config::onPageIsSchemaModifiedChanged);


    if (page->isValueModified()) {
        onPageIsValueModifiedChanged(true);
    }
    if (page->isSchemaModified()) {
        onPageIsSchemaModifiedChanged(true);
    }

    emit pageAdded(page);
    m_count = m_pagesByIndex.count();
}


} // namespace App
} // namespace QtNoid
