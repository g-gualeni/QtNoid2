#ifndef QTNOIDCORE_VERSION_H
#define QTNOIDCORE_VERSION_H

#define PROJECT_VERSION "2.0.1"
#define PROJECT_NAME "QtNoidCore"
#define PROJECT_COPYRIGHT "(C) 2025 Gianbattista Gualeni"

#endif // QTNOIDCORE_VERSION_H
